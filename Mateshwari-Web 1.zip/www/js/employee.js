// ---------- Employee views ----------
(function () {
  const V = window.Views, esc = U.esc;

  const todayId = () => S.user.empId + '_' + U.dateKey();

  // ===== HOME (GPS check-in / out) =====
  V.empHome = async function (el) {
    const e = S.emp;
    const [att, hol] = await Promise.all([DB.get('attendance', todayId()), Cal.holidays(U.monthKey())]);
    const st = S.settings;
    const todayHol = hol[U.dateKey()];
    const isOff = Cal.weeklyOff(e) === new Date().getDay();
    const unreadWarn = (S.warnings || []).filter((w) => !w.readAt);
    const notifs = (S.notifs || []).slice(0, 3);
    const now = new Date();

    let actionHtml;
    if (!att || !att.checkIn) {
      actionHtml = '<button class="big-btn in" id="btnIn"><span>📍</span>' + T('checkIn') + '</button>';
    } else if (!att.checkOut) {
      actionHtml = '<div class="mini-stat">' + T('checkedInAt') + ' <b>' + U.fmtTime(att.checkIn.at) + '</b></div>' +
        '<button class="big-btn out" id="btnOut"><span>🏁</span>' + T('checkOut') + '</button>';
    } else {
      const hrs = ((att.checkOut.at - att.checkIn.at) / 3600000);
      actionHtml = '<div class="done-box">✅ ' + T('dayComplete') + '<div class="row-between"><span>' + T('in') + ': <b>' + U.fmtTime(att.checkIn.at) + '</b></span><span>' +
        T('out') + ': <b>' + U.fmtTime(att.checkOut.at) + '</b></span><span>' + T('hours') + ': <b>' + hrs.toFixed(1) + '</b></span></div></div>';
    }

    el.innerHTML =
      '<div class="hello card">' + App.empAvatar(e, 56) + '<div><small class="muted">' + T('welcome') + '</small><h2>' + esc(e.name) + '</h2><small>' +
      esc(e.designation || '') + ' · ' + esc(e.id) + '</small></div></div>' +
      '<div class="card att-card"><div class="row-between"><b>' + T('todayAttendance') + '</b><span>' + U.fmtDate(now) + '</span></div>' +
      (todayHol ? '<div class="hol-banner">🎉 ' + T('todayHoliday') + ': <b>' + esc(todayHol) + '</b></div>' : isOff ? '<div class="hol-banner">🛌 ' + T('todayWeeklyOff') + '</div>' : '') +
      '<div class="clock" id="clock">' + U.fmtTime(now) + '</div>' +
      (att ? '<div class="center">' + U.badge(att.status) + (att.status === 'rejected' && att.note ? '<p class="muted small">' + esc(att.note) + '</p>' : '') + '</div>' : '') +
      actionHtml +
      (att && att.checkIn && !att.checkOut && window.LiveLoc && LiveLoc.enabled() ? '<div class="track-banner">📍 ' + T('trackingOn') + '</div>' : '') +
      '<p class="muted small center">' + (st.lat != null ? T('gpsInfo').replace('{r}', st.radius) : T('gpsNotSet')) + '</p></div>' +
      (unreadWarn.length ? '<div class="card warn-card" onclick="App.go(\'empLetters\')">⚠️ ' + T('youHaveWarning').replace('{n}', unreadWarn.length) + '</div>' : '') +
      '<div class="grid2">' +
      tile('empTargets', '🎯', T('targets')) + tile('empTargets', '💼', T('wallet'), { tab: 'wallet' }) +
      tile('empLearn', '📘', T('training')) + tile('empLearn', '📝', T('exams'), { tab: 'exams' }) +
      tile('empAttendance', '📅', T('myAttendance')) + tile('empLoan', '💰', T('loan')) +
      tile('empLedger', '📒', T('paymentLedger')) + tile('empDocs', '📁', T('myDocuments')) +
      tile('empIdCard', '🪪', T('idCard')) + tile('empLetters', '✉️', T('letters')) +
      (App.can('cashier') ? tile('cashier', '🧾', T('cashierEntry')) : '') +
      (App.can('approveAttendance') ? tile('attApprove', '✔️', T('approveAttendance')) : '') +
      '</div>' +
      '<h3 class="sec-title">' + T('latestNotifications') + '</h3>' +
      (notifs.length ? notifs.map((n) => '<div class="card notif" onclick="App.go(\'notifications\')"><div class="row-between"><b>' + esc(n.title) + '</b><small class="muted">' +
        U.fmtDate(n.at) + '</small></div><p class="clamp">' + esc(n.body) + '</p></div>').join('') : U.empty(T('noNotifications')));

    const ck = setInterval(() => { const c = U.$('#clock'); if (!c) return clearInterval(ck); c.textContent = U.fmtTime(new Date()); }, 15000);
    const bi = U.$('#btnIn'); if (bi) bi.onclick = () => punch('in');
    const bo = U.$('#btnOut'); if (bo) bo.onclick = () => punch('out');
  };

  function tile(view, icon, label, params) {
    return '<a class="tile card" onclick="App.go(\'' + view + '\'' + (params ? ',' + esc(JSON.stringify(params)) : '') + ')"><span>' + icon + '</span>' + esc(label) + '</a>';
  }

  async function punch(kind) {
    const st = S.settings;
    U.loading(true, T('gettingLocation'));
    let loc;
    try { loc = await U.getLocation(); }
    catch (e) { U.loading(false); return U.toast(e.message || T('gpsFailed'), 'err'); }
    let dist = null, inside = true;
    if (st.lat != null && st.lng != null) {
      dist = U.distance(loc.lat, loc.lng, st.lat, st.lng);
      inside = dist <= (Number(st.radius) || 150);
    }
    if (loc.mocked) { U.loading(false); return U.toast(T('mockGps'), 'err'); }
    if (!inside && st.blockOutside) {
      U.loading(false);
      return U.modal(T('outsideShowroom'), '<p>' + T('outsideMsg').replace('{d}', dist).replace('{r}', st.radius) + '</p><p class="muted small">GPS accuracy: ±' + loc.acc + 'm</p>');
    }
    const p = { at: Date.now(), serverAt: DB.now(), lat: loc.lat, lng: loc.lng, acc: loc.acc, dist: dist, inside: inside };
    try {
      if (kind === 'in') {
        await DB.set('attendance', todayId(), {
          empId: S.user.empId, empName: S.emp.name, date: U.dateKey(), month: U.monthKey(),
          checkIn: p, status: 'pending', createdAt: DB.now()
        });
      } else {
        await DB.update('attendance', todayId(), { checkOut: p });
      }
      U.toast(kind === 'in' ? T('checkInDone') : T('checkOutDone'), 'ok');
      if (kind === 'in' && window.LiveLoc) setTimeout(() => LiveLoc.tick(true), 1500);
      App.go('empHome');
    } catch (e) { U.toast(e.message, 'err'); }
    finally { U.loading(false); }
  }

  // ===== MY ATTENDANCE =====
  V.empAttendance = async function (el, p) {
    const month = p.month || U.monthKey();
    const [list, hol] = await Promise.all([DB.query('attendance', [['empId', '==', S.user.empId], ['month', '==', month]]), Cal.holidays(month)]);
    list.sort((a, b) => b.date.localeCompare(a.date));
    const s = Cal.summary(S.emp, list, month, hol);
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('myAttendance') + '</h2>' + App.monthSelect('mSel', month) + '</div>' +
      '<div class="stats4"><div><b>' + s.present + '</b><small>' + T('presentApproved') + '</small></div><div><b>' + s.pending + '</b><small>' + T('pending') +
      '</small></div><div><b>' + s.hols + '</b><small>' + T('holidays') + '</small></div><div><b>' + s.pct + '%</b><small>' + T('attendancePct') + '</small></div></div>' +
      App.calendarHtml(S.emp, month, list, hol) +
      (Object.keys(hol).length ? '<div class="card"><b>🎉 ' + T('holidays') + '</b>' + Object.keys(hol).sort().map((d) => '<div class="row-between small"><span>' + U.fmtDate(d) + '</span><span>' + esc(hol[d]) + '</span></div>').join('') + '</div>' : '') +
      (list.length ? '<div class="card list">' + list.map((a) => '<div class="li"><div><b>' + U.fmtDate(a.date) + '</b><small>' + T('in') + ' ' +
        (a.checkIn ? U.fmtTime(a.checkIn.at) : '-') + ' · ' + T('out') + ' ' + (a.checkOut ? U.fmtTime(a.checkOut.at) : '-') +
        (a.dayType === 'half' ? ' · ' + T('halfDay') : '') + (hol[a.date] ? ' · 🎉 ' + esc(hol[a.date]) : '') + (a.note ? '<br>' + esc(a.note) : '') + '</small></div>' + U.badge(a.status) + '</div>').join('') + '</div>' : U.empty());
    U.$('#mSel').onchange = (ev) => App.go('empAttendance', { month: ev.target.value });
  };

  // ===== LOAN =====
  V.empLoan = async function (el) {
    const ls = S.loanSettings, e = S.emp;
    const loans = (await DB.query('loans', [['empId', '==', S.user.empId]])).sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    const eligible = ls.enabled && App.can('applyLoan') && e.loanEligible;
    const active = loans.find((l) => l.status === 'applied' || l.status === 'in_process' || (l.status === 'approved' && !l.closed));
    el.innerHTML = '<h2 class="page-title">' + T('loan') + '</h2>' +
      (eligible ? (active ? '<div class="note">' + T('loanActiveExists') + '</div>' :
        '<div class="card loan-cta"><div><b>' + T('needLoan') + '</b><small>' + T('maxEligible') + ': ' + U.money(maxLoan()) + ' · ' + T('upTo') + ' ' + ls.maxTenure + ' ' + T('months') +
        '</small></div><button class="btn" onclick="App.go(\'empLoanApply\')">' + T('applyLoan') + '</button></div>')
        : '<div class="note">' + T('notEligibleLoan') + '</div>') +
      '<h3 class="sec-title">' + T('myLoans') + '</h3>' +
      (loans.length ? loans.map(loanCard).join('') : U.empty(T('noLoans')));
    U.$$('[data-loan]').forEach((b) => b.onclick = () => loanDetail(loans.find((l) => l.id === b.dataset.loan)));
  };

  function maxLoan() {
    const a = Number(S.emp.maxLoanAmount) || 0, b = Number(S.loanSettings.maxAmount) || 0;
    return a && b ? Math.min(a, b) : (a || b);
  }

  function stepper(l) {
    const steps = l.steps || [];
    return '<div class="stepper">' + steps.map((s, i) => {
      const done = ['approved', 'disbursed', 'closed'].includes(l.status) || i < l.step;
      const cur = l.status === 'in_process' || l.status === 'applied' ? i === l.step : false;
      const rej = l.status === 'rejected' && i === l.step;
      return '<div class="st ' + (done ? 'done' : rej ? 'rej' : cur ? 'cur' : '') + '"><i>' + (done ? '✓' : rej ? '✕' : i + 1) + '</i><span>' + esc(s) + '</span></div>';
    }).join('') + '</div>';
  }
  window.loanStepper = stepper;

  function loanCard(l) {
    return '<div class="card"><div class="row-between"><div><b>' + U.money(l.approvedAmount || l.amount) + '</b><small class="muted"> · ' + l.tenure + ' ' + T('months') +
      '</small><br><small class="muted">' + T('appliedOn') + ' ' + U.fmtDate(l.createdAt) + (l.loanNo ? ' · ' + esc(l.loanNo) : '') + '</small></div>' + U.badge(l.status) + '</div>' +
      stepper(l) + '<button class="btn ghost sm" data-loan="' + l.id + '">' + T('viewDetails') + '</button></div>';
  }

  function loanDetail(l) {
    const hist = (l.history || []).slice().reverse();
    const approved = l.status === 'approved';
    const m = U.modal(T('loanDetails'),
      '<div class="kv">' + kv(T('amountApplied'), U.money(l.amount)) + (l.approvedAmount ? kv(T('amountApproved'), U.money(l.approvedAmount)) : '') +
      kv(T('tenure'), l.tenure + ' ' + T('months')) + kv(T('interest'), (l.interest || 0) + '% p.a.') + kv('EMI', U.money(l.emi)) + kv(T('purpose'), esc(l.purpose)) +
      kv(T('status'), U.badge(l.status)) + '</div>' + stepper(l) +
      (approved ? '<div class="row-btns"><button class="btn" data-a="letter">📄 ' + T('approvalLetter') + '</button><button class="btn" data-a="dpn">📝 DPN</button></div>' : '') +
      '<h4>' + T('timeline') + '</h4><div class="timeline">' + hist.map((h) => '<div><b>' + esc(h.step) + '</b> — ' + esc(T('st_' + h.status)) +
        '<small class="muted"> · ' + U.fmtDT(h.at) + '</small>' + (h.note ? '<br><small>' + esc(h.note) + '</small>' : '') + '</div>').join('') + '</div>', { wide: true });
    U.$$('[data-a]', m.el).forEach((b) => b.onclick = () => {
      if (b.dataset.a === 'letter') PDF.showLoanLetter(l);
      else PDF.showDPN(l);
    });
  }
  function kv(k, v) { return '<div><span>' + esc(k) + '</span><b>' + v + '</b></div>'; }
  window.kvRow = kv;
  window.loanDetailView = loanDetail;

  V.empLoanApply = async function (el) {
    const e = S.emp, ls = S.loanSettings;
    if (!(ls.enabled && App.can('applyLoan') && e.loanEligible)) { el.innerHTML = '<div class="note">' + T('notEligibleLoan') + '</div>'; return; }
    const basic = [
      ['name', T('fullName')], ['id', T('employeeId')], ['fatherName', T('fatherName')], ['dob', T('dob'), 'date'],
      ['mobile', T('mobile'), 'tel'], ['address', T('address')], ['designation', T('designation')], ['joinDate', T('joinDate'), 'date'],
      ['aadhaar', T('aadhaar')], ['pan', T('pan')], ['bankName', T('bankName')], ['accountNo', T('accountNo')], ['ifsc', 'IFSC']
    ];
    const max = maxLoan();
    el.innerHTML = '<h2 class="page-title">' + T('loanApplication') + '</h2><form id="lf" class="form">' +
      '<div class="card"><h3>' + T('basicDetails') + '</h3><p class="muted small">' + T('autoFillNote') + '</p>' +
      basic.map((b) => U.field('b_' + b[0], b[1], e[b[0]], { type: b[2], readonly: !!e[b[0]], auto: !!e[b[0]], required: true })).join('') + '</div>' +
      '<div class="card"><h3>' + T('loanDetails') + '</h3>' +
      U.field('amount', T('loanAmount') + ' (max ' + U.money(max) + ')', '', { type: 'number', required: true, min: 1 }) +
      U.field('tenure', T('tenureMonths'), Math.min(6, ls.maxTenure), { type: 'select', options: Array.from({ length: ls.maxTenure }, (_, i) => i + 1) }) +
      U.field('purpose', T('purpose'), '', { type: 'textarea', required: true }) +
      (ls.customFields || []).map((f) => U.field('c_' + f.key, f.label, '', { type: f.type === 'textarea' ? 'textarea' : f.type, required: !!f.required })).join('') +
      '<div class="emi-box" id="emiBox">EMI: -</div>' +
      (ls.terms ? '<div class="terms">' + esc(ls.terms).replace(/\n/g, '<br>') + '</div>' : '') +
      U.field('agree', T('declaration'), false, { type: 'checkbox' }) + '</div>' +
      '<button class="btn block">' + T('submitApplication') + '</button></form>';
    const f = U.$('#lf');
    const upd = () => {
      const d = U.formData(f);
      U.$('#emiBox').innerHTML = 'EMI: <b>' + U.money(U.emi(d.amount, ls.interest, d.tenure)) + '</b> × ' + d.tenure + ' (' + (ls.interest || 0) + '% p.a.)';
    };
    f.oninput = upd; upd();
    f.onsubmit = async (ev) => {
      ev.preventDefault();
      const d = U.formData(f);
      if (!d.agree) return U.toast(T('acceptDeclaration'), 'err');
      if (!(d.amount > 0)) return U.toast(T('enterAmount'), 'err');
      if (max && d.amount > max) return U.toast(T('amountExceeds') + ' ' + U.money(max), 'err');
      const applicant = {}; basic.forEach((b) => { applicant[b[0]] = d['b_' + b[0]] || ''; });
      const custom = {}; (ls.customFields || []).forEach((cf) => { custom[cf.key] = { label: cf.label, value: d['c_' + cf.key] || '' }; });
      const tenure = Number(d.tenure);
      U.loading(true);
      try {
        await DB.add('loans', {
          empId: S.user.empId, empName: e.name, applicant, custom, amount: Number(d.amount), tenure, purpose: d.purpose,
          interest: Number(ls.interest) || 0, emi: U.emi(d.amount, ls.interest, tenure),
          steps: (ls.steps || []).slice(), step: 0, status: 'applied',
          history: [{ step: T('applied'), status: 'applied', at: Date.now(), by: e.name }],
          createdAt: DB.now(), month: U.monthKey()
        });
        U.toast(T('loanSubmitted'), 'ok');
        App.go('empLoan');
      } catch (err) { U.toast(err.message, 'err'); }
      finally { U.loading(false); }
    };
  };

  // ===== PAYMENT LEDGER =====
  V.empLedger = async function (el) {
    const list = (await DB.query('payments', [['empId', '==', S.user.empId]])).sort((a, b) => b.date.localeCompare(a.date));
    const total = list.reduce((s, p) => s + U.num(p.amount), 0);
    const mk = U.monthKey();
    const thisMonth = list.filter((p) => p.date.startsWith(mk)).reduce((s, p) => s + U.num(p.amount), 0);
    const groups = {};
    list.forEach((p) => { const m = p.date.slice(0, 7); (groups[m] = groups[m] || []).push(p); });
    el.innerHTML = '<h2 class="page-title">' + T('paymentLedger') + '</h2>' +
      '<div class="stats4 two"><div><b>' + U.money(thisMonth) + '</b><small>' + T('thisMonth') + '</small></div><div><b>' + U.money(total) + '</b><small>' + T('totalReceived') + '</small></div></div>' +
      (list.length ? Object.keys(groups).sort().reverse().map((m) => '<h3 class="sec-title">' + U.monthLabel(m) + ' <small class="muted">' + U.money(groups[m].reduce((s, p) => s + U.num(p.amount), 0)) +
        '</small></h3><div class="card list">' + groups[m].map((p) => '<div class="li"><div><b>' + U.fmtDate(p.date) + '</b><small>' + esc(T('pt_' + (p.type || 'other'))) + ' · ' + esc(p.mode || '') +
          (p.note ? ' · ' + esc(p.note) : '') + '</small></div><b class="amt">' + U.money(p.amount) + '</b></div>').join('') + '</div>').join('') : U.empty(T('noPayments')));
  };

  // ===== MORE =====
  V.empMore = async function (el) {
    const items = [
      ['empProfile', '👤', T('myProfile')], ['empLoan', '💰', T('loan')], ['empLedger', '📒', T('paymentLedger')],
      ['empLearn', '🏅', T('myProgress') + ' / ' + T('certificates'), { tab: 'progress' }],
      ['empDocs', '📁', T('myDocuments')], ['empIdCard', '🪪', T('idCard')],
      ['empLetters', '✉️', T('letters')], ['notifications', '🔔', T('notifications')]
    ];
    if (App.can('cashier')) items.push(['cashier', '🧾', T('cashierEntry')]);
    if (App.can('approveAttendance')) items.push(['attApprove', '✔️', T('approveAttendance')]);
    items.push(['changePassword', '🔑', T('changePassword')]);
    el.innerHTML = '<h2 class="page-title">' + T('more') + '</h2><div class="card menu-list">' +
      items.map((i) => '<a onclick="App.go(\'' + i[0] + '\'' + (i[3] ? ',' + esc(JSON.stringify(i[3])) : '') + ')"><span>' + i[1] + '</span>' + esc(i[2]) + '<i>›</i></a>').join('') +
      '<a onclick="App.logout()"><span>🚪</span>' + T('logout') + '<i>›</i></a></div>';
  };

  // ===== PROFILE =====
  const SELF_EDIT = ['fatherName', 'dob', 'address', 'altMobile', 'email', 'bloodGroup', 'emergencyContact', 'aadhaar', 'pan', 'bankName', 'accountNo', 'ifsc'];
  V.empProfile = async function (el) {
    const e = S.emp;
    const rows = [['employeeId', e.id], ['fullName', e.name], ['fatherName', e.fatherName], ['designation', e.designation], ['department', e.department],
    ['mobile', e.mobile], ['altMobile', e.altMobile], ['email', e.email], ['dob', U.fmtDate(e.dob)], ['joinDate', U.fmtDate(e.joinDate)], ['bloodGroup', e.bloodGroup],
    ['address', e.address], ['emergencyContact', e.emergencyContact], ['aadhaar', e.aadhaar], ['pan', e.pan], ['bankName', e.bankName], ['accountNo', e.accountNo], ['IFSC', e.ifsc]];
    el.innerHTML = '<div class="profile-head card">' + App.empAvatar(e, 84) + '<h2>' + esc(e.name) + '</h2><small>' + esc(e.designation || '') + '</small><small class="muted">' + T('photoAdminOnly') + '</small></div>' +
      '<div class="card kv">' + rows.map((r) => kvRow(T(r[0]), esc(r[1] || '-'))).join('') + '</div>' +
      (App.can('editProfile') ? '<button class="btn block" id="edp">✏️ ' + T('editProfile') + '</button>' : '<p class="muted small center">' + T('profileEditLocked') + '</p>');
    const b = U.$('#edp'); if (b) b.onclick = editProfile;
  };
  function editProfile() {
    const e = S.emp;
    const m = U.modal(T('editProfile'), '<form class="form" id="epf">' + SELF_EDIT.map((k) => U.field(k, T(k === 'ifsc' ? 'IFSC' : k), e[k], { type: k === 'dob' ? 'date' : (k === 'address' ? 'textarea' : 'text') })).join('') +
      '<button class="btn block">' + T('save') + '</button></form>', { wide: true });
    U.$('#epf', m.el).onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const upd = {}; SELF_EDIT.forEach((k) => { upd[k] = d[k] || ''; });
      U.loading(true);
      try { await DB.update('employees', S.user.empId, upd); Object.assign(S.emp, upd); m.close(); U.toast(T('saved'), 'ok'); App.go('empProfile'); }
      catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
  }

  // ===== DOCUMENTS =====
  V.empDocs = async function (el) {
    if (!App.can('docsView')) { el.innerHTML = '<h2 class="page-title">' + T('myDocuments') + '</h2><div class="note">' + T('noRight') + '</div>'; return; }
    const docs = await DB.query('documents', [['empId', '==', S.user.empId]]);
    el.innerHTML = '<h2 class="page-title">' + T('myDocuments') + '</h2>' +
      (App.can('docsAdd') ? '<button class="btn" id="upDoc">⬆️ ' + T('uploadDocument') + '</button>' : '') +
      Docs.listHtml(docs, { canEdit: App.can('docsEdit'), admin: false });
    const u = U.$('#upDoc'); if (u) u.onclick = () => Docs.upload(S.user.empId, S.emp.name, false, () => App.go('empDocs'));
    Docs.bind(el, docs, { canEdit: App.can('docsEdit'), admin: false, reload: () => App.go('empDocs') });
  };

  // ===== ID CARD =====
  V.empIdCard = async function (el) {
    const e = S.emp;
    const limit = (Number((e.rights || {}).idCardLimit) || 0) + (Number(e.idExtraApproved) || 0);
    const used = Number(e.idPrintsUsed) || 0;
    const reqs = await DB.query('idRequests', [['empId', '==', S.user.empId]]);
    const pendingReq = reqs.find((r) => r.status === 'pending');
    el.innerHTML = '<h2 class="page-title">' + T('idCard') + '</h2>' + PDF.idCardHtml(e, S.settings) +
      '<div class="card center"><p>' + T('printsUsed') + ': <b>' + used + ' / ' + limit + '</b></p>' +
      (used < limit ? '<button class="btn" id="prId">🖨️ ' + T('printIdCard') + '</button>' :
        pendingReq ? '<div class="note">' + T('idRequestPending') + '</div>' :
          '<p class="muted">' + T('idLimitReached') + '</p><button class="btn" id="reqId">' + T('requestApproval') + '</button>') + '</div>';
    const pr = U.$('#prId');
    if (pr) pr.onclick = async () => {
      U.loading(true);
      try {
        await DB.update('employees', S.user.empId, { idPrintsUsed: used + 1 });
        S.emp.idPrintsUsed = used + 1;
        await PDF.idCardPdf(e, S.settings);
        App.go('empIdCard');
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
    const rq = U.$('#reqId');
    if (rq) rq.onclick = async () => {
      const reason = await U.prompt(T('requestApproval'), T('reason'), '', 'textarea');
      if (reason == null) return;
      await DB.add('idRequests', { empId: S.user.empId, empName: e.name, reason, status: 'pending', at: DB.now() });
      U.toast(T('requestSent'), 'ok'); App.go('empIdCard');
    };
  };

  // ===== LETTERS =====
  V.empLetters = async function (el) {
    const warns = (await DB.query('warnings', [['empId', '==', S.user.empId]])).sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    const loans = (await DB.query('loans', [['empId', '==', S.user.empId]])).filter((l) => ['approved', 'disbursed', 'closed'].includes(l.status));
    el.innerHTML = '<h2 class="page-title">' + T('letters') + '</h2>' +
      '<h3 class="sec-title">' + T('warningLetters') + '</h3>' +
      (warns.length ? warns.map((w) => '<div class="card letter-item' + (w.readAt ? '' : ' unread') + '" data-w="' + w.id + '"><div class="row-between"><b>⚠️ ' + esc(w.subject) +
        '</b>' + (w.readAt ? '' : U.badge('unread')) + '</div><small class="muted">' + U.fmtDate(w.at) + ' · ' + esc(w.refNo || '') + '</small></div>').join('') : U.empty(T('noWarnings'))) +
      '<h3 class="sec-title">' + T('loanLetters') + '</h3>' +
      (loans.length ? loans.map((l) => '<div class="card"><b>' + esc(l.loanNo || '') + ' · ' + U.money(l.approvedAmount || l.amount) + '</b><div class="row-btns"><button class="btn sm" data-ll="' + l.id +
        '">📄 ' + T('sanctionLetter') + '</button><button class="btn sm ghost" data-ld="' + l.id + '">📝 DPN</button><button class="btn sm ghost" data-la="' + l.id + '">📑 ' + T('loanAgreement') + '</button></div></div>').join('') : U.empty(T('noLoanLetters')));
    U.$$('[data-w]').forEach((c) => c.onclick = async () => {
      const w = warns.find((x) => x.id === c.dataset.w);
      PDF.showWarning(w);
      if (!w.readAt) { try { await DB.update('warnings', w.id, { readAt: DB.now() }); c.classList.remove('unread'); } catch (e) { } }
    });
    U.$$('[data-ll]').forEach((b) => b.onclick = () => PDF.showLoanLetter(loans.find((l) => l.id === b.dataset.ll)));
    U.$$('[data-ld]').forEach((b) => b.onclick = () => PDF.showDPN(loans.find((l) => l.id === b.dataset.ld)));
    U.$$('[data-la]').forEach((b) => b.onclick = () => PDF.showAgreement(loans.find((l) => l.id === b.dataset.la)));
  };
})();
