// ---------- App shell, login, router ----------
(function () {
  const S = window.S = { user: null, emp: null, settings: null, loanSettings: null, isAdmin: false, view: null, params: null, unsubs: [] };
  const V = window.Views = {};
  const App = window.App = {};
  const esc = U.esc;

  const root = () => document.getElementById('app');

  App.start = async function () {
    I18N.init();
    if (!DB.configured()) return renderNotConfigured();
    try { DB.init(); } catch (e) { return renderNotConfigured(e.message); }
    U.loading(true);
    DB.auth.onAuthStateChanged(async (fbUser) => {
      if (S.bootstrapping) return;
      S.unsubs.forEach((f) => { try { f(); } catch (e) { } }); S.unsubs = [];
      if (!fbUser) { U.loading(false); return renderLogin(); }
      try {
        const u = await DB.get('users', fbUser.uid);
        if (!u || u.active === false) {
          U.loading(false); await DB.signOut(); U.toast(T('accountInactive'), 'err'); return;
        }
        S.user = u; S.isAdmin = u.role === 'admin';
        S.settings = Object.assign(DB.defaultSettings(), (await DB.get('settings', 'app')) || {});
        S.loanSettings = Object.assign(DB.defaultLoanSettings(), (await DB.get('settings', 'loan')) || {});
        if (!S.isAdmin) {
          S.emp = await DB.get('employees', u.empId);
          if (!S.emp) { U.loading(false); await DB.signOut(); U.toast(T('profileMissing'), 'err'); return; }
          S.unsubs.push(DB.watchDoc('employees', u.empId, (e) => { if (e) S.emp = e; }));
        }
        U.loading(false);
        renderShell();
        App.watchNotifications();
        if (window.LiveLoc) LiveLoc.start();
        App.go(S.isAdmin ? 'adminDashboard' : 'empHome');
      } catch (e) {
        console.error(e); U.loading(false);
        root().innerHTML = '<div class="center-card card"><h3>' + T('error') + '</h3><p>' + esc(e.message) + '</p><button class="btn" onclick="DB.signOut()">' + T('logout') + '</button></div>';
      }
    });
  };

  App.rights = function () { return (S.emp && S.emp.rights) || {}; };
  App.can = function (r) { return S.isAdmin || !!App.rights()[r]; };

  function renderNotConfigured(msg) {
    root().innerHTML = '<div class="center-card card"><img src="img/logo.png" class="login-logo" alt=""><h2>' + esc(APP_INFO.showroom) +
      '</h2><p>' + T('notConfigured') + '</p>' + (msg ? '<p class="muted">' + esc(msg) + '</p>' : '') + '</div>';
  }

  // ---------- Login ----------
  async function renderLogin() {
    S.user = null; S.emp = null;
    U.$$('.modal-wrap').forEach((m) => m.remove());
    if (window.LiveLoc) LiveLoc.stop();
    let boot = null;
    try { boot = await DB.get('meta', 'bootstrap'); } catch (e) { console.warn(e); }
    const needSetup = !boot;
    root().innerHTML = '<div class="login-page">' +
      '<div class="lang-top">' + langSwitch() + '</div>' +
      '<div class="login-card card">' +
      '<img src="img/logo.png" class="login-logo" alt="">' +
      '<h2>' + esc(APP_INFO.showroom) + '</h2><p class="muted">' + T('appSubtitle') + '</p>' +
      (needSetup ? setupForm() : loginForm()) +
      '</div><p class="muted small center">v' + APP_INFO.version + '</p></div>';
    bindLang();
    const f = U.$('#loginForm');
    if (f) f.onsubmit = async (e) => {
      e.preventDefault();
      const d = U.formData(f);
      U.loading(true, T('signingIn'));
      try { await DB.signIn(d.id, d.password); }
      catch (err) { U.loading(false); U.toast(friendlyAuthError(err), 'err'); }
    };
    const sf = U.$('#setupForm');
    if (sf) sf.onsubmit = async (e) => {
      e.preventDefault();
      const d = U.formData(sf);
      if (d.password.length < 6) return U.toast(T('pwdShort'), 'err');
      if (d.password !== d.password2) return U.toast(T('pwdMismatch'), 'err');
      U.loading(true); S.bootstrapping = true;
      try { await DB.bootstrap(d.name, d.email, d.password); U.toast(T('adminCreated'), 'ok'); setTimeout(() => location.reload(), 600); }
      catch (err) { S.bootstrapping = false; U.loading(false); U.toast(friendlyAuthError(err), 'err'); try { await DB.signOut(); } catch (e) { } }
    };
  }

  function loginForm() {
    return '<form id="loginForm" class="form">' +
      U.field('id', T('mobileOrEmail'), '', { required: true, placeholder: '98xxxxxxxx' }) +
      U.field('password', T('password'), '', { type: 'password', required: true }) +
      '<button class="btn block" type="submit">' + T('login') + '</button>' +
      '<p class="muted small center">' + T('forgotHint') + '</p></form>';
  }
  function setupForm() {
    return '<div class="note">' + T('firstSetup') + '</div><form id="setupForm" class="form">' +
      U.field('name', T('adminName'), '', { required: true }) +
      U.field('email', T('email'), '', { type: 'email', required: true }) +
      U.field('password', T('password'), '', { type: 'password', required: true }) +
      U.field('password2', T('confirmPassword'), '', { type: 'password', required: true }) +
      '<button class="btn block" type="submit">' + T('createAdmin') + '</button></form>';
  }
  function friendlyAuthError(err) {
    const c = (err && err.code) || '';
    if (/wrong-password|invalid-credential|invalid-login|user-not-found/.test(c)) return T('wrongLogin');
    if (/too-many-requests/.test(c)) return T('tooMany');
    if (/network/.test(c)) return T('noInternet');
    if (/email-already-in-use/.test(c)) return T('emailUsed');
    if (/weak-password/.test(c)) return T('pwdShort');
    return (err && err.message) || String(err);
  }
  App.friendlyAuthError = friendlyAuthError;

  function langSwitch() {
    return '<div class="lang-sw"><button data-lang="en" class="' + (I18N.lang === 'en' ? 'on' : '') + '">EN</button><button data-lang="hi" class="' +
      (I18N.lang === 'hi' ? 'on' : '') + '">हिं</button></div>';
  }
  function bindLang() {
    U.$$('[data-lang]').forEach((b) => b.onclick = () => {
      I18N.set(b.dataset.lang);
      if (S.user) { renderShell(); App.go(S.view, S.params); } else renderLogin();
    });
  }

  // ---------- Shell ----------
  const EMP_NAV = [
    { v: 'empHome', i: '🏠', k: 'home' },
    { v: 'empAttendance', i: '📅', k: 'attendance' },
    { v: 'empTargets', i: '🎯', k: 'targets' },
    { v: 'empLearn', i: '📘', k: 'training' },
    { v: 'empMore', i: '☰', k: 'more' }
  ];
  const ADMIN_MENU = [
    { v: 'adminDashboard', i: '📊', k: 'dashboard' },
    { v: 'adminAttendance', i: '📅', k: 'attendance' },
    { v: 'adminLiveLoc', i: '📍', k: 'liveLocation' },
    { v: 'adminSalary', i: '💵', k: 'salary' },
    { v: 'adminHolidays', i: '🎉', k: 'holidays' },
    { v: 'adminEmployees', i: '👥', k: 'employees' },
    { v: 'adminRights', i: '🔐', k: 'rights' },
    { v: 'adminLoans', i: '💰', k: 'loans' },
    { v: 'adminLoanSettings', i: '⚙️', k: 'loanSettings' },
    { v: 'adminTargets', i: '🎯', k: 'targetsCampaigns' },
    { v: 'adminWallet', i: '💼', k: 'walletPayouts' },
    { v: 'adminTraining', i: '📘', k: 'training' },
    { v: 'adminExams', i: '📝', k: 'exams' },
    { v: 'adminProgress', i: '📈', k: 'staffProgress' },
    { v: 'cashier', i: '📒', k: 'paymentLedger' },
    { v: 'adminLetters', i: '⚠️', k: 'warningLetters' },
    { v: 'adminNotify', i: '🔔', k: 'notifications' },
    { v: 'adminIdRequests', i: '🪪', k: 'idCardRequests' },
    { v: 'adminDocs', i: '📁', k: 'documents' },
    { v: 'adminReports', i: '📑', k: 'reports' },
    { v: 'adminSettings', i: '🛠️', k: 'settings' }
  ];
  const ADMIN_NAV = [
    { v: 'adminDashboard', i: '📊', k: 'dashboard' },
    { v: 'adminAttendance', i: '📅', k: 'attendance' },
    { v: 'adminEmployees', i: '👥', k: 'employees' },
    { v: 'adminLoans', i: '💰', k: 'loans' },
    { v: '_menu', i: '☰', k: 'menu' }
  ];

  function renderShell() {
    const nav = S.isAdmin ? ADMIN_NAV : EMP_NAV;
    const name = S.isAdmin ? (S.user.name || 'Admin') : (S.emp.name || '');
    root().innerHTML =
      '<header class="topbar"><div class="brand" onclick="App.go(\'' + (S.isAdmin ? 'adminDashboard' : 'empHome') + '\')"><img src="img/logo.png" alt=""><div><b>' + esc(APP_INFO.showroom) +
      '</b><small>' + (S.isAdmin ? T('adminPanel') : esc(name)) + '</small></div></div>' +
      '<div class="top-actions">' + langSwitch() + '<button class="icon-btn bell" onclick="App.go(\'notifications\')">🔔<i id="notifDot"></i></button></div></header>' +
      (S.isAdmin ? '<aside id="drawer" class="drawer"><div class="drawer-head"><b>' + esc(name) + '</b><small>' + esc(S.user.email || '') + '</small></div>' +
        ADMIN_MENU.map((m) => '<a data-go="' + m.v + '"><span>' + m.i + '</span>' + T(m.k) + '</a>').join('') +
        '<a data-go="changePassword"><span>🔑</span>' + T('changePassword') + '</a><a onclick="App.logout()"><span>🚪</span>' + T('logout') + '</a></aside><div id="drawerBg" class="drawer-bg"></div>' : '') +
      '<main id="view" class="view"></main>' +
      '<nav class="bottomnav">' + nav.map((n) => '<a data-go="' + n.v + '"><span>' + n.i + '</span><small>' + T(n.k) + '</small></a>').join('') + '</nav>';
    bindLang();
    U.$$('[data-go]').forEach((a) => a.onclick = () => {
      if (a.dataset.go === '_menu') return toggleDrawer(true);
      toggleDrawer(false); App.go(a.dataset.go);
    });
    const bg = U.$('#drawerBg'); if (bg) bg.onclick = () => toggleDrawer(false);
    App.updateNotifDot();
  }
  function toggleDrawer(on) {
    const d = U.$('#drawer'), bg = U.$('#drawerBg');
    if (!d) return;
    d.classList.toggle('open', on); bg.classList.toggle('open', on);
  }

  App.go = async function (view, params) {
    S.view = view; S.params = params || null;
    U.$$('.modal-wrap').forEach((m) => m.remove());
    const el = U.$('#view'); if (!el) return;
    U.$$('.bottomnav a, .drawer a').forEach((a) => a.classList.toggle('on', a.dataset.go === view));
    const fn = V[view];
    if (!fn) { el.innerHTML = U.empty('Not found: ' + view); return; }
    el.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    window.scrollTo(0, 0);
    try { await fn(el, params || {}); }
    catch (e) {
      console.error(e);
      el.innerHTML = '<div class="card"><h3>' + T('error') + '</h3><p>' + esc(e.message || e) + '</p><button class="btn" onclick="App.go(S.view,S.params)">' + T('retry') + '</button></div>';
    }
  };
  App.refresh = () => App.go(S.view, S.params);

  App.logout = async function () {
    if (await U.confirm(T('logoutConfirm'), T('logout'))) { await DB.signOut(); }
  };

  // ---------- Notifications (in-app, realtime) ----------
  S.notifs = [];
  App.watchNotifications = function () {
    const w = S.isAdmin ? [] : [['target', 'in', ['all', S.user.empId]]];
    S.unsubs.push(DB.watch('notifications', w, (list) => {
      const prevIds = new Set(S.notifs.map((n) => n.id));
      const firstLoad = !S._notifLoaded; S._notifLoaded = true;
      S.notifs = list.sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
      App.updateNotifDot();
      if (!firstLoad) {
        const fresh = S.notifs.filter((n) => !prevIds.has(n.id));
        if (fresh.length && !S.isAdmin) U.toast('🔔 ' + fresh[0].title, 'info');
      }
    }));
    if (!S.isAdmin) {
      S.unsubs.push(DB.watch('warnings', [['empId', '==', S.user.empId]], (list) => {
        S.warnings = list; App.updateNotifDot();
      }));
    }
  };
  App.lastSeenKey = () => 'notifSeen_' + (DB.auth.currentUser && DB.auth.currentUser.uid);
  App.updateNotifDot = function () {
    const dot = U.$('#notifDot'); if (!dot) return;
    let seen = 0; try { seen = Number(localStorage.getItem(App.lastSeenKey()) || 0); } catch (e) { }
    const unread = (S.isAdmin ? [] : S.notifs).filter((n) => (U.toDate(n.at) || new Date()).getTime() > seen).length +
      ((S.warnings || []).filter((w) => !w.readAt).length);
    dot.textContent = unread ? (unread > 9 ? '9+' : unread) : '';
    dot.style.display = unread ? 'flex' : 'none';
  };

  V.notifications = async function (el) {
    try { localStorage.setItem(App.lastSeenKey(), String(Date.now())); } catch (e) { }
    App.updateNotifDot();
    const list = S.notifs.filter((n) => S.isAdmin || n.target === 'all' || n.target === S.user.empId);
    el.innerHTML = '<h2 class="page-title">' + T('notifications') + '</h2>' +
      (S.isAdmin ? '<button class="btn" onclick="App.go(\'adminNotify\')">+ ' + T('sendNotification') + '</button>' : '') +
      (list.length ? list.map((n) => '<div class="card notif"><div class="row-between"><b>' + esc(n.title) + '</b><small class="muted">' + U.fmtDT(n.at) +
        '</small></div><p>' + esc(n.body).replace(/\n/g, '<br>') + '</p>' + (S.isAdmin ? '<small class="muted">' + T('to') + ': ' + esc(n.target === 'all' ? T('allEmployees') : (n.targetName || n.target)) + '</small>' : '') + '</div>').join('') : U.empty());
  };

  V.changePassword = async function (el) {
    el.innerHTML = '<h2 class="page-title">' + T('changePassword') + '</h2><form id="cpf" class="card form">' +
      U.field('old', T('oldPassword'), '', { type: 'password', required: true }) +
      U.field('n1', T('newPassword'), '', { type: 'password', required: true }) +
      U.field('n2', T('confirmPassword'), '', { type: 'password', required: true }) +
      '<button class="btn block">' + T('save') + '</button></form>';
    U.$('#cpf').onsubmit = async (e) => {
      e.preventDefault(); const d = U.formData(e.target);
      if (d.n1.length < 6) return U.toast(T('pwdShort'), 'err');
      if (d.n1 !== d.n2) return U.toast(T('pwdMismatch'), 'err');
      U.loading(true);
      try { await DB.changePassword(d.old, d.n1); U.toast(T('saved'), 'ok'); App.go(S.isAdmin ? 'adminDashboard' : 'empMore'); }
      catch (err) { U.toast(friendlyAuthError(err), 'err'); }
      finally { U.loading(false); }
    };
  };

  // Shared helper: month select html
  App.monthSelect = function (id, value) {
    return '<select id="' + id + '" class="month-sel">' + U.monthOptions(18).map((m) => '<option value="' + m + '"' + (m === value ? ' selected' : '') + '>' + U.monthLabel(m) + '</option>').join('') + '</select>';
  };

  App.empAvatar = function (e, size) {
    size = size || 44;
    if (e && e.photo) return '<img class="avatar" style="width:' + size + 'px;height:' + size + 'px" src="' + esc(e.photo) + '" alt="">';
    const ini = String((e && e.name) || '?').split(' ').map((x) => x[0]).slice(0, 2).join('').toUpperCase();
    return '<span class="avatar ph" style="width:' + size + 'px;height:' + size + 'px;font-size:' + Math.round(size / 2.6) + 'px">' + esc(ini) + '</span>';
  };

  document.addEventListener('DOMContentLoaded', App.start);
  // Android back button closes modals / drawer
  document.addEventListener('backbutton', () => {
    const m = U.$$('.modal-wrap'); if (m.length) return m[m.length - 1].remove();
  });
})();
