// ---------- Loan documents: Sanction letter, DPN (ROI blank), Loan Agreement, Statement ----------
(function () {
  const P = window.PDF, H = P._, esc = U.esc, LN = window.Loan;
  const shop = () => S.settings.showroom || APP_INFO.showroom;
  const n2 = (v) => Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

  function vars(l) {
    const a = l.applicant || {}, t = LN.terms(l), g = l.guarantor || {};
    return {
      t, name: a.name || l.empName, empId: l.empId, father: a.fatherName || '________', address: a.address || '________', designation: a.designation || '',
      amount: n2(t.P), amountWords: U.numToWords(t.P), tenure: t.n, emi: n2(t.emi), netAmount: n2(t.net), charges: n2(t.charges), interest: '________',
      loanNo: l.loanNo || '-', date: U.fmtDate(l.approvedAt || new Date()), showroom: shop(), guarantor: g.name ? g.name + ' (' + g.empId + ')' : '-'
    };
  }
  function termsRows(l, v, withRoi) {
    const t = v.t;
    const rows = [['Loan No.', v.loanNo], ['Sanctioned Amount', 'Rs. ' + v.amount + ' (' + v.amountWords + ' Only)'], ['Tenure', t.n + ' months'], ['Monthly EMI', 'Rs. ' + v.emi]];
    if (withRoi) rows.push(['Rate of Interest', LN.roiText(t)], ['Total Interest', 'Rs. ' + n2(t.totalInterest)], ['Total Payable', 'Rs. ' + n2(t.totalPayable)]);
    rows.push(['Processing Fee', 'Rs. ' + n2(t.pf)], ['GST on Processing Fee', 'Rs. ' + n2(t.gst)], ['Documentation Charges', 'Rs. ' + n2(t.doc)], ['Stamp Duty', 'Rs. ' + n2(t.stamp)],
      ['Total Charges (deducted)', 'Rs. ' + n2(t.charges)], ['Net Amount to Account', 'Rs. ' + n2(t.net)]);
    if (l.firstEmiDate) rows.push(['First EMI Date', U.fmtDate(l.firstEmiDate)]);
    if (l.guarantor) rows.push(['Guarantor', v.guarantor]);
    return rows;
  }
  const tableHtml = (rows) => '<table class="tbl doc-tbl">' + rows.map((r) => '<tr><td>' + esc(r[0]) + '</td><td><b>' + esc(r[1]) + '</b></td></tr>').join('') + '</table>';
  function autoTable(doc, y, rows, head) {
    doc.autoTable({ startY: y, head: head ? [head] : undefined, body: rows.map((r) => r.map((c) => H.L(c))), theme: 'grid', styles: { fontSize: 9.5, cellPadding: 1.8 },
      headStyles: { fillColor: [218, 37, 29] }, columnStyles: head ? {} : { 0: { cellWidth: 70, fontStyle: 'bold', fillColor: [250, 246, 246] } }, margin: { left: 14, right: 14 } });
    return doc.lastAutoTable.finalY + 6;
  }
  const showRoiDocs = () => !!LN.settings().showRoi;

  // ---------- Sanction letter ----------
  P.showLoanLetter = function (l) {
    const v = vars(l), ls = LN.settings();
    const m = U.modal(T('sanctionLetter'), '<div class="letter">' + H.headHtml('LOAN SANCTION LETTER') +
      '<div class="row-between"><span>Ref: ' + esc(v.loanNo) + '</span><span>Date: ' + esc(v.date) + '</span></div>' +
      '<p>To,<br><b>' + esc(v.name) + '</b><br>' + esc(v.designation) + ' (Emp ID: ' + esc(v.empId) + ')</p><p><b>Subject: Sanction of Staff Loan</b></p>' +
      '<p>' + esc(U.fillTemplate(ls.letterTemplate, v)).replace(/\n/g, '<br>') + '</p>' + tableHtml(termsRows(l, v, showRoiDocs() || S.isAdmin)) +
      (ls.terms ? '<p class="small"><b>Terms &amp; Conditions</b><br>' + esc(ls.terms).replace(/\n/g, '<br>') + '</p>' : '') +
      '<div class="sig"><span>Borrower Signature</span><span>For ' + esc(v.showroom) + '<br>Authorised Signatory</span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.loanLetterPdf(l);
  };
  P.loanLetterPdf = async function (l) {
    const v = vars(l), ls = LN.settings();
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'LOAN SANCTION LETTER');
    const W = doc.internal.pageSize.getWidth();
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    doc.text('Ref: ' + H.L(v.loanNo), 14, y); doc.text('Date: ' + v.date, W - 14, y, { align: 'right' }); y += 9;
    y = H.paragraph(doc, 'To,\n' + v.name + '\n' + v.designation + ' (Emp ID: ' + v.empId + ')', y, 10.5) + 3;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.text('Subject: Sanction of Staff Loan', 14, y); y += 7;
    y = H.paragraph(doc, U.fillTemplate(ls.letterTemplate, v), y, 10) + 2;
    y = autoTable(doc, y, termsRows(l, v, showRoiDocs() || S.isAdmin));
    if (ls.terms) { if (y > 240) { doc.addPage(); y = 20; } doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5); doc.text('Terms & Conditions', 14, y); y = H.paragraph(doc, ls.terms, y + 5, 9); }
    if (y > 255) { doc.addPage(); y = 20; }
    H.signature(doc, y, 'Borrower Signature', 'For ' + v.showroom + ' (Authorised Signatory)');
    await P.savePdf(doc, 'Sanction_Letter_' + safeName(v.loanNo) + '.pdf');
  };

  // ---------- DPN (ROI always blank) ----------
  P.showDPN = function (l) {
    const v = vars(l);
    const body = U.fillTemplate(LN.settings().dpnTemplate, v);
    const m = U.modal('DPN', '<div class="letter">' + H.headHtml('DEMAND PROMISSORY NOTE') +
      '<div class="row-between"><b>Rs. ' + esc(v.amount) + '/-</b><span>Date: ________</span></div><p>Place: ________________</p>' +
      '<p>' + esc(body).replace(/\n/g, '<br>') + '</p><div class="stamp">Revenue<br>Stamp</div>' +
      '<div class="sig"><span>Witness 1<br>Name: ____________</span><span>Signature of Borrower<br>' + esc(v.name) + '</span></div>' +
      '<div class="sig"><span>Witness 2<br>Name: ____________</span><span></span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.dpnPdf(l);
  };
  P.dpnPdf = async function (l) {
    const v = vars(l);
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'DEMAND PROMISSORY NOTE');
    const W = doc.internal.pageSize.getWidth();
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text('Rs. ' + v.amount + '/-', 14, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.text('Date: ____________', W - 14, y, { align: 'right' }); y += 7;
    doc.text('Place: ____________________', 14, y); y += 10;
    y = H.paragraph(doc, U.fillTemplate(LN.settings().dpnTemplate, v), y, 11.5) + 8;
    doc.rect(W - 44, y, 30, 30); doc.setFontSize(8); doc.text('Affix Revenue', W - 29, y + 13, { align: 'center' }); doc.text('Stamp', W - 29, y + 17, { align: 'center' });
    y += 40;
    H.signature(doc, y, 'Witness 1 (Name & Sign)', 'Signature of Borrower: ' + v.name);
    H.signature(doc, y + 22, 'Witness 2 (Name & Sign)', '');
    await P.savePdf(doc, 'DPN_' + safeName(v.loanNo) + '.pdf');
  };

  // ---------- Loan Agreement ----------
  P.showAgreement = function (l) {
    const v = vars(l), ls = LN.settings(), r1 = l.ref1 || {}, g = l.guarantor || {};
    const terms = String(ls.agreementTerms || '').split('\n').map((x) => x.trim()).filter(Boolean);
    const m = U.modal(T('loanAgreement'), '<div class="letter">' + H.headHtml('STAFF LOAN AGREEMENT') +
      '<p>This Loan Agreement is made on <b>' + esc(v.date) + '</b> at the office of <b>' + esc(v.showroom) + '</b> (the "Company") with <b>' + esc(v.name) + '</b>, S/o / D/o ' + esc(v.father) +
      ', Employee ID ' + esc(v.empId) + ', ' + esc(v.designation) + ', residing at ' + esc(v.address) + ' (the "Borrower")' + (g.name ? ', and <b>' + esc(g.name) + '</b>, Employee ID ' + esc(g.empId) + ' (the "Guarantor")' : '') + '.</p>' +
      '<h4>1. Loan Details</h4>' + tableHtml(termsRows(l, v, true)) +
      '<h4>2. References</h4><p>Reference 1: ' + esc(r1.name || '-') + ' (' + esc(r1.relation || '-') + '), Mob: ' + esc(r1.mobile || '-') + ', ' + esc(r1.address || '') + '<br>Reference 2 / Guarantor: ' + esc(v.guarantor) + '</p>' +
      '<h4>3. Terms &amp; Conditions</h4><ol class="small">' + terms.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ol>' +
      '<div class="sig"><span>Borrower</span><span>Guarantor</span></div><div class="sig"><span>Witness</span><span>For ' + esc(v.showroom) + '<br>Authorised Signatory</span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.agreementPdf(l);
  };
  P.agreementPdf = async function (l) {
    const v = vars(l), ls = LN.settings(), r1 = l.ref1 || {}, g = l.guarantor || {};
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'STAFF LOAN AGREEMENT');
    y = H.paragraph(doc, 'This Loan Agreement is made on ' + v.date + ' at the office of ' + v.showroom + ' (the "Company") with ' + v.name + ', S/o / D/o ' + v.father + ', Employee ID ' + v.empId + ', ' + v.designation +
      ', residing at ' + v.address + ' (the "Borrower")' + (g.name ? ', and ' + g.name + ', Employee ID ' + g.empId + ' (the "Guarantor")' : '') + '.', y, 10) + 3;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('1. Loan Details', 14, y); y += 3;
    y = autoTable(doc, y, termsRows(l, v, true));
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('2. Repayment Schedule', 14, y); y += 3;
    y = autoTable(doc, y, LN.terms(l).schedule.map((x) => [x.n, U.fmtDate(x.due), n2(x.emi), n2(x.principal), n2(x.interest), n2(x.balance)]), ['#', 'Due Date', 'EMI', 'Principal', 'Interest', 'Balance']);
    if (y > 240) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('3. References', 14, y); y += 6;
    y = H.paragraph(doc, 'Reference 1: ' + (r1.name || '-') + ' (' + (r1.relation || '-') + '), Mob: ' + (r1.mobile || '-') + ', ' + (r1.address || '') + '\nReference 2 / Guarantor: ' + v.guarantor, y, 10) + 3;
    if (y > 230) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('4. Terms & Conditions', 14, y); y += 6;
    const terms = String(ls.agreementTerms || '').split('\n').map((x) => x.trim()).filter(Boolean);
    y = H.paragraph(doc, terms.map((x, i) => (i + 1) + '. ' + x).join('\n'), y, 9.5) + 4;
    if (y > 235) { doc.addPage(); y = 20; }
    H.signature(doc, y, 'Borrower: ' + v.name, 'Guarantor: ' + (g.name || '________'));
    H.signature(doc, y + 24, 'Witness (Name & Sign)', 'For ' + v.showroom + ' (Authorised Signatory)');
    await P.savePdf(doc, 'Loan_Agreement_' + safeName(v.loanNo) + '.pdf');
  };

  // ---------- Loan statement ----------
  P.loanStatementPdf = async function (l) {
    const v = vars(l);
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'LOAN ACCOUNT STATEMENT');
    y = autoTable(doc, y, [['Borrower', v.name + ' (' + v.empId + ')'], ['Loan No.', v.loanNo], ['Loan Amount', 'Rs. ' + v.amount], ['EMI', 'Rs. ' + v.emi + ' x ' + v.tenure],
      ['Disbursed On', U.fmtDate(l.disbursedAt)], ['Outstanding', 'Rs. ' + n2(LN.outstanding(l))], ['Statement Date', U.fmtDate(new Date())]]);
    y = autoTable(doc, y, LN.ledgerRows(l).map((e) => [U.fmtDate(e.date), (I18N.dict.en['lt_' + e.type] || e.type) + (e.note ? ' - ' + e.note : '') + (e.mode ? ' [' + e.mode + (e.ref ? ' ' + e.ref : '') + ']' : ''),
      U.num(e.debit) ? n2(e.debit) : '', U.num(e.credit) ? n2(e.credit) : '', n2(e.balance)]), ['Date', 'Particulars', 'Debit', 'Credit', 'Balance']);
    await P.savePdf(doc, 'Loan_Statement_' + safeName(v.loanNo) + '.pdf');
  };
})();
