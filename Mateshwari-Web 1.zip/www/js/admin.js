// ---------- Admin views ----------
(function () {
  const V = window.Views, esc = U.esc;
  const A = window.Admin = {};

  const RIGHTS = [
    ['editProfile', 'r_editProfile'], ['docsView', 'r_docsView'], ['docsAdd', 'r_docsAdd'], ['docsEdit', 'r_docsEdit'], ['docsApprove', 'r_docsApprove'],
    ['applyLoan', 'r_applyLoan'], ['cashier', 'r_cashier'], ['approveAttendance', 'r_approveAttendance']
  ];
  A.defaultRights = () => ({ editProfile: false, docsView: true, docsAdd: true, docsEdit: false, docsApprove: false, applyLoan: false, cashier: false, approveAttendance: false, idCardLimit: 1 });

  // ---------- data helpers ----------
  A.employees = async function (includeInactive) {
    const l = await DB.all('employees');
    return l.filter((e) => includeInactive || e.active !== false).sort((a, b) => String(a.id).localeCompare(String(b.id), undefined, { numeric: true }));
  };

  // Attendance summary per employee for a month
  A.attSummary = function (emps, att, month, hol) {
    return emps.map((e) => Cal.summary(e, att.filter((a) => a.empId === e.id), month, hol));
  };

  // Salary computation
  A.salaryRows = async function (month) {
    const [emps, sal, att, pays, adj, loans, hol] = await Promise.all([
      A.employees(true), DB.all('salary'), DB.query('attendance', [['month', '==', month]]),
      DB.query('payments', [['month', '==', month]]), DB.query('payroll', [['month', '==', month]]), DB.query('loans', [['status', 'in', ['approved', 'disbursed']]]),
      Cal.holidays(month)
    ]);
    const D = U.daysInMonth(month);
    const sm = {}; sal.forEach((s) => { sm[s.id] = s; });
    const am = {}; adj.forEach((a) => { am[a.empId] = a; });
    const sum = A.attSummary(emps, att, month, hol);
    return sum.filter((r) => r.emp.active !== false || r.present > 0).map((r) => {
      const e = r.emp, monthly = U.num((sm[e.id] || {}).monthly);
      const a = am[e.id] || {};
      const paidSun = r.paidWO, paidHol = r.paidHol;
      const extra = U.num(a.extraDays);
      const payable = r.present + paidSun + paidHol + extra;
      const perDay = monthly / D;
      const earned = U.round2(perDay * payable);
      const activeLoanEmi = loans.filter((l) => l.empId === e.id && !l.closed && l.disbursedAt && String(l.disbursedAt).slice(0, 7) < month).reduce((s, l) => s + U.num(l.emi), 0);
      const emi = a.loanEmi != null && a.loanEmi !== '' ? U.num(a.loanEmi) : activeLoanEmi;
      const bonus = U.num(a.bonus), ded = U.num(a.deduction);
      const paid = pays.filter((p) => p.empId === e.id).reduce((s, p) => s + U.num(p.amount), 0);
      const net = U.round2(earned + bonus - ded - emi - paid);
      return { emp: e, monthly, perDay: U.round2(perDay), present: r.present, half: r.half, paidSun, paidHol, extra, payable, earned, bonus, ded, emi, paid, net, adj: a, pct: r.pct };
    });
  };

  // ========== DASHBOARD ==========
  V.adminDashboard = async function (el, p) {
    const month = p.month || U.monthKey();
    const today = U.dateKey();
    const [emps, att, loans, idReq, docs, todayAtt] = await Promise.all([
      A.employees(), DB.query('attendance', [['month', '==', month]]), DB.all('loans'),
      DB.query('idRequests', [['status', '==', 'pending']]), DB.query('documents', [['status', '==', 'pending']]),
      DB.query('attendance', [['date', '==', today]])
    ]);
    const hol = await Cal.holidays(month);
    const sum = A.attSummary(emps, att, month, hol).sort((a, b) => b.pct - a.pct);
    const pendingAtt = att.filter((a) => a.status === 'pending').length;
    const pendingLoans = loans.filter((l) => l.status === 'applied' || l.status === 'in_process').length;
    const inToday = todayAtt.filter((a) => a.checkIn).length;
    const avg = sum.length ? Math.round(sum.reduce((s, r) => s + r.pct, 0) / sum.length) : 0;
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('dashboard') + '</h2>' + App.monthSelect('dm', month) + '</div>' +
      '<div class="dash-grid">' +
      dtile('👥', emps.length, T('totalStaff'), 'adminEmployees') +
      dtile('✅', inToday + ' / ' + emps.length, T('presentToday'), 'adminAttendance', { tab: 'today' }) +
      dtile('⏳', pendingAtt, T('pendingAttendance'), 'adminAttendance', { tab: 'approve' }, pendingAtt) +
      dtile('💰', pendingLoans, T('pendingLoans'), 'adminLoans', null, pendingLoans) +
      dtile('🪪', idReq.length, T('idCardRequests'), 'adminIdRequests', null, idReq.length) +
      dtile('📁', docs.length, T('pendingDocs'), 'adminDocs', null, docs.length) +
      '</div>' +
      '<div class="card"><div class="row-between"><h3>' + T('employeeWiseAttendance') + '</h3><span class="pill">' + T('avg') + ' ' + avg + '%</span></div>' +
      '<p class="muted small">' + U.monthLabel(month) + ' · ' + T('workingDaysNote').replace('{n}', sum[0] ? sum[0].working : 0) + '</p>' +
      (sum.length ? sum.map((r) => '<div class="pct-row" onclick="App.go(\'adminEmpDetail\',{id:\'' + esc(r.emp.id) + '\'})">' + App.empAvatar(r.emp, 34) +
        '<div class="grow"><div class="row-between"><b>' + esc(r.emp.name) + '</b><b class="' + pctCls(r.pct) + '">' + r.pct + '%</b></div>' +
        '<div class="bar"><i class="' + pctCls(r.pct) + '" style="width:' + r.pct + '%"></i></div><small class="muted">' + T('present') + ' ' + r.present + ' · ' + T('pending') + ' ' + r.pending +
        ' · ' + T('rejected') + ' ' + r.rejected + '</small></div></div>').join('') : U.empty(T('noEmployees'))) + '</div>' +
      '<div class="row-btns"><button class="btn ghost" onclick="App.go(\'adminReports\')">📑 ' + T('reports') + '</button><button class="btn ghost" onclick="App.go(\'adminSalary\')">💵 ' + T('salary') + '</button></div>';
    U.$('#dm').onchange = (e) => App.go('adminDashboard', { month: e.target.value });
    U.$$('[data-dgo]').forEach((t) => t.onclick = () => App.go(t.dataset.dgo, t.dataset.p ? JSON.parse(t.dataset.p) : null));
  };
  const pctCls = (p) => p >= 90 ? 'good' : p >= 70 ? 'mid' : 'low';
  function dtile(icon, val, label, go, params, alert) {
    return '<a class="dtile card' + (alert ? ' alert' : '') + '" data-dgo="' + go + '"' + (params ? ' data-p=\'' + JSON.stringify(params) + '\'' : '') + '><span>' + icon + '</span><b>' + val + '</b><small>' + esc(label) + '</small></a>';
  }

  // ========== ATTENDANCE ==========
  V.adminAttendance = async function (el, p) {
    const tab = p.tab || 'approve';
    el.innerHTML = '<h2 class="page-title">' + T('attendance') + '</h2><div class="tabs">' +
      [['approve', T('approvals')], ['today', T('today')], ['manual', T('manualEntry')]].map((t) => '<button class="' + (t[0] === tab ? 'on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') +
      '</div><div id="tabBody"></div>';
    U.$$('[data-tab]').forEach((b) => b.onclick = () => App.go('adminAttendance', { tab: b.dataset.tab }));
    const body = U.$('#tabBody');
    if (tab === 'approve') return V.attApprove(body, p);
    if (tab === 'today') return todayTab(body);
    return manualTab(body);
  };

  async function todayTab(el) {
    const [emps, att] = await Promise.all([A.employees(), DB.query('attendance', [['date', '==', U.dateKey()]])]);
    const m = {}; att.forEach((a) => { m[a.empId] = a; });
    const absent = emps.filter((e) => !m[e.id]);
    el.innerHTML = '<div class="stats4"><div><b>' + att.length + '</b><small>' + T('checkedIn') + '</small></div><div><b>' + att.filter((a) => a.checkOut).length +
      '</b><small>' + T('checkedOut') + '</small></div><div><b>' + absent.length + '</b><small>' + T('notCheckedIn') + '</small></div><div><b>' + emps.length + '</b><small>' + T('totalStaff') + '</small></div></div>' +
      '<div class="card list">' + emps.map((e) => {
        const a = m[e.id];
        return '<div class="li">' + App.empAvatar(e, 36) + '<div class="grow"><b>' + esc(e.name) + '</b><small>' + (a ? T('in') + ' ' + U.fmtTime(a.checkIn && a.checkIn.at) + ' · ' + T('out') + ' ' +
          (a.checkOut ? U.fmtTime(a.checkOut.at) : '-') : T('notCheckedIn')) + '</small></div>' + (a ? U.badge(a.status) : U.badge('absent')) + '</div>';
      }).join('') + '</div>';
  }

  async function manualTab(el) {
    const emps = await A.employees();
    el.innerHTML = '<form id="mf" class="card form"><p class="muted small">' + T('manualNote') + '</p>' +
      U.field('empId', T('employee'), '', { type: 'select', options: emps.map((e) => ({ v: e.id, l: e.name + ' (' + e.id + ')' })) }) +
      '<div class="grid2f">' + U.field('date', T('date'), U.dateKey(), { type: 'date', required: true }) +
      U.field('dayType', T('dayType'), 'full', { type: 'select', options: [{ v: 'full', l: T('fullDay') }, { v: 'half', l: T('halfDay') }, { v: 'absent', l: T('st_absent') + ' (' + T('delete') + ')' }] }) +
      U.field('inTime', T('checkIn'), S.settings.officeStart, { type: 'time' }) + U.field('outTime', T('checkOut'), S.settings.officeEnd, { type: 'time' }) + '</div>' +
      U.field('note', T('note'), '') + '<button class="btn block">' + T('save') + '</button></form>';
    U.$('#mf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const e = emps.find((x) => x.id === d.empId); if (!e) return;
      const id = e.id + '_' + d.date;
      U.loading(true);
      try {
        if (d.dayType === 'absent') { await DB.del('attendance', id); }
        else {
          const mk = (t) => t ? { at: new Date(d.date + 'T' + t + ':00').getTime(), manual: true } : null;
          const doc = {
            empId: e.id, empName: e.name, date: d.date, month: d.date.slice(0, 7), checkIn: mk(d.inTime), status: 'approved', dayType: d.dayType,
            manual: true, note: d.note || T('manualEntry'), reviewedBy: S.user.name || 'Admin', reviewedAt: DB.now(), createdAt: DB.now()
          };
          if (d.outTime) doc.checkOut = mk(d.outTime);
          await DB.set('attendance', id, doc);
        }
        U.toast(T('saved'), 'ok');
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
  }

  // ========== SALARY ==========
  V.adminSalary = async function (el, p) {
    const month = p.month || U.monthKey();
    const rows = await A.salaryRows(month);
    const tot = (k) => U.round2(rows.reduce((s, r) => s + U.num(r[k]), 0));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('salary') + '</h2>' + App.monthSelect('sm', month) + '</div>' +
      '<div class="note small">🔒 ' + T('salaryAdminOnly') + ' ' + T('salaryFormula') + '</div>' +
      '<div class="stats4"><div><b>' + U.money(tot('earned')) + '</b><small>' + T('earnedSalary') + '</small></div><div><b>' + U.money(tot('paid')) + '</b><small>' + T('paidAdvance') +
      '</small></div><div><b>' + U.money(tot('emi')) + '</b><small>' + T('loanEmi') + '</small></div><div><b>' + U.money(tot('net')) + '</b><small>' + T('netPayable') + '</small></div></div>' +
      '<div class="row-btns"><button class="btn ghost sm" id="sx">⬇ Excel</button><button class="btn ghost sm" id="sp">⬇ PDF</button></div>' +
      (rows.length ? rows.map((r) => '<div class="card sal-card" data-s="' + esc(r.emp.id) + '"><div class="row-between"><div class="row">' + App.empAvatar(r.emp, 36) + '<div><b>' + esc(r.emp.name) +
        '</b><br><small class="muted">' + T('monthlySalary') + ': ' + U.money(r.monthly) + (r.monthly ? '' : ' ⚠️') + '</small></div></div><div class="right"><small class="muted">' + T('netPayable') + '</small><br><b class="big ' + (r.net < 0 ? 'low' : '') + '">' + U.money(r.net) + '</b></div></div>' +
        '<div class="sal-grid"><span>' + T('presentDays') + '<b>' + r.present + '</b></span><span>' + T('paidWeeklyOff') + '<b>' + r.paidSun + '</b></span><span>' + T('paidHolidays') + '<b>' + r.paidHol + '</b></span><span>' + T('extraDays') + '<b>' + r.extra +
        '</b></span><span>' + T('payableDays') + '<b>' + r.payable + '</b></span><span>' + T('earnedSalary') + '<b>' + U.money(r.earned) + '</b></span><span>' + T('bonus') + '<b>' + U.money(r.bonus) +
        '</b></span><span>' + T('deduction') + '<b>' + U.money(r.ded) + '</b></span><span>' + T('loanEmi') + '<b>' + U.money(r.emi) + '</b></span><span>' + T('paidAdvance') + '<b>' + U.money(r.paid) + '</b></span></div>' +
        '<small class="muted">✏️ ' + T('tapToAdjust') + '</small></div>').join('') : U.empty(T('noEmployees')));
    U.$('#sm').onchange = (e) => App.go('adminSalary', { month: e.target.value });
    U.$$('[data-s]').forEach((c) => c.onclick = () => adjustSalary(rows.find((r) => r.emp.id === c.dataset.s), month));
    U.$('#sx').onclick = () => Reports.export('salary', month, 'xlsx');
    U.$('#sp').onclick = () => Reports.export('salary', month, 'pdf');
  };

  function adjustSalary(r, month) {
    const a = r.adj || {};
    const m = U.modal(r.emp.name + ' · ' + U.monthLabel(month), '<form class="form" id="adjf">' +
      U.field('monthly', T('monthlySalary'), r.monthly, { type: 'number' }) +
      U.field('extraDays', T('extraDays') + ' (' + T('paidLeave') + ')', a.extraDays || 0, { type: 'number', step: '0.5' }) +
      U.field('bonus', T('bonus') + ' / ' + T('incentive'), a.bonus || 0, { type: 'number' }) +
      U.field('deduction', T('deduction'), a.deduction || 0, { type: 'number' }) +
      U.field('loanEmi', T('loanEmi') + ' (' + T('blankAuto') + ')', a.loanEmi != null ? a.loanEmi : '', { type: 'number' }) +
      U.field('note', T('note'), a.note || '') + '<button class="btn block">' + T('save') + '</button></form>');
    U.$('#adjf', m.el).onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      U.loading(true);
      try {
        await DB.set('salary', r.emp.id, { monthly: U.num(d.monthly), updatedAt: DB.now() }, true);
        await DB.set('payroll', r.emp.id + '_' + month, {
          empId: r.emp.id, month, extraDays: U.num(d.extraDays), bonus: U.num(d.bonus), deduction: U.num(d.deduction),
          loanEmi: d.loanEmi === '' ? null : U.num(d.loanEmi), note: d.note, updatedAt: DB.now()
        });
        m.close(); U.toast(T('saved'), 'ok'); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  }

  // ========== EMPLOYEES ==========
  V.adminEmployees = async function (el, p) {
    const showInactive = !!p.inactive;
    const emps = await A.employees(true);
    const list = emps.filter((e) => showInactive ? e.active === false : e.active !== false);
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('employees') + '</h2><button class="btn" onclick="App.go(\'adminEmpEdit\')">+ ' + T('addEmployee') + '</button></div>' +
      '<input id="es" class="search" placeholder="🔍 ' + T('search') + '">' +
      '<div class="chips"><button class="chip ' + (showInactive ? '' : 'on') + '" onclick="App.go(\'adminEmployees\')">' + T('active') + ' (' + emps.filter((e) => e.active !== false).length + ')</button>' +
      '<button class="chip ' + (showInactive ? 'on' : '') + '" onclick="App.go(\'adminEmployees\',{inactive:1})">' + T('inactive') + ' (' + emps.filter((e) => e.active === false).length + ')</button></div>' +
      '<div id="elist">' + (list.length ? list.map((e) => '<div class="card emp-row" data-id="' + esc(e.id) + '" data-q="' + esc((e.name + ' ' + e.id + ' ' + e.mobile + ' ' + (e.designation || '')).toLowerCase()) + '">' +
        App.empAvatar(e, 46) + '<div class="grow"><b>' + esc(e.name) + '</b><small>' + esc(e.id) + ' · ' + esc(e.designation || '') + ' · ' + esc(e.mobile || '') + '</small></div><i>›</i></div>').join('') : U.empty(T('noEmployees'))) + '</div>';
    U.$('#es').oninput = (ev) => { const q = ev.target.value.toLowerCase(); U.$$('.emp-row').forEach((r) => r.style.display = r.dataset.q.includes(q) ? '' : 'none'); };
    U.$$('.emp-row').forEach((r) => r.onclick = () => App.go('adminEmpDetail', { id: r.dataset.id }));
  };

  const PROFILE_FIELDS = [
    ['name', 'fullName', 'text', true], ['fatherName', 'fatherName'], ['mobile', 'mobile', 'tel', true], ['altMobile', 'altMobile', 'tel'], ['email', 'email', 'email'],
    ['designation', 'designation'], ['department', 'department'], ['joinDate', 'joinDate', 'date'], ['dob', 'dob', 'date'], ['bloodGroup', 'bloodGroup'],
    ['address', 'address', 'textarea'], ['emergencyContact', 'emergencyContact'], ['aadhaar', 'aadhaar'], ['pan', 'pan'], ['bankName', 'bankName'], ['accountNo', 'accountNo'], ['ifsc', 'IFSC']
  ];

  async function nextEmpId() {
    const emps = await A.employees(true);
    let max = 0; emps.forEach((e) => { const n = parseInt(String(e.id).replace(/\D/g, '')) || 0; if (n > max) max = n; });
    return 'MA' + String(max + 1).padStart(3, '0');
  }

  V.adminEmpEdit = async function (el, p) {
    const isNew = !p.id;
    const e = isNew ? { id: await nextEmpId(), joinDate: U.dateKey() } : await DB.get('employees', p.id);
    const sal = isNew ? {} : ((await DB.get('salary', p.id)) || {});
    let photo = e.photo || '';
    el.innerHTML = '<h2 class="page-title">' + (isNew ? T('addEmployee') : T('editEmployee')) + '</h2><form id="ef" class="form">' +
      '<div class="card center"><div id="ph">' + App.empAvatar(Object.assign({}, e, { photo }), 96) + '</div><button type="button" class="btn ghost sm" id="phb">📷 ' + T('uploadPhoto') + '</button>' +
      (photo ? ' <button type="button" class="btn ghost sm" id="phr">🗑</button>' : '') + '</div>' +
      '<div class="card"><h3>' + T('basicDetails') + '</h3>' +
      U.field('id', T('employeeId'), e.id, { readonly: !isNew, required: true }) +
      PROFILE_FIELDS.map((f) => U.field(f[0], T(f[1]), e[f[0]], { type: f[2], required: f[3] })).join('') +
      U.field('weeklyOff', T('weeklyOff'), e.weeklyOff == null ? '' : e.weeklyOff, { type: 'select', options: Cal.weeklyOffOptions(true) }) + '</div>' +
      '<div class="card"><h3>🔒 ' + T('salaryDetails') + '</h3>' + U.field('monthly', T('monthlySalary') + ' (₹)', sal.monthly || '', { type: 'number' }) + '<p class="muted small">' + T('salaryAdminOnly') + '</p></div>' +
      (isNew ? '<div class="card"><h3>🔑 ' + T('loginDetails') + '</h3><p class="muted small">' + T('loginNote') + '</p>' + U.field('password', T('password'), '', { type: 'text', required: true, placeholder: 'min 6' }) + '</div>' : '') +
      '<button class="btn block">' + T('save') + '</button></form>';
    const setPh = () => { U.$('#ph').innerHTML = App.empAvatar(Object.assign({}, e, { photo }), 96); };
    U.$('#phb').onclick = async () => {
      const f = await U.pickFile('image/*'); if (!f) return;
      try { photo = await U.compressImage(f, 360, 0.8); setPh(); } catch (er) { U.toast(er.message, 'err'); }
    };
    const pr = U.$('#phr'); if (pr) pr.onclick = () => { photo = ''; setPh(); };
    U.$('#ef').onsubmit = async (ev) => {
      ev.preventDefault();
      const d = U.formData(ev.target);
      const id = String(d.id).trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
      if (!id) return U.toast(T('employeeId') + '?', 'err');
      const mobile = String(d.mobile).replace(/\D/g, '');
      if (mobile.length !== 10) return U.toast(T('invalidMobile'), 'err');
      const data = { photo };
      PROFILE_FIELDS.forEach((f) => { data[f[0]] = d[f[0]] || ''; });
      data.weeklyOff = d.weeklyOff === '' ? '' : Number(d.weeklyOff);
      data.mobile = mobile;
      U.loading(true);
      try {
        if (isNew) {
          if (await DB.get('employees', id)) throw new Error(T('idExists'));
          if (await DB.get('logins', mobile)) throw new Error(T('mobileExists'));
          if (!d.password || d.password.length < 6) throw new Error(T('pwdShort'));
          const login = await DB.createStaffLogin(mobile, d.password);
          await DB.set('employees', id, Object.assign(data, { active: true, rights: A.defaultRights(), loanEligible: false, maxLoanAmount: 0, idPrintsUsed: 0, idExtraApproved: 0, loginUid: login.uid, loginEmail: login.email, createdAt: DB.now() }));
          await DB.set('users', login.uid, { role: 'employee', empId: id, active: true, createdAt: DB.now() });
          await DB.set('logins', mobile, { email: login.email, empId: id });
        } else {
          if (mobile !== e.mobile) throw new Error(T('mobileChangeHint'));
          await DB.update('employees', id, data);
        }
        await DB.set('directory', id, { name: data.name, designation: data.designation, active: isNew ? true : e.active !== false });
        await DB.set('salary', id, { monthly: U.num(d.monthly), updatedAt: DB.now() }, true);
        U.toast(T('saved'), 'ok');
        await App.go('adminEmpDetail', { id });
        if (isNew) {
          U.modal(T('employeeCreated'), '<p>' + T('shareLogin') + '</p><div class="kv">' + kvRow(T('loginId'), esc(mobile)) + kvRow(T('password'), esc(d.password)) + '</div>');
        }
      } catch (err) { U.toast(App.friendlyAuthError(err), 'err'); } finally { U.loading(false); }
    };
  };

  V.adminEmpDetail = async function (el, p) {
    const e = await DB.get('employees', p.id);
    if (!e) { el.innerHTML = U.empty(); return; }
    const tab = p.tab || 'profile';
    const sal = (await DB.get('salary', e.id)) || {};
    el.innerHTML = '<div class="profile-head card">' + App.empAvatar(e, 80) + '<h2>' + esc(e.name) + '</h2><small>' + esc(e.id) + ' · ' + esc(e.designation || '') + '</small>' +
      (e.active === false ? '<span class="badge bad">' + T('inactive') + '</span>' : '') + '</div>' +
      '<div class="tabs">' + [['profile', T('profile')], ['docs', T('documents')], ['attendance', T('attendance')], ['account', T('account')]].map((t) =>
        '<button class="' + (t[0] === tab ? 'on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="tb"></div>';
    U.$$('[data-tab]').forEach((b) => b.onclick = () => App.go('adminEmpDetail', { id: e.id, tab: b.dataset.tab }));
    const tb = U.$('#tb');
    if (tab === 'profile') {
      tb.innerHTML = '<div class="card kv">' + PROFILE_FIELDS.map((f) => kvRow(T(f[1]), esc(f[2] === 'date' ? U.fmtDate(e[f[0]]) : (e[f[0]] || '-')))).join('') +
        kvRow(T('weeklyOff'), esc(Cal.weeklyOff(e) < 0 ? T('noWeeklyOff') : Cal.dayName(Cal.weeklyOff(e)))) + kvRow('🔒 ' + T('monthlySalary'), U.money(sal.monthly)) + '</div>' +
        '<div class="row-btns"><button class="btn" onclick="App.go(\'adminEmpEdit\',{id:\'' + esc(e.id) + '\'})">✏️ ' + T('edit') + '</button>' +
        '<button class="btn ghost" id="idc">🪪 ' + T('idCard') + '</button><button class="btn ghost" onclick="App.go(\'adminRights\',{id:\'' + esc(e.id) + '\'})">🔐 ' + T('rights') + '</button></div>';
      U.$('#idc').onclick = () => {
        const m = U.modal(T('idCard'), PDF.idCardHtml(e, S.settings) + '<button class="btn block" data-p>🖨️ ' + T('printIdCard') + '</button>', { wide: true });
        m.el.querySelector('[data-p]').onclick = () => PDF.idCardPdf(e, S.settings);
      };
    } else if (tab === 'docs') {
      const docs = await DB.query('documents', [['empId', '==', e.id]]);
      tb.innerHTML = '<button class="btn" id="ud">⬆️ ' + T('uploadDocument') + '</button>' + Docs.listHtml(docs, { admin: true });
      U.$('#ud').onclick = () => Docs.upload(e.id, e.name, true, App.refresh);
      Docs.bind(tb, docs, { admin: true, reload: App.refresh });
    } else if (tab === 'attendance') {
      const month = p.month || U.monthKey();
      const att = (await DB.query('attendance', [['empId', '==', e.id], ['month', '==', month]])).sort((a, b) => b.date.localeCompare(a.date));
      const s = A.attSummary([e], att, month, await Cal.holidays(month))[0];
      tb.innerHTML = '<div class="row-between">' + App.monthSelect('em', month) + '<b class="' + pctCls(s.pct) + '">' + s.pct + '%</b></div>' +
        '<div class="stats4"><div><b>' + s.present + '</b><small>' + T('present') + '</small></div><div><b>' + s.half + '</b><small>' + T('halfDay') + '</small></div><div><b>' + s.pending +
        '</b><small>' + T('pending') + '</small></div><div><b>' + s.rejected + '</b><small>' + T('rejected') + '</small></div></div>' +
        App.calendarHtml(e, month, att, await Cal.holidays(month)) +
        (att.length ? '<div class="card list">' + att.map((a) => '<div class="li"><div class="grow"><b>' + U.fmtDate(a.date) + '</b><small>' + T('in') + ' ' + (a.checkIn ? U.fmtTime(a.checkIn.at) : '-') + ' · ' + T('out') + ' ' +
          (a.checkOut ? U.fmtTime(a.checkOut.at) : '-') + (a.dayType === 'half' ? ' · ½' : '') + '</small></div>' + U.badge(a.status) + '</div>').join('') + '</div>' : U.empty());
      U.$('#em').onchange = (ev) => App.go('adminEmpDetail', { id: e.id, tab, month: ev.target.value });
    } else {
      tb.innerHTML = '<div class="card kv">' + kvRow(T('loginId'), esc(e.mobile)) + kvRow(T('status'), e.active === false ? T('inactive') : T('active')) +
        kvRow(T('idPrints'), (e.idPrintsUsed || 0) + ' / ' + ((Number((e.rights || {}).idCardLimit) || 0) + (Number(e.idExtraApproved) || 0))) + '</div>' +
        '<div class="card"><h3>' + T('resetLogin') + '</h3><p class="muted small">' + T('resetLoginNote') + '</p>' +
        '<button class="btn" id="rl">🔑 ' + T('resetLogin') + '</button></div>' +
        '<div class="card"><button class="btn ' + (e.active === false ? '' : 'danger') + '" id="act">' + (e.active === false ? T('activate') : T('deactivate')) + '</button></div>';
      U.$('#rl').onclick = () => resetLogin(e);
      U.$('#act').onclick = async () => {
        const on = e.active === false;
        if (!(await U.confirm(on ? T('activate') + '?' : T('deactivateConfirm')))) return;
        U.loading(true);
        try {
          await DB.update('employees', e.id, { active: on });
          await DB.set('directory', e.id, { name: e.name, designation: e.designation || '', active: on });
          if (e.loginUid) await DB.update('users', e.loginUid, { active: on });
          U.toast(T('saved'), 'ok'); App.refresh();
        } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
      };
    }
  };

  function resetLogin(e) {
    const m = U.modal(T('resetLogin'), '<form class="form" id="rlf">' + U.field('mobile', T('mobile') + ' (' + T('loginId') + ')', e.mobile, { type: 'tel', required: true }) +
      U.field('password', T('newPassword'), '', { required: true }) + '<button class="btn block">' + T('save') + '</button></form>');
    U.$('#rlf', m.el).onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const mobile = String(d.mobile).replace(/\D/g, '');
      if (mobile.length !== 10) return U.toast(T('invalidMobile'), 'err');
      if (d.password.length < 6) return U.toast(T('pwdShort'), 'err');
      U.loading(true);
      try {
        if (mobile !== e.mobile) { const ex = await DB.get('logins', mobile); if (ex && ex.empId !== e.id) throw new Error(T('mobileExists')); }
        const login = await DB.createStaffLogin(mobile, d.password);
        await DB.set('users', login.uid, { role: 'employee', empId: e.id, active: e.active !== false, createdAt: DB.now() });
        if (e.loginUid) { try { await DB.update('users', e.loginUid, { active: false, replacedBy: login.uid }); } catch (x) { } }
        if (mobile !== e.mobile && e.mobile) { try { await DB.del('logins', e.mobile); } catch (x) { } }
        await DB.set('logins', mobile, { email: login.email, empId: e.id });
        await DB.update('employees', e.id, { loginUid: login.uid, loginEmail: login.email, mobile });
        m.close();
        await App.refresh();
        U.modal(T('loginUpdated'), '<div class="kv">' + kvRow(T('loginId'), esc(mobile)) + kvRow(T('password'), esc(d.password)) + '</div>');
      } catch (err) { U.toast(App.friendlyAuthError(err), 'err'); } finally { U.loading(false); }
    };
  }

  // ========== RIGHTS ==========
  V.adminRights = async function (el, p) {
    let emps = await A.employees();
    if (p.id) emps = emps.filter((e) => e.id === p.id);
    el.innerHTML = '<h2 class="page-title">' + T('employeeRights') + '</h2><p class="muted small">' + T('rightsNote') + '</p>' +
      (p.id ? '<button class="btn ghost sm" onclick="App.go(\'adminRights\')">' + T('allEmployees') + '</button>' : '') +
      (emps.length ? emps.map((e) => {
        const r = Object.assign(A.defaultRights(), e.rights || {});
        return '<form class="card form rights" data-r="' + esc(e.id) + '"><div class="row">' + App.empAvatar(e, 36) + '<b class="grow">' + esc(e.name) + ' <small class="muted">' + esc(e.id) + '</small></b></div>' +
          '<div class="rights-grid">' + RIGHTS.map((x) => U.field(x[0], T(x[1]), r[x[0]], { type: 'checkbox' })).join('') + '</div>' +
          '<div class="grid2f">' + U.field('idCardLimit', T('idCardLimit'), r.idCardLimit, { type: 'number', min: 0 }) +
          U.field('loanEligible', T('loanEligible'), e.loanEligible, { type: 'checkbox' }) +
          U.field('maxLoanAmount', T('maxLoanAmount') + ' (₹)', e.maxLoanAmount || '', { type: 'number', min: 0 }) + '</div>' +
          '<button class="btn sm">' + T('save') + '</button></form>';
      }).join('') : U.empty(T('noEmployees')));
    U.$$('form[data-r]').forEach((f) => f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const rights = {}; RIGHTS.forEach((x) => { rights[x[0]] = !!d[x[0]]; }); rights.idCardLimit = U.num(d.idCardLimit);
      try {
        await DB.update('employees', f.dataset.r, { rights, loanEligible: !!d.loanEligible, maxLoanAmount: U.num(d.maxLoanAmount) });
        U.toast(T('saved'), 'ok');
      } catch (e) { U.toast(e.message, 'err'); }
    });
  };

  // ========== LOANS ==========
  V.adminLoans = async function (el, p) {
    const filter = p.filter || 'active';
    const loans = (await DB.all('loans')).sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    const fl = loans.filter((l) => filter === 'all' ? true : filter === 'active' ? (l.status === 'applied' || l.status === 'in_process') : l.status === filter);
    const cnt = (f) => loans.filter((l) => f === 'active' ? (l.status === 'applied' || l.status === 'in_process') : f === 'all' || l.status === f).length;
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('loans') + '</h2><button class="btn ghost sm" onclick="App.go(\'adminLoanSettings\')">⚙️ ' + T('loanSettings') + '</button></div>' +
      '<div class="chips">' + ['active', 'approved', 'rejected', 'all'].map((f) => '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' +
        T(f === 'active' ? 'inProcess' : f === 'all' ? 'all' : 'st_' + f) + ' (' + cnt(f) + ')</button>').join('') +
      '<button class="chip" onclick="App.go(\'adminRights\')">🔐 ' + T('eligibility') + '</button></div>' +
      (fl.length ? fl.map((l) => '<div class="card" data-l="' + l.id + '"><div class="row-between"><div><b>' + esc(l.empName) + '</b> <small class="muted">' + esc(l.empId) + '</small><br><small>' +
        U.money(l.approvedAmount || l.amount) + ' · ' + l.tenure + ' ' + T('months') + ' · ' + U.fmtDate(l.createdAt) + '</small></div>' + U.badge(l.status) + '</div>' + loanStepper(l) + '</div>').join('') : U.empty(T('noLoans')));
    U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('adminLoans', { filter: b.dataset.f }));
    U.$$('[data-l]').forEach((c) => c.onclick = () => App.go('adminLoanDetail', { id: c.dataset.l }));
  };

  V.adminLoanDetail = async function (el, p) {
    const l = await DB.get('loans', p.id);
    if (!l) { el.innerHTML = U.empty(); return; }
    const ap = l.applicant || {};
    const steps = l.steps || [];
    const open = l.status === 'applied' || l.status === 'in_process';
    const curStep = steps[l.step] || '';
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'adminLoans\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><div class="row-between"><h2>' + esc(l.empName) + '</h2>' + U.badge(l.status) + '</div>' + loanStepper(l) +
      '<div class="kv">' + kvRow(T('amountApplied'), U.money(l.amount)) + (l.approvedAmount ? kvRow(T('amountApproved'), U.money(l.approvedAmount)) : '') +
      kvRow(T('tenure'), l.tenure + ' ' + T('months')) + kvRow(T('interest'), (l.interest || 0) + '%') + kvRow('EMI', U.money(l.emi)) + kvRow(T('purpose'), esc(l.purpose)) +
      (l.loanNo ? kvRow(T('loanNo'), esc(l.loanNo)) : '') + (l.disbursedAt ? kvRow(T('disbursedOn'), U.fmtDate(l.disbursedAt)) : '') + '</div></div>' +
      (open ? '<div class="card action-card"><h3>' + T('currentStep') + ': ' + esc(curStep) + ' (' + (l.step + 1) + '/' + steps.length + ')</h3>' +
        '<form class="form" id="laf">' + '<div class="grid2f">' + U.field('approvedAmount', T('amountApproved'), l.approvedAmount || l.amount, { type: 'number' }) +
        U.field('interest', T('interest') + ' %', l.interest || 0, { type: 'number', step: '0.01' }) + U.field('tenure', T('tenureMonths'), l.tenure, { type: 'number', min: 1 }) + '</div>' +
        U.field('note', T('remarks'), '', { type: 'textarea', rows: 2 }) +
        '<div class="row-btns"><button class="btn danger" type="button" id="lrej">✕ ' + T('reject') + '</button><button class="btn" type="submit">✔ ' +
        (l.step >= steps.length - 1 ? T('finalApprove') : T('approveStep')) + '</button></div></form></div>' : '') +
      (l.status === 'approved' ? '<div class="card"><div class="row-btns left"><button class="btn" id="vl">📄 ' + T('approvalLetter') + '</button><button class="btn" id="vd">📝 DPN</button>' +
        (!l.disbursedAt ? '<button class="btn ghost" id="dis">💸 ' + T('markDisbursed') + '</button>' : '') +
        (!l.closed ? '<button class="btn ghost" id="cls">🔒 ' + T('closeLoan') + '</button>' : '<span class="badge muted">' + T('st_closed') + '</span>') + '</div></div>' : '') +
      '<div class="card"><h3>' + T('applicantDetails') + '</h3><div class="kv">' + Object.keys(ap).map((k) => kvRow(T(k === 'id' ? 'employeeId' : k === 'ifsc' ? 'IFSC' : k === 'name' ? 'fullName' : k), esc(ap[k] || '-'))).join('') +
      Object.keys(l.custom || {}).map((k) => kvRow(l.custom[k].label, esc(l.custom[k].value || '-'))).join('') + '</div></div>' +
      '<div class="card"><h3>' + T('timeline') + '</h3><div class="timeline">' + (l.history || []).slice().reverse().map((h) => '<div><b>' + esc(h.step) + '</b> — ' + esc(T('st_' + h.status)) +
        '<small class="muted"> · ' + esc(h.by || '') + ' · ' + U.fmtDT(h.at) + '</small>' + (h.note ? '<br><small>' + esc(h.note) + '</small>' : '') + '</div>').join('') + '</div></div>';

    const by = S.user.name || 'Admin';
    const f = U.$('#laf');
    if (f) {
      f.onsubmit = async (ev) => {
        ev.preventDefault(); const d = U.formData(f);
        const last = l.step >= steps.length - 1;
        if (!(await U.confirm((last ? T('finalApprove') : T('approveStep')) + ': ' + curStep + '?', T('approve')))) return;
        const amt = U.num(d.approvedAmount) || l.amount, rate = U.num(d.interest), ten = Math.max(1, parseInt(d.tenure) || l.tenure);
        const upd = {
          approvedAmount: amt, interest: rate, tenure: ten, emi: U.emi(amt, rate, ten),
          history: (l.history || []).concat([{ step: curStep, status: 'approved', at: Date.now(), by, note: d.note }])
        };
        if (last) {
          upd.status = 'approved'; upd.approvedAt = DB.now(); upd.step = steps.length;
          upd.loanNo = await nextLoanNo();
        } else { upd.status = 'in_process'; upd.step = l.step + 1; }
        U.loading(true);
        try {
          await DB.update('loans', l.id, upd);
          await DB.add('notifications', {
            target: l.empId, targetName: l.empName, title: last ? T('loanApprovedTitle') : T('loanUpdateTitle'),
            body: last ? T('loanApprovedBody').replace('{a}', U.money(amt)) : T('loanStepBody').replace('{s}', curStep), at: DB.now(), by
          });
          U.toast(T('saved'), 'ok'); App.refresh();
        } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      };
      U.$('#lrej').onclick = async () => {
        const note = await U.prompt(T('reject'), T('reason'), '', 'textarea'); if (note == null) return;
        U.loading(true);
        try {
          await DB.update('loans', l.id, { status: 'rejected', rejectedAt: DB.now(), history: (l.history || []).concat([{ step: curStep, status: 'rejected', at: Date.now(), by, note }]) });
          await DB.add('notifications', { target: l.empId, targetName: l.empName, title: T('loanRejectedTitle'), body: note || '-', at: DB.now(), by });
          App.refresh();
        } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      };
    }
    const vl = U.$('#vl'); if (vl) vl.onclick = () => PDF.showLoanLetter(l);
    const vd = U.$('#vd'); if (vd) vd.onclick = () => PDF.showDPN(l);
    const dis = U.$('#dis');
    if (dis) dis.onclick = async () => {
      const dt = await U.prompt(T('markDisbursed'), T('date'), U.dateKey(), 'date'); if (!dt) return;
      await DB.update('loans', l.id, { disbursedAt: dt, history: (l.history || []).concat([{ step: T('disbursed'), status: 'disbursed', at: Date.now(), by }]) });
      App.refresh();
    };
    const cls = U.$('#cls');
    if (cls) cls.onclick = async () => {
      if (!(await U.confirm(T('closeLoanConfirm')))) return;
      await DB.update('loans', l.id, { closed: true, closedAt: DB.now(), history: (l.history || []).concat([{ step: T('closeLoan'), status: 'closed', at: Date.now(), by }]) });
      App.refresh();
    };
  };

  async function nextLoanNo() {
    const y = new Date().getFullYear();
    const all = await DB.all('loans');
    const n = all.filter((x) => x.loanNo && x.loanNo.includes('/' + y + '/')).length + 1;
    return 'MA/LN/' + y + '/' + String(n).padStart(3, '0');
  }

  V.adminLoanSettings = async function (el) {
    const s = S.loanSettings;
    el.innerHTML = '<h2 class="page-title">' + T('loanSettings') + '</h2><form id="lsf" class="form">' +
      '<div class="card">' + U.field('enabled', T('loanModuleOn'), s.enabled, { type: 'checkbox' }) +
      '<div class="grid2f">' + U.field('interest', T('interest') + ' % p.a.', s.interest, { type: 'number', step: '0.01' }) + U.field('maxAmount', T('maxLoanAmount') + ' (₹)', s.maxAmount, { type: 'number' }) +
      U.field('maxTenure', T('maxTenure'), s.maxTenure, { type: 'number', min: 1 }) + U.field('minServiceMonths', T('minService'), s.minServiceMonths, { type: 'number' }) + '</div></div>' +
      '<div class="card"><h3>' + T('approvalSteps') + '</h3><p class="muted small">' + T('stepsNote') + '</p>' + U.field('steps', T('onePerLine'), (s.steps || []).join('\n'), { type: 'textarea', rows: 5 }) + '</div>' +
      '<div class="card"><h3>' + T('customFields') + '</h3><p class="muted small">' + T('customFieldsNote') + '</p>' +
      U.field('customFields', T('onePerLine'), (s.customFields || []).map((c) => c.label + ' | ' + c.type + (c.required ? ' | required' : '')).join('\n'), { type: 'textarea', rows: 4 }) + '</div>' +
      '<div class="card"><h3>' + T('letterTemplates') + '</h3><p class="muted small">' + T('placeholders') + ': {name} {empId} {father} {address} {amount} {amountWords} {interest} {tenure} {emi} {loanNo} {date} {showroom} {designation}</p>' +
      U.field('letterTemplate', T('approvalLetter'), s.letterTemplate, { type: 'textarea', rows: 8 }) +
      U.field('dpnTemplate', 'DPN', s.dpnTemplate, { type: 'textarea', rows: 5 }) +
      U.field('terms', T('terms'), s.terms, { type: 'textarea', rows: 4 }) + '</div>' +
      '<div class="row-btns"><button class="btn ghost" type="button" id="lsr">' + T('resetDefault') + '</button><button class="btn">' + T('save') + '</button></div></form>';
    U.$('#lsr').onclick = async () => {
      if (!(await U.confirm(T('resetDefault') + '?'))) return;
      await DB.set('settings', 'loan', DB.defaultLoanSettings()); S.loanSettings = DB.defaultLoanSettings(); App.refresh();
    };
    U.$('#lsf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const steps = d.steps.split('\n').map((x) => x.trim()).filter(Boolean);
      if (!steps.length) return U.toast(T('atLeastOneStep'), 'err');
      const customFields = d.customFields.split('\n').map((x) => x.trim()).filter(Boolean).map((line, i) => {
        const parts = line.split('|').map((x) => x.trim());
        const type = ['text', 'number', 'date', 'tel', 'textarea'].includes(parts[1]) ? parts[1] : 'text';
        return { key: 'f' + i + '_' + parts[0].toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 20), label: parts[0], type, required: /req/i.test(parts[2] || '') };
      });
      const ns = {
        enabled: !!d.enabled, interest: U.num(d.interest), maxAmount: U.num(d.maxAmount), maxTenure: Math.max(1, parseInt(d.maxTenure) || 1),
        minServiceMonths: U.num(d.minServiceMonths), steps, customFields, letterTemplate: d.letterTemplate, dpnTemplate: d.dpnTemplate, terms: d.terms
      };
      try { await DB.set('settings', 'loan', ns); S.loanSettings = Object.assign(DB.defaultLoanSettings(), ns); U.toast(T('saved'), 'ok'); }
      catch (e) { U.toast(e.message, 'err'); }
    };
  };

  // ========== WARNING LETTERS ==========
  const WARN_TPL = {
    late: ['Warning for Late Coming', 'It has been observed that you have been reporting late to duty on several occasions. This is against the discipline of the organisation. You are hereby warned to be punctual in future. Repetition may lead to strict disciplinary action including salary deduction.'],
    absent: ['Warning for Unauthorised Absence', 'It has been observed that you remained absent from duty without prior permission or information. This is a serious violation of company rules. You are hereby warned not to repeat such conduct in future, failing which strict action will be taken.'],
    conduct: ['Warning for Misconduct', 'Your behaviour/conduct at the workplace has been found unsatisfactory and against the code of conduct of the organisation. You are hereby warned to improve your conduct immediately. Any repetition will invite strict disciplinary action.'],
    performance: ['Warning for Poor Performance', 'Your work performance has not been up to the expected standard. You are advised to improve your performance and meet the targets assigned to you. Failure to improve may result in further action.']
  };
  V.adminLetters = async function (el) {
    const [emps, warns] = await Promise.all([A.employees(), DB.all('warnings')]);
    warns.sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    el.innerHTML = '<h2 class="page-title">' + T('warningLetters') + '</h2>' +
      '<form id="wf" class="card form"><h3>' + T('sendWarning') + '</h3>' +
      U.field('empId', T('employee'), '', { type: 'select', options: emps.map((e) => ({ v: e.id, l: e.name + ' (' + e.id + ')' })) }) +
      U.field('tpl', T('template'), '', { type: 'select', options: [{ v: '', l: '-- ' + T('custom') + ' --' }, { v: 'late', l: 'Late Coming' }, { v: 'absent', l: 'Absence' }, { v: 'conduct', l: 'Misconduct' }, { v: 'performance', l: 'Performance' }] }) +
      U.field('subject', T('subject'), '', { required: true }) + U.field('body', T('letterBody'), '', { type: 'textarea', rows: 6, required: true }) +
      '<button class="btn block">📤 ' + T('send') + '</button></form>' +
      '<h3 class="sec-title">' + T('sentLetters') + '</h3>' +
      (warns.length ? '<div class="card list">' + warns.map((w) => '<div class="li"><div class="grow"><b>' + esc(w.empName) + '</b><small>' + esc(w.subject) + ' · ' + U.fmtDate(w.at) + ' · ' + esc(w.refNo || '') +
        '</small></div>' + (w.readAt ? '<span class="badge ok">' + T('read') + '</span>' : U.badge('unread')) + '<button class="icon-btn" data-wv="' + w.id + '">👁</button><button class="icon-btn" data-wd="' + w.id + '">🗑</button></div>').join('') + '</div>' : U.empty());
    const f = U.$('#wf');
    f.tpl.onchange = () => { const t = WARN_TPL[f.tpl.value]; if (t) { f.subject.value = t[0]; f.body.value = t[1]; } };
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const e = emps.find((x) => x.id === d.empId); if (!e) return U.toast(T('selectEmployee'), 'err');
      if (!(await U.confirm(T('sendWarningConfirm').replace('{n}', e.name), T('send')))) return;
      U.loading(true);
      try {
        const refNo = 'MA/WL/' + new Date().getFullYear() + '/' + String(warns.length + 1).padStart(3, '0');
        await DB.add('warnings', { empId: e.id, empName: e.name, designation: e.designation || '', subject: d.subject, body: d.body, refNo, at: DB.now(), by: S.user.name || 'Admin' });
        await DB.add('notifications', { target: e.id, targetName: e.name, title: '⚠️ ' + d.subject, body: T('warningIssued'), at: DB.now(), by: S.user.name || 'Admin' });
        U.toast(T('sent'), 'ok'); App.refresh();
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
    U.$$('[data-wv]').forEach((b) => b.onclick = () => PDF.showWarning(warns.find((w) => w.id === b.dataset.wv)));
    U.$$('[data-wd]').forEach((b) => b.onclick = async () => { if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('warnings', b.dataset.wd); App.refresh(); } });
  };

  // ========== NOTIFICATIONS ==========
  V.adminNotify = async function (el) {
    const emps = await A.employees();
    const sent = S.notifs || [];
    el.innerHTML = '<h2 class="page-title">' + T('notifications') + '</h2><form id="nf" class="card form"><h3>' + T('sendNotification') + '</h3>' +
      U.field('target', T('sendTo'), 'all', { type: 'select', options: [{ v: 'all', l: '📢 ' + T('allEmployees') }].concat(emps.map((e) => ({ v: e.id, l: e.name + ' (' + e.id + ')' }))) }) +
      U.field('title', T('title'), '', { required: true }) + U.field('body', T('message'), '', { type: 'textarea', rows: 4, required: true }) +
      '<button class="btn block">📤 ' + T('send') + '</button></form><h3 class="sec-title">' + T('sent') + '</h3>' +
      (sent.length ? sent.map((n) => '<div class="card notif"><div class="row-between"><b>' + esc(n.title) + '</b><button class="icon-btn" data-nd="' + n.id + '">🗑</button></div><p>' + esc(n.body) +
        '</p><small class="muted">' + T('to') + ': ' + esc(n.target === 'all' ? T('allEmployees') : (n.targetName || n.target)) + ' · ' + U.fmtDT(n.at) + '</small></div>').join('') : U.empty());
    U.$('#nf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const e = emps.find((x) => x.id === d.target);
      try {
        await DB.add('notifications', { target: d.target, targetName: e ? e.name : 'All', title: d.title, body: d.body, at: DB.now(), by: S.user.name || 'Admin' });
        U.toast(T('sent'), 'ok'); setTimeout(App.refresh, 400);
      } catch (err) { U.toast(err.message, 'err'); }
    };
    U.$$('[data-nd]').forEach((b) => b.onclick = async () => { if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('notifications', b.dataset.nd); setTimeout(App.refresh, 300); } });
  };

  // ========== ID CARD REQUESTS ==========
  V.adminIdRequests = async function (el) {
    const reqs = (await DB.all('idRequests')).sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    el.innerHTML = '<h2 class="page-title">' + T('idCardRequests') + '</h2><p class="muted small">' + T('idReqNote') + '</p>' +
      (reqs.length ? reqs.map((r) => '<div class="card"><div class="row-between"><div><b>' + esc(r.empName) + '</b><br><small class="muted">' + U.fmtDT(r.at) + '</small></div>' + U.badge(r.status) + '</div>' +
        (r.reason ? '<p>' + esc(r.reason) + '</p>' : '') + (r.status === 'pending' ? '<div class="row-btns left"><button class="btn sm" data-ia="' + r.id + '">✔ ' + T('approve') +
          '</button><button class="btn sm danger" data-ir="' + r.id + '">✕ ' + T('reject') + '</button></div>' : '') + '</div>').join('') : U.empty());
    U.$$('[data-ia]').forEach((b) => b.onclick = async () => {
      const r = reqs.find((x) => x.id === b.dataset.ia);
      U.loading(true);
      try {
        await DB.update('employees', r.empId, { idExtraApproved: DB.inc(1) });
        await DB.update('idRequests', r.id, { status: 'approved', reviewedAt: DB.now() });
        await DB.add('notifications', { target: r.empId, targetName: r.empName, title: T('idApprovedTitle'), body: T('idApprovedBody'), at: DB.now(), by: S.user.name || 'Admin' });
        App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
    U.$$('[data-ir]').forEach((b) => b.onclick = async () => { await DB.update('idRequests', b.dataset.ir, { status: 'rejected', reviewedAt: DB.now() }); App.refresh(); });
  };

  // ========== DOCUMENTS (all) ==========
  V.adminDocs = async function (el, p) {
    const filter = p.filter || 'pending';
    let docs = filter === 'all' ? await DB.all('documents') : await DB.query('documents', [['status', '==', filter]]);
    el.innerHTML = '<h2 class="page-title">' + T('documents') + '</h2><div class="chips">' + ['pending', 'approved', 'rejected', 'all'].map((f) =>
      '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + T(f === 'all' ? 'all' : 'st_' + f) + '</button>').join('') + '</div>' +
      Docs.listHtml(docs, { admin: true, showEmp: true });
    U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('adminDocs', { filter: b.dataset.f }));
    Docs.bind(el, docs, { admin: true, reload: App.refresh });
  };

  // ========== HOLIDAYS ==========
  V.adminHolidays = async function (el, p) {
    const year = p.year || new Date().getFullYear();
    const list = (await DB.all('holidays')).filter((h) => String(h.date).startsWith(year + '-')).sort((a, b) => a.date.localeCompare(b.date));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">🎉 ' + T('holidays') + '</h2><select id="hy" class="month-sel">' + [year - 1, year, year + 1].map((y) => '<option' + (y === year ? ' selected' : '') + '>' + y + '</option>').join('') + '</select></div>' +
      '<p class="muted small">' + T('holidayNote') + '</p>' +
      '<form id="hf" class="card form"><h3>' + T('addHoliday') + '</h3><div class="grid2f">' + U.field('date', T('date'), '', { type: 'date', required: true }) +
      U.field('toDate', T('toDateOptional'), '', { type: 'date' }) + '</div>' + U.field('name', T('holidayName'), '', { required: true, placeholder: 'Diwali' }) +
      U.field('notify', T('notifyAllStaff'), true, { type: 'checkbox' }) + '<button class="btn block">' + T('save') + '</button></form>' +
      (list.length ? '<div class="card list">' + list.map((h) => '<div class="li"><div class="grow"><b>' + U.fmtDate(h.date) + ' · ' + esc(Cal.dayName(new Date(h.date + 'T00:00:00').getDay())) + '</b><small>' + esc(h.name) + '</small></div>' +
        '<button class="icon-btn" data-hd="' + h.id + '">🗑</button></div>').join('') + '</div>' : U.empty(T('noHolidays'))) +
      '<div class="card"><b>' + T('weeklyOff') + ':</b> ' + esc(Cal.showroomOff() < 0 ? T('noWeeklyOff') : Cal.dayName(Cal.showroomOff())) +
      ' <button class="btn ghost sm" onclick="App.go(\'adminSettings\')">' + T('change') + '</button></div>';
    U.$('#hy').onchange = (ev) => App.go('adminHolidays', { year: Number(ev.target.value) });
    U.$('#hf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const dates = []; const s0 = new Date(d.date + 'T00:00:00'); const s1 = d.toDate ? new Date(d.toDate + 'T00:00:00') : s0;
      if (s1 < s0) return U.toast(T('invalidRange'), 'err');
      for (let x = new Date(s0); x <= s1 && dates.length < 31; x.setDate(x.getDate() + 1)) dates.push(U.dateKey(x));
      U.loading(true);
      try {
        for (const dt of dates) await DB.set('holidays', dt, { date: dt, month: dt.slice(0, 7), name: d.name, at: DB.now() });
        if (d.notify) await DB.add('notifications', { target: 'all', targetName: 'All', title: '🎉 ' + T('holiday') + ': ' + d.name,
          body: U.fmtDate(dates[0]) + (dates.length > 1 ? ' – ' + U.fmtDate(dates[dates.length - 1]) : '') + ' · ' + T('holidayMsg'), at: DB.now(), by: S.user.name || 'Admin' });
        Cal.clearCache(); U.toast(T('saved'), 'ok'); App.go('adminHolidays', { year: Number(d.date.slice(0, 4)) });
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
    U.$$('[data-hd]').forEach((b) => b.onclick = async () => {
      if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return;
      await DB.del('holidays', b.dataset.hd); Cal.clearCache(); App.refresh();
    });
  };

  // ========== SETTINGS ==========
  V.adminSettings = async function (el) {
    const s = S.settings;
    el.innerHTML = '<h2 class="page-title">' + T('settings') + '</h2><form id="stf" class="form">' +
      '<div class="card"><h3>' + T('showroomDetails') + '</h3>' + U.field('showroom', T('showroomName'), s.showroom) + U.field('address', T('address'), s.address, { type: 'textarea', rows: 2 }) +
      U.field('phone', T('phone'), s.phone) + '</div>' +
      '<div class="card"><h3>📍 ' + T('gpsSettings') + '</h3><p class="muted small">' + T('gpsSetNote') + '</p>' +
      '<button type="button" class="btn ghost" id="useLoc">📍 ' + T('useCurrentLocation') + '</button>' +
      '<div class="grid2f">' + U.field('lat', 'Latitude', s.lat, { type: 'number', step: 'any' }) + U.field('lng', 'Longitude', s.lng, { type: 'number', step: 'any' }) +
      U.field('radius', T('radiusM'), s.radius, { type: 'number', min: 20 }) + '</div>' +
      U.field('blockOutside', T('blockOutside'), s.blockOutside, { type: 'checkbox' }) +
      U.field('liveTracking', T('liveTrackingSetting'), s.liveTracking !== false, { type: 'checkbox' }) +
      U.field('trackMins', T('trackEvery'), s.trackMins || 5, { type: 'number', min: 2 }) + '</div>' +
      '<div class="card"><h3>⏰ ' + T('timing') + '</h3><div class="grid2f">' + U.field('officeStart', T('officeStart'), s.officeStart, { type: 'time' }) + U.field('officeEnd', T('officeEnd'), s.officeEnd, { type: 'time' }) + '</div>' +
      U.field('weeklyOff', T('weeklyOff'), Cal.showroomOff(), { type: 'select', options: Cal.weeklyOffOptions(false) }) +
      '<p class="muted small">' + T('weeklyOffNote') + '</p><button type="button" class="btn ghost sm" onclick="App.go(\'adminHolidays\')">🎉 ' + T('holidays') + '</button></div>' +
      '<button class="btn block">' + T('save') + '</button></form>' +
      '<div class="card"><h3>' + T('adminAccount') + '</h3><div class="kv">' + kvRow(T('name'), esc(S.user.name || '')) + kvRow(T('email'), esc(S.user.email || '')) + '</div>' +
      '<div class="row-btns left"><button class="btn ghost" onclick="App.go(\'changePassword\')">🔑 ' + T('changePassword') + '</button><button class="btn ghost" onclick="App.logout()">🚪 ' + T('logout') + '</button></div></div>';
    const f = U.$('#stf');
    U.$('#useLoc').onclick = async () => {
      U.loading(true, T('gettingLocation'));
      try { const l = await U.getLocation(); f.lat.value = l.lat.toFixed(6); f.lng.value = l.lng.toFixed(6); U.toast('±' + l.acc + 'm', 'ok'); }
      catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const ns = {
        showroom: d.showroom || APP_INFO.showroom, address: d.address, phone: d.phone,
        lat: d.lat === '' ? null : Number(d.lat), lng: d.lng === '' ? null : Number(d.lng), radius: Math.max(20, U.num(d.radius) || 150),
        blockOutside: !!d.blockOutside, liveTracking: !!d.liveTracking, trackMins: Math.max(2, U.num(d.trackMins) || 5), weeklyOff: Number(d.weeklyOff), sundayPaid: Number(d.weeklyOff) === 0, officeStart: d.officeStart, officeEnd: d.officeEnd
      };
      try { await DB.set('settings', 'app', ns, true); Object.assign(S.settings, ns); U.toast(T('saved'), 'ok'); }
      catch (e) { U.toast(e.message, 'err'); }
    };
  };
})();
