// ---------- Training, exams (MCQ), attempts, certificates, progress ----------
(function () {
  const V = window.Views, esc = U.esc;
  const TR = window.Training = {};

  TR.assigned = (item, empId) => item.active !== false && (item.assignTo !== 'selected' || (item.empIds || []).includes(empId));
  TR.assignedCount = (item, emps) => emps.filter((e) => TR.assigned(item, e.id)).length;

  // score from answers (used everywhere so a tampered score field is ignored)
  TR.grade = function (exam, answers) {
    let score = 0, total = 0;
    (exam.questions || []).forEach((q, i) => {
      const mk = U.num(q.marks) || 1; total += mk;
      if (answers && answers[i] === q.ans) score += mk;
    });
    const pct = total ? Math.round(score / total * 1000) / 10 : 0;
    return { score, total, pct, passed: pct >= U.num(exam.passPct || 0) };
  };

  TR.bestAttempt = function (exam, attempts) {
    let best = null;
    attempts.filter((a) => a.status === 'submitted').forEach((a) => {
      const g = TR.grade(exam, a.answers);
      if (!best || g.pct > best.g.pct) best = { a, g };
    });
    return best;
  };

  TR.certNo = (a) => 'MA/CERT/' + (U.toDate(a.submittedAt) || new Date()).getFullYear() + '/' + a.empId + '-' + String(a.examId || '').slice(-4).toUpperCase() + a.attemptNo;

  // ================= EMPLOYEE =================
  V.empLearn = async function (el, p) {
    const tab = p.tab || 'training';
    el.innerHTML = '<h2 class="page-title">' + T('trainingExams') + '</h2><div class="tabs">' +
      [['training', '📘 ' + T('training')], ['exams', '📝 ' + T('exams')], ['progress', '📈 ' + T('myProgress')]].map((t) => '<button class="' + (t[0] === tab ? 'on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') +
      '</div><div id="tb"></div>';
    U.$$('[data-tab]').forEach((b) => b.onclick = () => App.go('empLearn', { tab: b.dataset.tab }));
    const tb = U.$('#tb'), me = S.user.empId;
    const [trs, done, exams, atts] = await Promise.all([DB.all('trainings'), DB.query('trainingDone', [['empId', '==', me]]), DB.all('exams'), DB.query('attempts', [['empId', '==', me]])]);
    const myTr = trs.filter((t) => TR.assigned(t, me)).sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    const doneSet = new Set(done.map((d) => d.trainingId));
    const myEx = exams.filter((x) => TR.assigned(x, me)).sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));

    if (tab === 'training') {
      tb.innerHTML = '<div class="stats4 two"><div><b>' + myTr.filter((t) => doneSet.has(t.id)).length + ' / ' + myTr.length + '</b><small>' + T('trainingCompleted') + '</small></div><div><b>' +
        myTr.filter((t) => !doneSet.has(t.id)).length + '</b><small>' + T('pending') + '</small></div></div>' +
        (myTr.length ? myTr.map((t) => '<div class="card tr-card" data-tr="' + esc(t.id) + '"><div class="row-between"><b>📘 ' + esc(t.title) + '</b>' +
          (doneSet.has(t.id) ? '<span class="badge ok">✔ ' + T('completed') + '</span>' : '<span class="badge warn">' + T('pending') + '</span>') + '</div>' +
          (t.description ? '<p class="muted small clamp">' + esc(t.description) + '</p>' : '') + (t.dueDate ? '<small class="muted">' + T('dueDate') + ': ' + U.fmtDate(t.dueDate) + '</small>' : '') + '</div>').join('') : U.empty(T('noTraining')));
      U.$$('[data-tr]', tb).forEach((c) => c.onclick = () => App.go('empTraining', { id: c.dataset.tr }));
    } else if (tab === 'exams') {
      tb.innerHTML = myEx.length ? myEx.map((x) => examCard(x, atts.filter((a) => a.examId === x.id), doneSet)).join('') : U.empty(T('noExams'));
      U.$$('[data-start]', tb).forEach((b) => b.onclick = () => startExam(myEx.find((x) => x.id === b.dataset.start), atts.filter((a) => a.examId === b.dataset.start)));
      U.$$('[data-res]', tb).forEach((b) => b.onclick = () => { const x = myEx.find((e) => e.id === b.dataset.res); TR.showResults(x, atts.filter((a) => a.examId === x.id), false); });
      U.$$('[data-cert]', tb).forEach((b) => b.onclick = () => { const x = myEx.find((e) => e.id === b.dataset.cert); const best = TR.bestAttempt(x, atts.filter((a) => a.examId === x.id)); TR.showCertificate(x, best.a, S.emp); });
    } else {
      const month = U.monthKey();
      const [att, hol] = await Promise.all([DB.query('attendance', [['empId', '==', me], ['month', '==', month]]), Cal.holidays(month)]);
      const s = Cal.summary(S.emp, att, month, hol);
      const passed = myEx.filter((x) => { const b = TR.bestAttempt(x, atts.filter((a) => a.examId === x.id)); return b && b.g.passed; });
      const bests = myEx.map((x) => TR.bestAttempt(x, atts.filter((a) => a.examId === x.id))).filter(Boolean);
      const avg = bests.length ? Math.round(bests.reduce((t, b) => t + b.g.pct, 0) / bests.length) : 0;
      tb.innerHTML = TR.progressCard({ att: s.pct, trDone: myTr.filter((t) => doneSet.has(t.id)).length, trTotal: myTr.length, exPassed: passed.length, exTotal: myEx.length, avg }) +
        '<h3 class="sec-title">🏅 ' + T('certificates') + '</h3>' +
        (passed.filter((x) => x.certificate !== false).length ? '<div class="card list">' + passed.filter((x) => x.certificate !== false).map((x) => {
          const b = TR.bestAttempt(x, atts.filter((a) => a.examId === x.id));
          return '<div class="li"><div class="grow"><b>' + esc(x.title) + '</b><small>' + b.g.pct + '% · ' + U.fmtDate(b.a.submittedAt) + '</small></div><button class="btn sm" data-cert="' + esc(x.id) + '">🏅 ' + T('view') + '</button></div>';
        }).join('') + '</div>' : U.empty(T('noCertificates'))) +
        '<h3 class="sec-title">📝 ' + T('examResults') + '</h3>' +
        (myEx.length ? '<div class="card list">' + myEx.map((x) => {
          const mine = atts.filter((a) => a.examId === x.id); const b = TR.bestAttempt(x, mine);
          return '<div class="li"><div class="grow"><b>' + esc(x.title) + '</b><small>' + T('attempts') + ' ' + mine.length + '/' + x.maxAttempts + (b ? ' · ' + T('best') + ' ' + b.g.pct + '%' : '') + '</small></div>' +
            (b ? (b.g.passed ? '<span class="badge ok">' + T('pass') + '</span>' : '<span class="badge bad">' + T('fail') + '</span>') : '<span class="badge muted">' + T('notAttempted') + '</span>') + '</div>';
        }).join('') + '</div>' : U.empty());
      U.$$('[data-cert]', tb).forEach((b) => b.onclick = () => { const x = myEx.find((e) => e.id === b.dataset.cert); TR.showCertificate(x, TR.bestAttempt(x, atts.filter((a) => a.examId === x.id)).a, S.emp); });
    }
  };

  TR.progressCard = function (d) {
    const ring = (pct, label, sub) => '<div class="ring-box"><div class="ring" style="--p:' + Math.max(0, Math.min(100, pct)) + '"><b>' + Math.round(pct) + '%</b></div><small>' + label + '</small>' + (sub ? '<small class="muted">' + sub + '</small>' : '') + '</div>';
    return '<div class="card"><div class="rings">' +
      ring(d.att, T('attendance'), T('thisMonth')) +
      ring(d.trTotal ? d.trDone / d.trTotal * 100 : 0, T('training'), d.trDone + '/' + d.trTotal) +
      ring(d.exTotal ? d.exPassed / d.exTotal * 100 : 0, T('examsPassed'), d.exPassed + '/' + d.exTotal) +
      ring(d.avg, T('avgScore'), '') +
      (d.target != null ? ring(d.target, T('targets'), '') : '') + '</div></div>';
  };

  function examCard(x, mine, doneSet) {
    const used = mine.length, left = Math.max(0, U.num(x.maxAttempts) - used);
    const b = TR.bestAttempt(x, mine);
    const needTr = x.trainingId && !doneSet.has(x.trainingId);
    const canStart = left > 0 && !(b && b.g.passed) && !needTr;
    return '<div class="card"><div class="row-between"><b>📝 ' + esc(x.title) + '</b>' + (b ? (b.g.passed ? '<span class="badge ok">✔ ' + T('pass') + ' ' + b.g.pct + '%</span>' : '<span class="badge bad">' + T('fail') + ' ' + b.g.pct + '%</span>') : '<span class="badge muted">' + T('notAttempted') + '</span>') + '</div>' +
      (x.description ? '<p class="muted small">' + esc(x.description) + '</p>' : '') +
      '<div class="tg-grid"><span>' + T('questions') + '<b>' + (x.questions || []).length + '</b></span><span>' + T('passMarks') + '<b>' + x.passPct + '%</b></span><span>' + T('attempts') + '<b>' + used + ' / ' + x.maxAttempts + '</b></span>' +
      (x.timeLimit ? '<span>' + T('timeLimit') + '<b>' + x.timeLimit + ' min</b></span>' : '') + '</div>' +
      (needTr ? '<div class="note small">' + T('completeTrainingFirst') + '</div>' : '') +
      '<div class="row-btns left">' + (canStart ? '<button class="btn sm" data-start="' + esc(x.id) + '">▶ ' + (used ? T('reattempt') : T('startExam')) + '</button>' : '') +
      (used ? '<button class="btn sm ghost" data-res="' + esc(x.id) + '">📊 ' + T('result') + '</button>' : '') +
      (b && b.g.passed && x.certificate !== false ? '<button class="btn sm ghost" data-cert="' + esc(x.id) + '">🏅 ' + T('certificate') + '</button>' : '') + '</div>' +
      (!canStart && left === 0 && !(b && b.g.passed) ? '<small class="muted">' + T('noAttemptsLeft') + '</small>' : '') + '</div>';
  }

  V.empTraining = async function (el, p) {
    const t = await DB.get('trainings', p.id);
    if (!t) { el.innerHTML = U.empty(); return; }
    const done = await DB.get('trainingDone', p.id + '_' + S.user.empId);
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'empLearn\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><h2>📘 ' + esc(t.title) + '</h2>' + (t.description ? '<p class="muted">' + esc(t.description) + '</p>' : '') +
      (t.dueDate ? '<small class="muted">' + T('dueDate') + ': ' + U.fmtDate(t.dueDate) + '</small>' : '') + '</div>' +
      (t.content ? '<div class="card tr-content">' + esc(t.content).replace(/\n/g, '<br>') + '</div>' : '') +
      (t.link ? '<div class="card"><a href="' + esc(t.link) + '" target="_blank" rel="noopener">🔗 ' + T('openLink') + '</a><br><small class="muted">' + esc(t.link) + '</small></div>' : '') +
      (t.fileName ? '<div class="card"><button class="btn ghost" id="att">📎 ' + esc(t.fileName) + '</button></div>' : '') +
      (done ? '<div class="done-box">✔ ' + T('completedOn') + ' ' + U.fmtDT(done.at) + '</div>' : '<button class="btn block" id="mk">✔ ' + T('markCompleted') + '</button>');
    const a = U.$('#att');
    if (a) a.onclick = async () => { U.loading(true); try { const f = await DB.get('trainingfiles', t.id); if (f) { if (/^data:image/.test(f.data)) U.modal(t.fileName, '<img class="doc-img" src="' + f.data + '">', { wide: true }); else U.openDataUrl(safeName(t.fileName) + '.pdf', f.data); } } finally { U.loading(false); } };
    const mk = U.$('#mk');
    if (mk) mk.onclick = async () => {
      if (!(await U.confirm(T('markCompletedConfirm'), T('yes')))) return;
      try { await DB.set('trainingDone', t.id + '_' + S.user.empId, { trainingId: t.id, title: t.title, empId: S.user.empId, empName: S.emp.name, at: DB.now() }); U.toast(T('saved'), 'ok'); App.refresh(); }
      catch (e) { U.toast(e.message, 'err'); }
    };
  };

  async function startExam(x, mine) {
    const n = mine.length + 1;
    if (!(await U.confirm(T('startExamConfirm').replace('{n}', n).replace('{m}', x.maxAttempts) + (x.timeLimit ? ' ' + T('timeLimit') + ': ' + x.timeLimit + ' min.' : ''), T('startExam')))) return;
    const id = x.id + '_' + S.user.empId + '_' + n;
    U.loading(true);
    try {
      await DB.set('attempts', id, { examId: x.id, examTitle: x.title, empId: S.user.empId, empName: S.emp.name, attemptNo: n, status: 'started', startedAt: DB.now(), startMs: Date.now() });
    } catch (e) { U.loading(false); return U.toast(e.message, 'err'); }
    U.loading(false);
    App.go('empExam', { examId: x.id, attemptId: id });
  }

  V.empExam = async function (el, p) {
    const x = await DB.get('exams', p.examId);
    const at = await DB.get('attempts', p.attemptId);
    if (!x || !at) { el.innerHTML = U.empty(); return; }
    if (at.status === 'submitted') return App.go('empLearn', { tab: 'exams' });
    const qs = x.questions || [];
    const ans = qs.map(() => -1);
    el.innerHTML = '<div class="exam-head card"><div><b>' + esc(x.title) + '</b><br><small class="muted">' + T('attempt') + ' ' + at.attemptNo + '/' + x.maxAttempts + ' · ' + qs.length + ' ' + T('questions') + '</small></div>' +
      (x.timeLimit ? '<div class="timer" id="timer">--:--</div>' : '') + '</div>' +
      qs.map((q, i) => '<div class="card q-card"><b>Q' + (i + 1) + '. ' + esc(q.q) + '</b>' + (U.num(q.marks) > 1 ? ' <small class="muted">(' + q.marks + ' ' + T('marks') + ')</small>' : '') +
        '<div class="opts">' + (q.opts || []).map((o, j) => '<label class="opt"><input type="radio" name="q' + i + '" value="' + j + '"><span>' + String.fromCharCode(65 + j) + '. ' + esc(o) + '</span></label>').join('') + '</div></div>').join('') +
      '<div class="answered small muted center" id="cnt"></div><button class="btn block" id="sub">📤 ' + T('submitExam') + '</button>';
    const upd = () => { U.$('#cnt').textContent = T('answered') + ': ' + ans.filter((a) => a >= 0).length + ' / ' + qs.length; };
    U.$$('.opt input').forEach((r) => r.onchange = () => { ans[Number(r.name.slice(1))] = Number(r.value); upd(); });
    upd();
    let submitted = false, timerId = null;
    const submit = async (auto) => {
      if (submitted) return;
      if (!auto) {
        const un = ans.filter((a) => a < 0).length;
        if (!(await U.confirm((un ? T('unansweredWarn').replace('{n}', un) + ' ' : '') + T('submitConfirm'), T('submitExam')))) return;
      }
      submitted = true; if (timerId) clearInterval(timerId);
      const g = TR.grade(x, ans);
      U.loading(true);
      try {
        await DB.update('attempts', at.id, { answers: ans, score: g.score, total: g.total, pct: g.pct, passed: g.passed, status: 'submitted', submittedAt: DB.now(), timeTaken: Math.round((Date.now() - (at.startMs || Date.now())) / 1000) });
        U.loading(false);
        App.go('empLearn', { tab: 'exams' });
        setTimeout(() => TR.resultModal(x, Object.assign({}, at, { answers: ans, status: 'submitted', submittedAt: new Date(), timeTaken: Math.round((Date.now() - (at.startMs || Date.now())) / 1000) }), false), 400);
      } catch (e) { submitted = false; U.loading(false); U.toast(e.message, 'err'); }
    };
    U.$('#sub').onclick = () => submit(false);
    if (x.timeLimit) {
      const end = (at.startMs || Date.now()) + U.num(x.timeLimit) * 60000;
      const tick = () => {
        const t = U.$('#timer'); if (!t) { clearInterval(timerId); return; }
        const left = Math.max(0, end - Date.now());
        t.textContent = U.pad(Math.floor(left / 60000)) + ':' + U.pad(Math.floor(left / 1000) % 60);
        t.classList.toggle('low', left < 60000);
        if (left <= 0) { U.toast(T('timeUp'), 'err'); submit(true); }
      };
      timerId = setInterval(tick, 1000); tick();
    }
  };

  TR.resultModal = function (x, a, admin) {
    const g = TR.grade(x, a.answers);
    const show = admin || x.showAnswers;
    const m = U.modal(T('result') + ' · ' + x.title,
      '<div class="result-box ' + (g.passed ? 'ok' : 'bad') + '"><div class="big-score">' + g.pct + '%</div><b>' + (g.passed ? '🎉 ' + T('passed') : '❌ ' + T('failed')) + '</b><div>' +
      T('marks') + ': ' + g.score + ' / ' + g.total + ' · ' + T('passMarks') + ' ' + x.passPct + '%</div><small>' + T('attempt') + ' ' + a.attemptNo + ' · ' + U.fmtDT(a.submittedAt) +
      (a.timeTaken ? ' · ' + Math.floor(a.timeTaken / 60) + 'm ' + (a.timeTaken % 60) + 's' : '') + '</small></div>' +
      (a.status !== 'submitted' ? '<div class="note">' + T('incompleteAttempt') + '</div>' : '') +
      (show && a.answers ? (x.questions || []).map((q, i) => {
        const my = a.answers[i], ok = my === q.ans;
        return '<div class="card q-card ' + (ok ? 'q-ok' : 'q-bad') + '"><b>Q' + (i + 1) + '. ' + esc(q.q) + '</b><div class="small">' + T('yourAnswer') + ': <b>' + (my >= 0 ? esc(q.opts[my]) : '-') + '</b> ' + (ok ? '✔' : '✕') + '</div>' +
          (!ok ? '<div class="small good">' + T('correctAnswer') + ': <b>' + esc(q.opts[q.ans]) + '</b></div>' : '') + '</div>';
      }).join('') : '') +
      (g.passed && x.certificate !== false ? '<button class="btn block" data-c>🏅 ' + T('certificate') + '</button>' : ''), { wide: true });
    const c = m.el.querySelector('[data-c]');
    if (c) c.onclick = async () => { const emp = admin ? (await DB.get('employees', a.empId)) : S.emp; TR.showCertificate(x, a, emp); };
  };

  TR.showResults = function (x, mine, admin) {
    mine = mine.slice().sort((a, b) => b.attemptNo - a.attemptNo);
    const m = U.modal(x.title, mine.length ? '<div class="card list">' + mine.map((a) => {
      const g = TR.grade(x, a.answers);
      return '<div class="li"><div class="grow"><b>' + T('attempt') + ' ' + a.attemptNo + '</b><small>' + (a.status === 'submitted' ? U.fmtDT(a.submittedAt) + ' · ' + g.score + '/' + g.total : T('incompleteAttempt')) + '</small></div>' +
        (a.status === 'submitted' ? '<b class="' + (g.passed ? 'good' : 'low') + '">' + g.pct + '%</b>' : '<span class="badge muted">—</span>') + '<button class="icon-btn" data-a="' + esc(a.id) + '">👁</button></div>';
    }).join('') + '</div>' : U.empty());
    U.$$('[data-a]', m.el).forEach((b) => b.onclick = () => TR.resultModal(x, mine.find((a) => a.id === b.dataset.a), admin));
  };

  TR.showCertificate = function (x, a, e) {
    const g = TR.grade(x, a.answers);
    const st = S.settings;
    const m = U.modal('🏅 ' + T('certificate'), '<div class="cert"><img src="img/logo.png" alt=""><div class="cert-shop">' + esc(st.showroom || APP_INFO.showroom) + '</div>' +
      '<h2>CERTIFICATE OF ACHIEVEMENT</h2><p>This is to certify that</p><div class="cert-name">' + esc(e.name) + '</div><p>' + esc(e.designation || '') + ' (Emp ID: ' + esc(e.id) + ')</p>' +
      '<p>has successfully passed the assessment</p><div class="cert-exam">' + esc(x.title) + '</div><p>with a score of <b>' + g.pct + '%</b> on ' + U.fmtDate(a.submittedAt) + '</p>' +
      '<div class="sig"><span>Certificate No.<br>' + esc(TR.certNo(a)) + '</span><span>For ' + esc(st.showroom || '') + '<br>Authorised Signatory</span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => PDF.certificatePdf(x, a, e, g, TR.certNo(a));
  };

  // ================= ADMIN: TRAINING =================
  V.adminTraining = async function (el) {
    const [trs, done, emps] = await Promise.all([DB.all('trainings'), DB.all('trainingDone'), Admin.employees()]);
    trs.sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">📘 ' + T('training') + '</h2><button class="btn" onclick="App.go(\'adminTrainingEdit\')">+ ' + T('new') + '</button></div>' +
      '<div class="chips"><button class="chip" onclick="App.go(\'adminExams\')">📝 ' + T('exams') + '</button><button class="chip" onclick="App.go(\'adminProgress\')">📈 ' + T('staffProgress') + '</button></div>' +
      (trs.length ? trs.map((t) => {
        const asg = emps.filter((e) => TR.assigned(t, e.id)); const d = asg.filter((e) => done.find((x) => x.trainingId === t.id && x.empId === e.id)).length;
        const pct = asg.length ? Math.round(d / asg.length * 100) : 0;
        return '<div class="card" data-t="' + esc(t.id) + '"><div class="row-between"><b>📘 ' + esc(t.title) + '</b>' + (t.active === false ? '<span class="badge muted">' + T('inactive') + '</span>' : '') + '</div>' +
          '<div class="bar"><i class="' + (pct >= 90 ? 'good' : pct >= 50 ? 'mid' : 'low') + '" style="width:' + pct + '%"></i></div><small>' + T('completed') + ' ' + d + ' / ' + asg.length + (t.dueDate ? ' · ' + T('dueDate') + ' ' + U.fmtDate(t.dueDate) : '') + '</small></div>';
      }).join('') : U.empty(T('noTraining')));
    U.$$('[data-t]').forEach((c) => c.onclick = () => App.go('adminTrainingDetail', { id: c.dataset.t }));
  };

  function assignHtml(item, emps) {
    const sel = item.assignTo === 'selected';
    return '<div class="card"><h3>' + T('assignTo') + '</h3>' + U.field('_all', T('allEmployees'), !sel, { type: 'checkbox' }) +
      '<div id="empPick" class="pick-list"' + (sel ? '' : ' style="display:none"') + '>' + emps.map((e) => '<label class="chk"><input type="checkbox" data-emp="' + esc(e.id) + '"' + ((item.empIds || []).includes(e.id) ? ' checked' : '') + '> <span>' + esc(e.name) + '</span></label>').join('') + '</div></div>';
  }
  function bindAssign() {
    const all = U.$('[name=_all]'); if (all) all.onchange = () => { U.$('#empPick').style.display = all.checked ? 'none' : ''; };
  }
  function readAssign() {
    const all = U.$('[name=_all]').checked;
    return { assignTo: all ? 'all' : 'selected', empIds: all ? [] : U.$$('[data-emp]').filter((x) => x.checked).map((x) => x.dataset.emp) };
  }
  async function notifyAssigned(asg, emps, title, body) {
    if (asg.assignTo === 'all') return DB.add('notifications', { target: 'all', targetName: 'All', title, body, at: DB.now(), by: S.user.name || 'Admin' });
    for (const id of asg.empIds) { const e = emps.find((x) => x.id === id); await DB.add('notifications', { target: id, targetName: e ? e.name : id, title, body, at: DB.now(), by: S.user.name || 'Admin' }); }
  }

  V.adminTrainingEdit = async function (el, p) {
    const t = p.id ? await DB.get('trainings', p.id) : { active: true };
    const emps = await Admin.employees();
    let file = null;
    el.innerHTML = '<h2 class="page-title">📘 ' + (p.id ? T('edit') : T('newTraining')) + '</h2><form id="tf" class="form"><div class="card">' +
      U.field('title', T('title'), t.title, { required: true }) + U.field('description', T('description'), t.description, { type: 'textarea', rows: 2 }) +
      U.field('content', T('trainingContent'), t.content, { type: 'textarea', rows: 10 }) +
      U.field('link', T('videoLink'), t.link, { placeholder: 'https://youtube.com/...' }) +
      '<label class="fld"><span>' + T('attachment') + ' (PDF/JPG ≤ 750 KB)' + (t.fileName ? ' · ' + esc(t.fileName) : '') + '</span><input type="file" id="tfile" accept="image/*,application/pdf"></label>' +
      '<div class="grid2f">' + U.field('dueDate', T('dueDate'), t.dueDate, { type: 'date' }) + '</div>' + U.field('active', T('active'), t.active !== false, { type: 'checkbox' }) + '</div>' +
      assignHtml(t, emps) + (p.id ? '' : '<div class="card">' + U.field('notify', T('notifyStaff'), true, { type: 'checkbox' }) + '</div>') +
      '<button class="btn block">' + T('save') + '</button></form>';
    bindAssign();
    U.$('#tfile').onchange = async (ev) => {
      const f = ev.target.files[0]; if (!f) return;
      try {
        if (/^image\//.test(f.type)) file = { name: f.name, data: await U.compressImage(f, 1400, 0.75) };
        else if (f.type === 'application/pdf') { if (f.size > 750 * 1024) throw new Error(T('pdfTooBig')); file = { name: f.name, data: await U.fileToDataURL(f) }; }
        else throw new Error(T('onlyImagePdf'));
      } catch (e) { ev.target.value = ''; U.toast(e.message, 'err'); }
    };
    U.$('#tf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target); const asg = readAssign();
      if (asg.assignTo === 'selected' && !asg.empIds.length) return U.toast(T('selectEmployee'), 'err');
      const data = Object.assign({ title: d.title, description: d.description, content: d.content, link: d.link, dueDate: d.dueDate, active: !!d.active }, asg);
      U.loading(true);
      try {
        let id = p.id;
        if (id) await DB.update('trainings', id, data);
        else id = await DB.add('trainings', Object.assign(data, { createdAt: DB.now() }));
        if (file) { await DB.set('trainingfiles', id, { data: file.data }); await DB.update('trainings', id, { fileName: file.name }); }
        if (!p.id && d.notify) await notifyAssigned(asg, emps, '📘 ' + T('newTraining') + ': ' + d.title, T('newTrainingMsg'));
        U.toast(T('saved'), 'ok'); App.go('adminTrainingDetail', { id });
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  V.adminTrainingDetail = async function (el, p) {
    const [t, done, emps] = await Promise.all([DB.get('trainings', p.id), DB.query('trainingDone', [['trainingId', '==', p.id]]), Admin.employees()]);
    if (!t) { el.innerHTML = U.empty(); return; }
    const asg = emps.filter((e) => TR.assigned(Object.assign({}, t, { active: true }), e.id));
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'adminTraining\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><h2>📘 ' + esc(t.title) + '</h2><p class="muted">' + esc(t.description || '') + '</p>' +
      '<div class="row-btns left"><button class="btn sm ghost" onclick="App.go(\'adminTrainingEdit\',{id:\'' + esc(t.id) + '\'})">✏️ ' + T('edit') + '</button><button class="btn sm ghost" id="del">🗑 ' + T('delete') + '</button></div></div>' +
      '<div class="card list">' + asg.map((e) => {
        const d = done.find((x) => x.empId === e.id);
        return '<div class="li">' + App.empAvatar(e, 32) + '<div class="grow"><b>' + esc(e.name) + '</b><small>' + (d ? T('completedOn') + ' ' + U.fmtDT(d.at) : T('pending')) + '</small></div>' +
          (d ? '<span class="badge ok">✔</span><button class="icon-btn" data-rs="' + esc(d.id) + '" title="reset">↺</button>' : '<span class="badge warn">' + T('pending') + '</span>') + '</div>';
      }).join('') + '</div>';
    U.$('#del').onclick = async () => { if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('trainings', t.id); try { await DB.del('trainingfiles', t.id); } catch (e) { } App.go('adminTraining'); } };
    U.$$('[data-rs]').forEach((b) => b.onclick = async () => { if (await U.confirm(T('resetCompletion'))) { await DB.del('trainingDone', b.dataset.rs); App.refresh(); } });
  };

  // ================= ADMIN: EXAMS =================
  V.adminExams = async function (el) {
    const [exams, atts, emps] = await Promise.all([DB.all('exams'), DB.all('attempts'), Admin.employees()]);
    exams.sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">📝 ' + T('exams') + '</h2><button class="btn" onclick="App.go(\'adminExamEdit\')">+ ' + T('newExam') + '</button></div>' +
      '<div class="chips"><button class="chip" onclick="App.go(\'adminTraining\')">📘 ' + T('training') + '</button><button class="chip" onclick="App.go(\'adminProgress\')">📈 ' + T('staffProgress') + '</button></div>' +
      (exams.length ? exams.map((x) => {
        const asg = emps.filter((e) => TR.assigned(Object.assign({}, x, { active: true }), e.id));
        const attempted = asg.filter((e) => atts.some((a) => a.examId === x.id && a.empId === e.id)).length;
        const passed = asg.filter((e) => { const b = TR.bestAttempt(x, atts.filter((a) => a.examId === x.id && a.empId === e.id)); return b && b.g.passed; }).length;
        return '<div class="card" data-x="' + esc(x.id) + '"><div class="row-between"><b>📝 ' + esc(x.title) + '</b>' + (x.active === false ? '<span class="badge muted">' + T('inactive') + '</span>' : '') + '</div>' +
          '<small class="muted">' + (x.questions || []).length + ' ' + T('questions') + ' · ' + T('passMarks') + ' ' + x.passPct + '% · ' + T('attemptLimit') + ' ' + x.maxAttempts + '</small>' +
          '<div class="tg-grid"><span>' + T('assigned') + '<b>' + asg.length + '</b></span><span>' + T('attempted') + '<b>' + attempted + '</b></span><span>' + T('passed') + '<b class="good">' + passed + '</b></span></div></div>';
      }).join('') : U.empty(T('noExams')));
    U.$$('[data-x]').forEach((c) => c.onclick = () => App.go('adminExamDetail', { id: c.dataset.x }));
  };

  V.adminExamEdit = async function (el, p) {
    const x = p.id ? await DB.get('exams', p.id) : { passPct: 60, maxAttempts: 2, timeLimit: 15, certificate: true, showAnswers: false, active: true, questions: [{ q: '', opts: ['', '', '', ''], ans: 0, marks: 1 }] };
    const [emps, trs] = await Promise.all([Admin.employees(), DB.all('trainings')]);
    el.innerHTML = '<h2 class="page-title">📝 ' + (p.id ? T('edit') : T('newExam')) + '</h2><form id="xf" class="form"><div class="card">' +
      U.field('title', T('title'), x.title, { required: true }) + U.field('description', T('description'), x.description, { type: 'textarea', rows: 2 }) +
      '<div class="grid2f">' + U.field('passPct', T('passMarks') + ' %', x.passPct, { type: 'number', min: 1 }) + U.field('maxAttempts', T('attemptLimit'), x.maxAttempts, { type: 'number', min: 1 }) +
      U.field('timeLimit', T('timeLimit') + ' (min, 0 = ' + T('none') + ')', x.timeLimit, { type: 'number', min: 0 }) +
      U.field('trainingId', T('linkedTraining'), x.trainingId || '', { type: 'select', options: [{ v: '', l: '— ' + T('none') + ' —' }].concat(trs.map((t) => ({ v: t.id, l: t.title }))) }) + '</div>' +
      U.field('certificate', T('issueCertificate'), x.certificate !== false, { type: 'checkbox' }) + U.field('showAnswers', T('showAnswersAfter'), !!x.showAnswers, { type: 'checkbox' }) +
      U.field('active', T('active'), x.active !== false, { type: 'checkbox' }) + '</div>' +
      '<h3 class="sec-title">' + T('questions') + '</h3><div id="qs"></div><button type="button" class="btn ghost block" id="addQ">+ ' + T('addQuestion') + '</button>' +
      assignHtml(x, emps) + (p.id ? '' : '<div class="card">' + U.field('notify', T('notifyStaff'), true, { type: 'checkbox' }) + '</div>') +
      '<button class="btn block">' + T('save') + '</button></form>';
    bindAssign();
    const qs = U.$('#qs');
    const qHtml = (q, i) => '<div class="card q-edit" data-qi><div class="row-between"><b>Q' + (i + 1) + '</b><button type="button" class="icon-btn" data-rmq>🗑</button></div>' +
      '<textarea class="qtext" rows="2" placeholder="' + T('questionText') + '">' + esc(q.q) + '</textarea>' +
      [0, 1, 2, 3].map((j) => '<label class="opt-edit"><input type="radio" name="ans' + i + '" value="' + j + '"' + (q.ans === j ? ' checked' : '') + ' title="' + T('correctAnswer') + '"><input class="otext" placeholder="' + T('option') + ' ' + String.fromCharCode(65 + j) + (j > 1 ? ' (' + T('optional') + ')' : '') + '" value="' + esc((q.opts || [])[j] || '') + '"></label>').join('') +
      '<div class="row"><small class="muted grow">◉ = ' + T('correctAnswer') + '</small><label class="small">' + T('marks') + ' <input type="number" class="qmarks" min="1" value="' + (q.marks || 1) + '" style="width:60px"></label></div></div>';
    const read = () => U.$$('[data-qi]', qs).map((c, i) => ({
      q: c.querySelector('.qtext').value.trim(), opts: U.$$('.otext', c).map((o) => o.value.trim()),
      ans: Number((c.querySelector('input[type=radio]:checked') || { value: 0 }).value), marks: Math.max(1, U.num(c.querySelector('.qmarks').value) || 1)
    }));
    const render = (list) => {
      qs.innerHTML = list.map(qHtml).join('');
      U.$$('[data-rmq]', qs).forEach((b, i) => b.onclick = () => { const l = read(); l.splice(i, 1); render(l.length ? l : [{ q: '', opts: ['', '', '', ''], ans: 0, marks: 1 }]); });
    };
    render(x.questions || []);
    U.$('#addQ').onclick = () => { const l = read(); l.push({ q: '', opts: ['', '', '', ''], ans: 0, marks: 1 }); render(l); qs.lastElementChild.scrollIntoView({ behavior: 'smooth' }); };
    U.$('#xf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target); const asg = readAssign();
      if (asg.assignTo === 'selected' && !asg.empIds.length) return U.toast(T('selectEmployee'), 'err');
      const raw = read();
      const questions = [];
      for (let i = 0; i < raw.length; i++) {
        const q = raw[i];
        if (!q.q) return U.toast('Q' + (i + 1) + ': ' + T('questionText') + '?', 'err');
        const keep = q.opts.map((o, j) => ({ o, j })).filter((z) => z.o);
        if (keep.length < 2) return U.toast('Q' + (i + 1) + ': ' + T('min2Options'), 'err');
        if (!q.opts[q.ans]) return U.toast('Q' + (i + 1) + ': ' + T('pickCorrect'), 'err');
        questions.push({ q: q.q, opts: keep.map((z) => z.o), ans: keep.findIndex((z) => z.j === q.ans), marks: q.marks });
      }
      if (!questions.length) return U.toast(T('addQuestion'), 'err');
      const data = Object.assign({
        title: d.title, description: d.description, passPct: Math.min(100, Math.max(1, U.num(d.passPct))), maxAttempts: Math.max(1, parseInt(d.maxAttempts) || 1),
        timeLimit: Math.max(0, parseInt(d.timeLimit) || 0), trainingId: d.trainingId || '', certificate: !!d.certificate, showAnswers: !!d.showAnswers, active: !!d.active, questions
      }, asg);
      U.loading(true);
      try {
        let id = p.id;
        if (id) await DB.update('exams', id, data); else id = await DB.add('exams', Object.assign(data, { createdAt: DB.now() }));
        if (!p.id && d.notify) await notifyAssigned(asg, emps, '📝 ' + T('newExam') + ': ' + d.title, T('newExamMsg').replace('{n}', data.maxAttempts));
        U.toast(T('saved'), 'ok'); App.go('adminExamDetail', { id });
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  V.adminExamDetail = async function (el, p) {
    const [x, atts, emps] = await Promise.all([DB.get('exams', p.id), DB.query('attempts', [['examId', '==', p.id]]), Admin.employees()]);
    if (!x) { el.innerHTML = U.empty(); return; }
    const asg = emps.filter((e) => TR.assigned(Object.assign({}, x, { active: true }), e.id));
    const rows = asg.map((e) => { const mine = atts.filter((a) => a.empId === e.id); return { e, mine, b: TR.bestAttempt(x, mine) }; });
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'adminExams\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><h2>📝 ' + esc(x.title) + '</h2><small class="muted">' + (x.questions || []).length + ' ' + T('questions') + ' · ' + T('passMarks') + ' ' + x.passPct + '% · ' + T('attemptLimit') + ' ' + x.maxAttempts +
      (x.timeLimit ? ' · ' + x.timeLimit + ' min' : '') + '</small><div class="row-btns left"><button class="btn sm ghost" onclick="App.go(\'adminExamEdit\',{id:\'' + esc(x.id) + '\'})">✏️ ' + T('edit') + '</button>' +
      '<button class="btn sm ghost" id="xl">⬇ Excel</button><button class="btn sm ghost" id="del">🗑 ' + T('delete') + '</button></div></div>' +
      '<div class="card list">' + rows.map((r) => '<div class="li">' + App.empAvatar(r.e, 32) + '<div class="grow"><b>' + esc(r.e.name) + '</b><small>' + T('attempts') + ' ' + r.mine.length + '/' + x.maxAttempts +
        (r.b ? ' · ' + T('best') + ' ' + r.b.g.score + '/' + r.b.g.total : '') + '</small></div>' +
        (r.b ? '<b class="' + (r.b.g.passed ? 'good' : 'low') + '">' + r.b.g.pct + '%</b>' : '<span class="badge muted">' + T('notAttempted') + '</span>') +
        (r.mine.length ? '<button class="icon-btn" data-v="' + esc(r.e.id) + '">👁</button><button class="icon-btn" data-g="' + esc(r.e.id) + '" title="' + T('giveAttempt') + '">↺</button>' : '') + '</div>').join('') + '</div>';
    U.$$('[data-v]').forEach((b) => b.onclick = () => { const r = rows.find((z) => z.e.id === b.dataset.v); TR.showResults(x, r.mine, true); });
    U.$$('[data-g]').forEach((b) => b.onclick = async () => {
      const r = rows.find((z) => z.e.id === b.dataset.g);
      if (!(await U.confirm(T('giveAttemptConfirm').replace('{n}', r.e.name)))) return;
      const last = r.mine.slice().sort((a, c) => c.attemptNo - a.attemptNo)[0];
      await DB.del('attempts', last.id); App.refresh();
    });
    U.$('#del').onclick = async () => { if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('exams', x.id); App.go('adminExams'); } };
    U.$('#xl').onclick = () => PDF.tableXlsx(x.title, 'Results', ['Emp ID', 'Name', 'Attempts', 'Best Score', 'Total', 'Percent', 'Result'],
      rows.map((r) => [r.e.id, r.e.name, r.mine.length, r.b ? r.b.g.score : '', r.b ? r.b.g.total : '', r.b ? r.b.g.pct : '', r.b ? (r.b.g.passed ? 'PASS' : 'FAIL') : 'Not attempted']));
  };

  // ================= ADMIN: STAFF PROGRESS =================
  V.adminProgress = async function (el, p) {
    const month = p.month || U.monthKey();
    const [emps, att, hol, trs, done, exams, atts, tgs, wal] = await Promise.all([
      Admin.employees(), DB.query('attendance', [['month', '==', month]]), Cal.holidays(month), DB.all('trainings'), DB.all('trainingDone'),
      DB.all('exams'), DB.all('attempts'), DB.all('targets'), DB.all('wallet')]);
    const rows = emps.map((e) => {
      const s = Cal.summary(e, att.filter((a) => a.empId === e.id), month, hol);
      const myTr = trs.filter((t) => TR.assigned(t, e.id)); const trDone = myTr.filter((t) => done.some((d) => d.trainingId === t.id && d.empId === e.id)).length;
      const myEx = exams.filter((x) => TR.assigned(x, e.id));
      const bests = myEx.map((x) => TR.bestAttempt(x, atts.filter((a) => a.examId === x.id && a.empId === e.id))).filter(Boolean);
      const exPassed = bests.filter((b) => b.g.passed).length;
      const avg = bests.length ? Math.round(bests.reduce((t, b) => t + b.g.pct, 0) / bests.length) : 0;
      const myTg = tgs.filter((t) => t.empId === e.id && t.status !== 'closed' && U.num(t.targetQty) > 0);
      const target = myTg.length ? Math.round(myTg.reduce((t, x) => t + Targets.calc(x).pct, 0) / myTg.length) : null;
      return { e, d: { att: s.pct, trDone, trTotal: myTr.length, exPassed, exTotal: myEx.length, avg, target }, bal: Targets.balance(wal.filter((w) => w.empId === e.id)), bests, myEx };
    });
    el.innerHTML = '<div class="row-between"><h2 class="page-title">📈 ' + T('staffProgress') + '</h2>' + App.monthSelect('pm', month) + '</div>' +
      '<div class="row-btns left"><button class="btn ghost sm" id="px">⬇ Excel</button></div>' +
      (rows.length ? rows.map((r) => '<div class="card"><div class="row-between"><div class="row">' + App.empAvatar(r.e, 38) + '<div><b>' + esc(r.e.name) + '</b><br><small class="muted">' + esc(r.e.designation || r.e.id) + '</small></div></div>' +
        '<small>💼 ' + U.money(r.bal) + '</small></div>' + TR.progressCard(r.d).replace('<div class="card">', '<div>') + '</div>').join('') : U.empty(T('noEmployees')));
    U.$('#pm').onchange = (ev) => App.go('adminProgress', { month: ev.target.value });
    U.$('#px').onclick = () => PDF.tableXlsx('Staff Progress', U.monthLabel(month).replace(/[^\x20-\x7E]/g, '') || month,
      ['Emp ID', 'Name', 'Attendance %', 'Training Done', 'Training Assigned', 'Exams Passed', 'Exams Assigned', 'Avg Score %', 'Target %', 'Wallet Balance'],
      rows.map((r) => [r.e.id, r.e.name, r.d.att, r.d.trDone, r.d.trTotal, r.d.exPassed, r.d.exTotal, r.d.avg, r.d.target == null ? '' : r.d.target, r.bal]));
  };
})();
