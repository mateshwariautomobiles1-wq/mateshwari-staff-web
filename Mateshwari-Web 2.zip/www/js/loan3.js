// ---------- Signed loan documents, lending partners, company profile ----------
(function () {
  const V = window.Views, esc = U.esc, LN = window.Loan;
  const kv = (k, v) => window.kvRow(k, v);
  const by = () => S.isAdmin ? (S.user.name || 'Admin') : (S.emp && S.emp.name) || '';

  // read an image file -> compressed dataURL
  App.pickImage = async function (maxSide, quality) {
    const f = await U.pickFile('image/*'); if (!f) return null;
    try { return await U.compressImage(f, maxSide || 600, quality || 0.85); } catch (e) { U.toast(e.message, 'err'); return null; }
  };
  // read image or pdf (<= 750KB)
  App.readDocFile = async function (file) {
    if (/^image\//.test(file.type)) { const data = await U.compressImage(file, 1400, 0.72); return { data, mime: 'image/jpeg', size: Math.round(data.length * 0.75) }; }
    if (file.type === 'application/pdf') { if (file.size > Files.MAX_PDF) throw new Error(T('pdfTooBig')); return { data: await U.fileToDataURL(file), mime: 'application/pdf', size: file.size }; }
    throw new Error(T('onlyImagePdf'));
  };
  App.viewFile = function (name, data) {
    if (!data) return U.toast(T('fileMissing'), 'err');
    if (/^data:image/.test(data)) {
      const m = U.modal(name, '<img src="' + data + '" class="doc-img" alt=""><div class="row-btns"><button class="btn" data-dl>⬇ ' + T('download') + '</button></div>', { wide: true });
      m.el.querySelector('[data-dl]').onclick = () => U.openDataUrl(safeName(name) + '.jpg', data);
    } else U.openDataUrl(safeName(name) + (/pdf/.test(data.slice(0, 30)) ? '.pdf' : ''), data);
  };

  // ================= SIGNED LOAN DOCUMENTS (before disbursal) =================
  LN.signedDocsReady = async function (l) {
    const ls = LN.settings();
    if (!ls.requireSignedDocs) return { ok: true, missing: [] };
    const docs = await DB.query('loandocs', [['loanId', '==', l.id]]);
    const types = ls.signedDocTypes && ls.signedDocTypes.length ? ls.signedDocTypes : ['Signed Documents'];
    const missing = types.filter((t) => !docs.some((d) => d.type === t && d.status === 'approved'));
    return { ok: !missing.length, missing };
  };

  LN.signedDocs = async function (el, l) {
    const ls = LN.settings();
    const types = (ls.signedDocTypes && ls.signedDocTypes.length ? ls.signedDocTypes : ['Signed Documents']).concat(['Other']);
    const docs = (await DB.query('loandocs', [['loanId', '==', l.id]])).sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    const mine = !S.isAdmin && l.empId === S.user.empId;
    const canUpload = S.isAdmin || (mine && ['approved', 'disbursed'].includes(l.status));
    const status = types.filter((t) => t !== 'Other').map((t) => {
      const d = docs.find((x) => x.type === t && x.status !== 'rejected') || docs.find((x) => x.type === t);
      return '<div class="li"><div class="grow"><b>' + esc(t) + '</b>' + (d && d.remark ? '<small>' + T('remark') + ': ' + esc(d.remark) + '</small>' : '') + '</div>' + (d ? U.badge(d.status) : '<span class="badge muted">' + T('notUploaded') + '</span>') + '</div>';
    }).join('');
    el.innerHTML = '<div class="card"><h3>✍️ ' + T('signedDocs') + '</h3><p class="muted small">' + T('signedDocsNote') + '</p><div class="list">' + status + '</div>' +
      (canUpload ? '<button class="btn" id="sdUp">⬆️ ' + T('uploadSignedDoc') + '</button>' : '') + '</div>' +
      (docs.length ? '<div class="card list">' + docs.map((d) => '<div class="li"><div class="doc-ic">' + (/pdf/.test(d.mime) ? '📕' : '🖼️') + '</div><div class="grow"><b>' + esc(d.type) + '</b><small>' + esc(d.name || '') + ' · ' + U.fmtDT(d.at) + ' · ' + esc(d.byName || '') +
        (d.remark ? '<br>' + T('remark') + ': ' + esc(d.remark) : '') + '</small><div class="row-btns left"><button class="btn sm ghost" data-v="' + d.id + '">👁 ' + T('view') + '</button>' +
        (S.isAdmin && d.status !== 'approved' ? '<button class="btn sm" data-ok="' + d.id + '">✔ ' + T('approve') + '</button>' : '') +
        (S.isAdmin && d.status !== 'rejected' ? '<button class="btn sm danger" data-no="' + d.id + '">✕ ' + T('reject') + '</button>' : '') +
        ((S.isAdmin || (mine && d.status !== 'approved')) ? '<button class="btn sm ghost" data-del="' + d.id + '">🗑</button>' : '') + '</div></div>' + U.badge(d.status) + '</div>').join('') + '</div>' : '');
    const up = U.$('#sdUp', el);
    if (up) up.onclick = () => {
      const m = U.modal(T('uploadSignedDoc'), '<form class="form" id="sdf">' + U.field('type', T('docType'), types[0], { type: 'select', options: types }) +
        '<label class="fld"><span>' + T('chooseFile') + ' (JPG/PNG/PDF)</span><input type="file" name="_file" accept="image/*,application/pdf" required></label><button class="btn block">' + T('upload') + '</button></form>');
      U.$('#sdf', m.el).onsubmit = async (ev) => {
        ev.preventDefault(); const f = ev.target.querySelector('[name=_file]').files[0]; if (!f) return;
        const type = ev.target.type.value;
        U.loading(true, T('uploading'));
        try {
          const r = await App.readDocFile(f);
          const id = U.uid();
          await Files.put('loandocfiles', id, { loanId: l.id, empId: l.empId }, r.data);
          await DB.set('loandocs', id, { loanId: l.id, empId: l.empId, empName: l.empName, type, name: f.name, mime: r.mime, size: r.size, status: S.isAdmin ? 'approved' : 'pending',
            uploadedBy: S.isAdmin ? 'admin' : 'self', byName: by(), at: DB.now() });
          if (!S.isAdmin) await DB.add('notifications', { target: 'admin', targetName: 'Admin', title: '✍️ ' + T('signedDocUploaded'), body: l.empName + ' · ' + type + ' · ' + (l.loanNo || ''), at: DB.now(), by: by() }).catch(() => { });
          m.close(); U.toast(T('uploaded'), 'ok'); LN.signedDocs(el, l);
        } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      };
    };
    U.$$('[data-v]', el).forEach((b) => b.onclick = async () => {
      U.loading(true); try { const f = await Files.get('loandocfiles', b.dataset.v); const d = docs.find((x) => x.id === b.dataset.v); App.viewFile(d.type, f && f.data); } finally { U.loading(false); }
    });
    const review = async (id, ok) => {
      const d = docs.find((x) => x.id === id);
      const remark = await U.prompt(ok ? T('approve') : T('reject'), T('remarkOptional'), d.remark || ''); if (remark == null) return;
      await DB.update('loandocs', id, { status: ok ? 'approved' : 'rejected', remark, reviewedAt: DB.now(), reviewedBy: by() });
      await DB.add('notifications', { target: l.empId, targetName: l.empName, title: (ok ? '✅ ' : '❌ ') + d.type + ' · ' + (ok ? T('approved') : T('rejected')), body: (l.loanNo || '') + (remark ? ' · ' + remark : ''), at: DB.now(), by: by() });
      LN.signedDocs(el, l);
    };
    U.$$('[data-ok]', el).forEach((b) => b.onclick = () => review(b.dataset.ok, true));
    U.$$('[data-no]', el).forEach((b) => b.onclick = () => review(b.dataset.no, false));
    U.$$('[data-del]', el).forEach((b) => b.onclick = async () => {
      if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return;
      await DB.del('loandocs', b.dataset.del); await Files.del('loandocfiles', b.dataset.del); LN.signedDocs(el, l);
    });
  };

  // ================= LENDING PARTNERS =================
  V.adminPartners = async function (el) {
    const list = await LN.loadPartners(true);
    const loans = await DB.all('loans');
    el.innerHTML = '<div class="row-between"><h2 class="page-title">🏦 ' + T('lendingPartners') + '</h2><button class="btn" onclick="App.go(\'adminPartnerEdit\')">+ ' + T('addPartner') + '</button></div>' +
      '<p class="muted small">' + T('partnersNote') + '</p>' +
      (list.length ? list.map((p) => {
        const mine = loans.filter((l) => l.partnerId === p.id);
        const run = mine.filter((l) => l.status === 'disbursed');
        return '<div class="card partner-row" data-p="' + esc(p.id) + '"><div class="row">' + (p.logo ? '<img class="p-logo" src="' + esc(p.logo) + '">' : '<span class="p-logo ph">🏦</span>') +
          '<div class="grow"><b>' + esc(p.name) + '</b>' + (p.active === false ? ' <span class="badge muted">' + T('inactive') + '</span>' : '') + '<br><small class="muted">' + esc(p.contactPerson || '') + (p.phone ? ' · ' + esc(p.phone) : '') + '</small></div></div>' +
          '<div class="tg-grid"><span>' + T('loans') + '<b>' + mine.length + '</b></span><span>' + T('runningLoans') + '<b>' + run.length + '</b></span><span>' + T('outstanding') + '<b>' + U.money(run.reduce((s, l) => s + LN.outstanding(l), 0)) + '</b></span><span>' + T('roi') + '<b>' + (p.interest || 0) + '% ' + (p.roiType === 'flat' ? T('flat') : T('reducing')) + '</b></span></div></div>';
      }).join('') : U.empty(T('noPartners')));
    U.$$('[data-p]').forEach((c) => c.onclick = () => App.go('adminPartnerEdit', { id: c.dataset.p }));
  };

  function imgPicker(id, label, val, hint) {
    return '<div class="fld"><span>' + esc(label) + '</span><div class="img-pick" id="' + id + '">' + (val ? '<img src="' + esc(val) + '">' : '<em>' + T('noImage') + '</em>') + '</div>' +
      '<div class="row-btns left"><button type="button" class="btn sm ghost" data-pick="' + id + '">📷 ' + T('upload') + '</button>' + (hint === 'sign' ? '<button type="button" class="btn sm ghost" data-draw="' + id + '">✍️ ' + T('drawSign') + '</button>' : '') +
      '<button type="button" class="btn sm ghost" data-clr="' + id + '">🗑</button></div></div>';
  }
  App.imgPickerHtml = imgPicker;
  App.bindImgPickers = function (root, store) {
    const show = (id) => { const b = U.$('#' + id, root); b.innerHTML = store[id] ? '<img src="' + store[id] + '">' : '<em>' + T('noImage') + '</em>'; };
    U.$$('[data-pick]', root).forEach((b) => b.onclick = async () => { const d = await App.pickImage(b.dataset.pick.includes('logo') ? 600 : 500, 0.9); if (d) { store[b.dataset.pick] = d; show(b.dataset.pick); } });
    U.$$('[data-draw]', root).forEach((b) => b.onclick = async () => { const d = await App.signPad(); if (d) { store[b.dataset.draw] = d; show(b.dataset.draw); } });
    U.$$('[data-clr]', root).forEach((b) => b.onclick = () => { store[b.dataset.clr] = ''; show(b.dataset.clr); });
  };

  // signature drawing pad -> PNG dataURL
  App.signPad = function () {
    return new Promise((resolve) => {
      const m = U.modal('✍️ ' + T('drawSign'), '<canvas class="sign-pad" width="600" height="220"></canvas><div class="row-btns"><button class="btn ghost" data-c>' + T('clear') + '</button><button class="btn" data-ok>' + T('save') + '</button></div>',
        { onClose: () => resolve(null) });
      const c = m.el.querySelector('canvas'), ctx = c.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.lineWidth = 3.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#0b2a6b';
      let drawing = false, drawn = false;
      const pos = (e) => { const r = c.getBoundingClientRect(); const p = e.touches ? e.touches[0] : e; return [(p.clientX - r.left) * c.width / r.width, (p.clientY - r.top) * c.height / r.height]; };
      const start = (e) => { e.preventDefault(); drawing = true; const [x, y] = pos(e); ctx.beginPath(); ctx.moveTo(x, y); };
      const move = (e) => { if (!drawing) return; e.preventDefault(); const [x, y] = pos(e); ctx.lineTo(x, y); ctx.stroke(); drawn = true; };
      const end = () => { drawing = false; };
      c.addEventListener('mousedown', start); c.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
      c.addEventListener('touchstart', start, { passive: false }); c.addEventListener('touchmove', move, { passive: false }); c.addEventListener('touchend', end);
      m.el.querySelector('[data-c]').onclick = () => { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); drawn = false; };
      m.el.querySelector('[data-ok]').onclick = () => { if (!drawn) return U.toast(T('drawFirst'), 'err'); const d = c.toDataURL('image/jpeg', 0.9); m.el.remove(); resolve(d); };
    });
  };

  V.adminPartnerEdit = async function (el, p) {
    const def = LN.defaults();
    const x = p.id ? (await DB.get('partners', p.id)) : { active: true, roiType: def.roiType, interest: def.interest, pfType: def.pfType, pfValue: def.pfValue, gstPct: def.gstPct, docFee: def.docFee, stampDuty: def.stampDuty, signDesig: 'Authorised Signatory' };
    const img = { p_logo: x.logo || '', p_sign: x.sign || '' };
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'adminPartners\')">‹ ' + T('back') + '</button><h2 class="page-title">🏦 ' + (p.id ? esc(x.name) : T('addPartner')) + '</h2><form id="pf" class="form">' +
      '<div class="card"><h3>' + T('partnerDetails') + '</h3>' + U.field('name', T('partnerName'), x.name, { required: true, placeholder: 'e.g. ABC Finance Pvt Ltd' }) +
      '<div class="grid2f">' + U.field('shortName', T('shortName'), x.shortName) + U.field('contactPerson', T('contactPerson'), x.contactPerson) + U.field('phone', T('phone'), x.phone) + U.field('email', T('email'), x.email) +
      U.field('gstin', 'GSTIN', x.gstin) + U.field('cin', 'CIN', x.cin) + U.field('reg', T('rbiReg'), x.reg) + U.field('website', T('website'), x.website) + '</div>' +
      U.field('address', T('address'), x.address, { type: 'textarea', rows: 2 }) + U.field('bankDetails', T('partnerBank'), x.bankDetails, { type: 'textarea', rows: 2 }) +
      U.field('active', T('active'), x.active !== false, { type: 'checkbox' }) + '</div>' +
      '<div class="card"><h3>' + T('logoSign') + '</h3>' + imgPicker('p_logo', T('logo'), img.p_logo) + imgPicker('p_sign', T('authSign'), img.p_sign, 'sign') +
      '<div class="grid2f">' + U.field('signName', T('signatoryName'), x.signName) + U.field('signDesig', T('signatoryDesig'), x.signDesig) + '</div></div>' +
      '<div class="card"><h3>' + T('defaultTerms') + '</h3><p class="muted small">' + T('partnerTermsNote') + '</p><div class="grid2f">' +
      U.field('roiType', T('roiType'), x.roiType, { type: 'select', options: [{ v: 'reducing', l: T('reducing') }, { v: 'flat', l: T('flat') }] }) + U.field('interest', T('roi') + ' %', x.interest, { type: 'number', step: '0.01' }) +
      U.field('pfType', T('processingFee'), x.pfType, { type: 'select', options: [{ v: 'pct', l: '% ' + T('ofLoan') }, { v: 'fixed', l: '₹ ' + T('fixed') }] }) + U.field('pfValue', T('processingFee') + ' (%/₹)', x.pfValue, { type: 'number', step: '0.01' }) +
      U.field('gstPct', T('gstOnPf') + ' %', x.gstPct, { type: 'number', step: '0.01' }) + U.field('docFee', T('docFee') + ' ₹', x.docFee, { type: 'number' }) + U.field('stampDuty', T('stampDuty') + ' ₹', x.stampDuty, { type: 'number' }) +
      U.field('penaltyAmt', T('penaltyDefault') + ' ₹', x.penaltyAmt, { type: 'number' }) + '</div></div>' +
      '<div class="card"><h3>' + T('partnerTemplates') + '</h3><p class="muted small">' + T('partnerTplNote') + ' ' + T('placeholders') + ': {name} {empId} {father} {address} {amount} {amountWords} {tenure} {emi} {netAmount} {charges} {loanNo} {date} {lender} {dealer} {guarantor}</p>' +
      U.field('letterTemplate', T('sanctionLetter'), x.letterTemplate, { type: 'textarea', rows: 5 }) + U.field('dpnTemplate', 'DPN', x.dpnTemplate, { type: 'textarea', rows: 3 }) +
      U.field('agreementTerms', T('loanAgreement') + ' – ' + T('terms') + ' (' + T('onePerLine') + ')', x.agreementTerms, { type: 'textarea', rows: 6 }) + U.field('terms', T('terms'), x.terms, { type: 'textarea', rows: 3 }) + '</div>' +
      '<div class="row-btns">' + (p.id ? '<button type="button" class="btn danger" id="pdel">🗑 ' + T('delete') + '</button>' : '') + '<button class="btn">' + T('save') + '</button></div></form>';
    App.bindImgPickers(el, img);
    const pd = U.$('#pdel');
    if (pd) pd.onclick = async () => {
      const used = (await DB.all('loans')).some((l) => l.partnerId === p.id);
      if (used) return U.toast(T('partnerInUse'), 'err');
      if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('partners', p.id); await LN.loadPartners(true); App.go('adminPartners'); }
    };
    U.$('#pf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const data = Object.assign({}, d, { active: !!d.active, interest: U.num(d.interest), pfValue: U.num(d.pfValue), gstPct: U.num(d.gstPct), docFee: U.num(d.docFee), stampDuty: U.num(d.stampDuty), penaltyAmt: U.num(d.penaltyAmt),
        logo: img.p_logo, sign: img.p_sign, updatedAt: DB.now() });
      U.loading(true);
      try {
        if (p.id) await DB.update('partners', p.id, data); else await DB.add('partners', Object.assign(data, { createdAt: DB.now() }));
        await LN.loadPartners(true); U.toast(T('saved'), 'ok'); App.go('adminPartners');
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  // ================= COMPANY PROFILE =================
  V.adminCompany = async function (el) {
    const c = Object.assign({}, PDF.company(), S.company || {});
    const img = { c_logo: (S.company || {}).logo || '', c_sign: (S.company || {}).sign || '' };
    el.innerHTML = '<h2 class="page-title">🏢 ' + T('companyProfile') + '</h2><p class="muted small">' + T('companyNote') + '</p><form id="cf" class="form">' +
      '<div class="card">' + U.field('name', T('companyName'), c.name, { required: true }) + U.field('address', T('address'), c.address, { type: 'textarea', rows: 2 }) +
      '<div class="grid2f">' + U.field('phone', T('phone'), c.phone) + U.field('email', T('email'), c.email) + U.field('gstin', 'GSTIN', c.gstin) + U.field('cin', 'CIN', c.cin) +
      U.field('pan', 'PAN', (S.company || {}).pan) + U.field('website', T('website'), (S.company || {}).website) + '</div></div>' +
      '<div class="card"><h3>' + T('logoSign') + '</h3>' + imgPicker('c_logo', T('logo') + ' (' + T('logoUsedIn') + ')', img.c_logo) + imgPicker('c_sign', T('authSign'), img.c_sign, 'sign') +
      '<div class="grid2f">' + U.field('signName', T('signatoryName'), (S.company || {}).signName) + U.field('signDesig', T('signatoryDesig'), (S.company || {}).signDesig || 'Authorised Signatory') + '</div></div>' +
      '<button class="btn block">' + T('save') + '</button></form>';
    App.bindImgPickers(el, img);
    U.$('#cf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const data = Object.assign(d, { logo: img.c_logo, sign: img.c_sign, updatedAt: DB.now() });
      U.loading(true);
      try { await DB.set('settings', 'company', data); S.company = data; U.toast(T('saved'), 'ok'); App.applyBrandHeader && App.applyBrandHeader(); }
      catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };
})();
