// ---------- Admin: employee full statement, extra reports, festival themes ----------
(function () {
  const V = window.Views, esc = U.esc, A = window.Admin, R = window.Reports, LN = window.Loan;
  const n2 = (v) => Number(v || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const monthsBetween = (from, to) => { const out = []; let [y, m] = from.split('-').map(Number); const [ty, tm] = to.split('-').map(Number); while (y < ty || (y === ty && m <= tm)) { out.push(y + '-' + U.pad(m)); m++; if (m > 12) { m = 1; y++; } if (out.length > 36) break; } return out; };

  // ================= EMPLOYEE FULL STATEMENT (admin only) =================
  async function buildStatement(id, from, to) {
    const [e, sal, pays, loans, wal, docs, warns, att] = await Promise.all([DB.get('employees', id), DB.get('salary', id), DB.query('payments', [['empId', '==', id]]), DB.query('loans', [['empId', '==', id]]),
      DB.query('wallet', [['empId', '==', id]]), DB.query('documents', [['empId', '==', id]]), DB.query('warnings', [['empId', '==', id]]), DB.query('attendance', [['empId', '==', id]])]);
    const months = monthsBetween(from, to);
    const salRows = [];
    for (const m of months) {
      if (m > U.monthKey()) continue;
      const r = (await A.salaryRows(m)).find((x) => x.emp.id === id);
      if (r) salRows.push(Object.assign({ month: m }, r));
    }
    const inRange = (d) => d && d.slice(0, 7) >= from && d.slice(0, 7) <= to;
    return {
      e: e || {}, monthly: (sal || {}).monthly || 0, months, salRows,
      pays: pays.filter((p) => inRange(p.date)).sort((a, b) => a.date.localeCompare(b.date)),
      loans, wal: wal.sort((a, b) => String(a.date).localeCompare(b.date)), docs, warns, att: att.filter((a) => inRange(a.date))
    };
  }

  V.adminEmpStatement = async function (el, p) {
    const emps = await A.employees(true);
    const id = p.id || (emps[0] && emps[0].id);
    const to = p.to || U.monthKey(); const from = p.from || (() => { const d = new Date(); d.setMonth(d.getMonth() - 5); return U.monthKey(d); })();
    el.innerHTML = '<h2 class="page-title">📋 ' + T('empFullStatement') + '</h2><p class="muted small">🔒 ' + T('empStatementNote') + '</p>' +
      '<div class="card form"><label class="fld"><span>' + T('employee') + '</span><select id="se">' + emps.map((e) => '<option value="' + esc(e.id) + '"' + (e.id === id ? ' selected' : '') + '>' + esc(e.name + ' (' + e.id + ')') + '</option>').join('') + '</select></label>' +
      '<div class="grid2f"><label class="fld"><span>' + T('fromMonth') + '</span>' + App.monthSelect('sf', from) + '</label><label class="fld"><span>' + T('toMonth') + '</span>' + App.monthSelect('st', to) + '</label></div>' +
      '<div class="row-btns"><button class="btn" id="sx">⬇ Excel</button><button class="btn" id="sp">⬇ PDF</button></div></div><div id="sbody"><div class="skeleton"></div></div>';
    const go = () => App.go('adminEmpStatement', { id: U.$('#se').value, from: U.$('#sf').value, to: U.$('#st').value });
    U.$('#se').onchange = go; U.$('#sf').onchange = go; U.$('#st').onchange = go;
    if (!id) { U.$('#sbody').innerHTML = U.empty(T('noEmployees')); return; }
    if (from > to) { U.$('#sbody').innerHTML = '<div class="note">' + T('invalidRange') + '</div>'; return; }
    const d = await buildStatement(id, from, to);
    const e = d.e;
    const tot = (k) => U.round2(d.salRows.reduce((s, r) => s + U.num(r[k]), 0));
    const payTot = U.round2(d.pays.reduce((s, x) => s + U.num(x.amount), 0));
    const walBal = Targets.balance(d.wal);
    const kv = (k, v) => window.kvRow(k, v);
    U.$('#sbody').innerHTML =
      '<div class="card"><div class="row">' + App.empAvatar(e, 64) + '<div><h3 style="margin:0">' + esc(e.name) + '</h3><small class="muted">' + esc(e.id) + ' · ' + esc(e.designation || '') + ' · ' + esc(e.mobile || '') + '</small></div></div>' +
      '<div class="kv">' + A.PROFILE_FIELDS.map((f) => kv(T(f[1]), esc(f[2] === 'date' ? U.fmtDate(e[f[0]]) : (e[f[0]] || '-')))).join('') + kv('🔒 ' + T('monthlySalary'), U.money(d.monthly)) + '</div></div>' +
      '<div class="stats4"><div><b>' + U.money(tot('earned')) + '</b><small>' + T('earnedSalary') + '</small></div><div><b>' + U.money(payTot) + '</b><small>' + T('paidAdvance') + '</small></div><div><b>' + U.money(tot('net')) +
      '</b><small>' + T('netPayable') + '</small></div><div><b>' + U.money(walBal) + '</b><small>' + T('wallet') + '</small></div></div>' +
      '<h3 class="sec-title">💵 ' + T('salary') + '</h3><div class="card table-wrap"><table class="tbl"><thead><tr><th>' + T('month') + '</th><th>' + T('presentDays') + '</th><th>' + T('payableDays') + '</th><th>' + T('earnedSalary') + '</th><th>' + T('bonus') +
      '</th><th>' + T('deduction') + '</th><th>' + T('loanEmi') + '</th><th>' + T('paidAdvance') + '</th><th>' + T('netPayable') + '</th></tr></thead><tbody>' +
      d.salRows.map((r) => '<tr><td>' + U.monthLabel(r.month) + '</td><td>' + r.present + '</td><td>' + r.payable + '</td><td>' + n2(r.earned) + '</td><td>' + n2(r.bonus) + '</td><td>' + n2(r.ded) + '</td><td>' + n2(r.emi) + '</td><td>' + n2(r.paid) + '</td><td><b>' + n2(r.net) + '</b></td></tr>').join('') +
      '</tbody><tfoot><tr><td>' + T('total') + '</td><td>' + tot('present') + '</td><td>' + tot('payable') + '</td><td>' + n2(tot('earned')) + '</td><td>' + n2(tot('bonus')) + '</td><td>' + n2(tot('ded')) + '</td><td>' + n2(tot('emi')) + '</td><td>' + n2(tot('paid')) + '</td><td>' + n2(tot('net')) + '</td></tr></tfoot></table></div>' +
      '<h3 class="sec-title">📒 ' + T('paymentLedger') + ' (' + U.money(payTot) + ')</h3>' + (d.pays.length ? '<div class="card list">' + d.pays.map((x) => '<div class="li"><div class="grow"><b>' + U.fmtDate(x.date) + '</b><small>' + esc(T('pt_' + (x.type || 'other'))) + ' · ' + esc(x.mode || '') + (x.note ? ' · ' + esc(x.note) : '') + '</small></div><b class="amt">' + U.money(x.amount) + '</b></div>').join('') + '</div>' : U.empty(T('noPayments'))) +
      '<h3 class="sec-title">💰 ' + T('loans') + '</h3>' + (d.loans.length ? d.loans.map((l) => LN.loanCard(l, false)).join('') : U.empty(T('noLoans'))) +
      '<h3 class="sec-title">💼 ' + T('wallet') + ' (' + U.money(walBal) + ')</h3>' + (d.wal.length ? '<div class="card list">' + d.wal.map((x) => '<div class="li"><div class="grow"><b>' + esc(T('src_' + (x.source || 'adjust'))) + '</b><small>' + U.fmtDate(x.date) + (x.title ? ' · ' + esc(x.title) : '') + '</small></div><b class="' + (x.type === 'credit' ? 'good' : 'low') + '">' + (x.type === 'credit' ? '+' : '−') + U.money(x.amount) + '</b></div>').join('') + '</div>' : U.empty()) +
      '<div class="card kv">' + kv(T('documents'), d.docs.length) + kv(T('warningLetters'), d.warns.length) + '</div>';
    U.$$('.loan-card', U.$('#sbody')).forEach((c) => c.onclick = () => App.go('adminLoanDetail', { id: c.dataset.loan }));
    U.$('#sx').onclick = () => statementXlsx(d, from, to);
    U.$('#sp').onclick = () => statementPdf(d, from, to);
  };

  function sections(d) {
    const e = d.e;
    return {
      profile: A.PROFILE_FIELDS.map((f) => [I18N.dict.en[f[1]] || f[1], f[2] === 'date' ? U.fmtDate(e[f[0]]) : (e[f[0]] || '-')]).concat([['Employee ID', e.id], ['Monthly Salary', d.monthly]]),
      salary: d.salRows.map((r) => [U.monthLabel(r.month).replace(/[^\x20-\x7E]/g, '') || r.month, r.present, r.payable, r.earned, r.bonus, r.ded, r.emi, r.paid, r.net]),
      pays: d.pays.map((x) => [U.fmtDate(x.date), x.type || '', x.mode || '', U.num(x.amount), x.note || '']),
      loans: d.loans.map((l) => { const t = LN.terms(l); return [l.loanNo || '-', l.partnerName || 'Self', t.P, t.n, t.emi, l.status, ['disbursed', 'closed'].includes(l.status) ? LN.outstanding(l) : '']; }),
      wal: d.wal.map((x) => [U.fmtDate(x.date), x.source || '', x.title || '', x.type === 'credit' ? U.num(x.amount) : '', x.type !== 'credit' ? U.num(x.amount) : ''])
    };
  }
  const SAL_H = ['Month', 'Present', 'Payable Days', 'Earned', 'Bonus', 'Deduction', 'Loan EMI', 'Paid/Advance', 'Net'];
  function statementXlsx(d, from, to) {
    const s = sections(d), wb = XLSX.utils.book_new();
    const add = (name, aoa) => { const ws = XLSX.utils.aoa_to_sheet(aoa); XLSX.utils.book_append_sheet(wb, ws, name); };
    add('Profile', [[PDF.company().name], ['Employee Statement ' + from + ' to ' + to], []].concat(s.profile));
    add('Salary', [SAL_H].concat(s.salary));
    add('Payments', [['Date', 'Type', 'Mode', 'Amount', 'Note']].concat(s.pays));
    add('Loans', [['Loan No', 'Lender', 'Amount', 'Tenure', 'EMI', 'Status', 'Outstanding']].concat(s.loans));
    add('Wallet', [['Date', 'Source', 'Title', 'Credit', 'Debit']].concat(s.wal));
    U.saveFile(safeName('Statement_' + d.e.id + '_' + from + '_' + to) + '.xlsx', XLSX.write(wb, { bookType: 'xlsx', type: 'base64' }), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  }
  async function statementPdf(d, from, to) {
    const H = PDF._, s = sections(d), e = d.e;
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'EMPLOYEE STATEMENT');
    const W = doc.internal.pageSize.getWidth();
    doc.setFontSize(9); doc.text(H.L('Period: ' + from + ' to ' + to + '   |   Generated: ' + U.fmtDT(new Date())), 14, y - 4);
    if (e.photo) await PDF.addImageFit(doc, e.photo, W - 40, y, 26, 30);
    const tbl = (head, body, opts) => { doc.autoTable(Object.assign({ startY: y, head: head ? [head.map(H.L)] : undefined, body: body.map((r) => r.map((c) => H.L(typeof c === 'number' ? n2(c) : c))), theme: 'grid', styles: { fontSize: 8.5, cellPadding: 1.5 }, headStyles: { fillColor: [218, 37, 29] }, margin: { left: 14, right: 14 } }, opts || {})); y = doc.lastAutoTable.finalY + 6; };
    const head = (t) => { if (y > 260) { doc.addPage(); y = 20; } doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text(t, 14, y); y += 2; };
    tbl(null, s.profile, { margin: { left: 14, right: 46 }, columnStyles: { 0: { cellWidth: 45, fontStyle: 'bold', fillColor: [250, 246, 246] } } });
    head('Salary'); tbl(SAL_H, s.salary);
    head('Payments'); tbl(['Date', 'Type', 'Mode', 'Amount', 'Note'], s.pays.length ? s.pays : [['-', '', '', '', '']]);
    head('Loans'); tbl(['Loan No', 'Lender', 'Amount', 'Tenure', 'EMI', 'Status', 'Outstanding'], s.loans.length ? s.loans : [['-', '', '', '', '', '', '']]);
    head('Wallet'); tbl(['Date', 'Source', 'Title', 'Credit', 'Debit'], s.wal.length ? s.wal : [['-', '', '', '', '']]);
    await PDF.savePdf(doc, safeName('Statement_' + e.id + '_' + from + '_' + to) + '.pdf');
  }

  // ================= EXTRA REPORTS =================
  ['emiDue', 'partnerLoans', 'docStatus', 'insurance', 'walletReport', 'examReport', 'absentReport', 'todoReport', 'nomineeReport'].forEach((t) => { if (!R.TYPES.includes(t)) R.TYPES.push(t); });
  const base = R.build;
  R.build = async function (type, month) {
    if (type === 'emiDue') {
      const loans = (await DB.all('loans')).filter((l) => l.status === 'disbursed');
      const rows = [];
      loans.forEach((l) => LN.scheduleStatus(l).forEach((x) => {
        if (x.status === 'paid') return;
        if (x.due.slice(0, 7) === month || x.status === 'overdue' || (x.status === 'partial' && x.due < U.dateKey())) rows.push([l.empId, l.empName, l.loanNo || '-', l.partnerName || 'Self', U.fmtDate(x.due), x.emi, x.paidAmt, U.round2(x.emi - x.paidAmt), x.status]);
      }));
      rows.sort((a, b) => a[4].split('-').reverse().join('').localeCompare(b[4].split('-').reverse().join('')));
      return { title: 'EMI Due & Overdue', columns: ['Emp ID', 'Name', 'Loan No', 'Lender', 'Due Date', 'EMI', 'Paid', 'Balance', 'Status'], rows, foot: ['', 'TOTAL', '', '', '', U.round2(rows.reduce((s, r) => s + r[5], 0)), U.round2(rows.reduce((s, r) => s + r[6], 0)), U.round2(rows.reduce((s, r) => s + r[7], 0)), ''] };
    }
    if (type === 'partnerLoans') {
      const [loans, partners] = await Promise.all([DB.all('loans'), LN.loadPartners(true)]);
      const groups = [{ id: '', name: PDF.company().name + ' (Self)' }].concat(partners);
      return { title: 'Lender-wise Loans', all: true, columns: ['Lender', 'Applications', 'Sanctioned', 'Running', 'Closed', 'Sanctioned Amt', 'Disbursed Amt', 'Outstanding', 'Overdue EMI'],
        rows: groups.map((g) => { const ls = loans.filter((l) => (l.partnerId || '') === g.id); const run = ls.filter((l) => l.status === 'disbursed');
          return [g.name, ls.length, ls.filter((l) => ['approved', 'disbursed', 'closed'].includes(l.status)).length, run.length, ls.filter((l) => l.status === 'closed').length,
            U.round2(ls.filter((l) => ['approved', 'disbursed', 'closed'].includes(l.status)).reduce((s, l) => s + LN.terms(l).P, 0)), U.round2(ls.filter((l) => ['disbursed', 'closed'].includes(l.status)).reduce((s, l) => s + LN.terms(l).net, 0)),
            U.round2(run.reduce((s, l) => s + LN.outstanding(l), 0)), run.reduce((s, l) => s + LN.overdueCount(l), 0)]; }) };
    }
    if (type === 'docStatus') {
      const [docs, reqs] = await Promise.all([DB.all('documents'), DB.all('docrequests')]);
      const rows = docs.map((d) => [d.empId, d.empName, d.category, d.name, U.fmtDate(d.at), d.status, d.remark || '', d.requestId ? 'Requested' : 'Self'])
        .concat(reqs.filter((r) => r.status === 'open').map((r) => [r.empId, r.empName, r.category || '', r.title, U.fmtDate(r.at), 'not uploaded', r.remark || '', 'Requested']));
      return { title: 'Document Status', all: true, columns: ['Emp ID', 'Name', 'Category', 'Document', 'Date', 'Status', 'Remark', 'Source'], rows };
    }
    if (type === 'insurance') {
      const docs = await DB.query('documents', [['category', '==', 'Staff Insurance']]);
      return { title: 'Staff Insurance', all: true, columns: ['Emp ID', 'Name', 'Insurer', 'Policy No', 'Sum Insured', 'Valid Till', 'Status'],
        rows: docs.map((d) => { const m = d.meta || {}; return [d.empId, d.empName, m.insurer || '', m.policyNo || '', m.sumInsured || '', m.expiry ? U.fmtDate(m.expiry) : '', m.expiry && m.expiry < U.dateKey() ? 'EXPIRED' : d.status]; }) };
    }
    if (type === 'walletReport') {
      const [emps, wal] = await Promise.all([A.employees(true), DB.all('wallet')]);
      const rows = emps.map((e) => { const mine = wal.filter((w) => w.empId === e.id); const mm = mine.filter((w) => String(w.date).startsWith(month));
        return [e.id, e.name, U.round2(mm.filter((w) => w.type === 'credit').reduce((s, w) => s + U.num(w.amount), 0)), U.round2(mm.filter((w) => w.source === 'release').reduce((s, w) => s + U.num(w.amount), 0)), Targets.balance(mine)]; })
        .filter((r) => r[2] || r[3] || r[4]);
      return { title: 'Wallet & Payouts', columns: ['Emp ID', 'Name', 'Credited (month)', 'Released (month)', 'Balance'], rows, foot: ['', 'TOTAL', U.round2(rows.reduce((s, r) => s + r[2], 0)), U.round2(rows.reduce((s, r) => s + r[3], 0)), U.round2(rows.reduce((s, r) => s + r[4], 0))] };
    }
    if (type === 'examReport') {
      const [emps, exams, atts] = await Promise.all([A.employees(), DB.all('exams'), DB.all('attempts')]);
      const rows = [];
      exams.forEach((x) => emps.filter((e) => Training.assigned(Object.assign({}, x, { active: true }), e.id)).forEach((e) => {
        const mine = atts.filter((a) => a.examId === x.id && a.empId === e.id); const b = Training.bestAttempt(x, mine);
        rows.push([x.title, e.id, e.name, mine.length + '/' + x.maxAttempts, b ? b.g.score + '/' + b.g.total : '', b ? b.g.pct + '%' : '', b ? (b.g.passed ? 'PASS' : 'FAIL') : 'Not attempted']);
      }));
      return { title: 'Exam Results', all: true, columns: ['Exam', 'Emp ID', 'Name', 'Attempts', 'Score', 'Percent', 'Result'], rows };
    }
    if (type === 'absentReport') {
      const [emps, att, hol] = await Promise.all([A.employees(), DB.query('attendance', [['month', '==', month]]), Cal.holidays(month)]);
      const upto = Cal.upto(month);
      const rows = emps.map((e) => {
        const map = {}; att.filter((a) => a.empId === e.id).forEach((a) => { map[a.date] = a; });
        const ds = []; for (let d = 1; d <= upto; d++) { const c = Cal.dayCode(e, month, d, map[month + '-' + U.pad(d)], hol); if (c === 'A' || c === 'R') ds.push(d); }
        return [e.id, e.name, ds.length, ds.join(', ')];
      });
      return { title: 'Absent Report', columns: ['Emp ID', 'Name', 'Absent Days', 'Dates'], rows };
    }
    if (type === 'todoReport') {
      const list = await DB.query('todos', [['by', '==', 'admin']]);
      return { title: 'Staff Tasks', all: true, columns: ['Emp ID', 'Name', 'Task', 'Due', 'Status', 'Done At'],
        rows: list.sort((a, b) => (a.dueAt || 0) - (b.dueAt || 0)).map((t) => [t.empId, t.empName, t.title, t.dueAt ? U.fmtDT(t.dueAt) : '', t.done ? 'Done' : (t.dueAt < Date.now() ? 'Overdue' : 'Pending'), t.doneAt ? U.fmtDT(t.doneAt) : '']) };
    }
    if (type === 'nomineeReport') {
      const emps = await A.employees(true);
      return { title: 'Employee Family & Nominee', all: true, columns: ['Emp ID', 'Name', 'Father', 'Mother', 'Nominee', 'Relation', 'Nominee DOB', 'Nominee Mobile', 'Share %'],
        rows: emps.map((e) => [e.id, e.name, e.fatherName || '', e.motherName || '', e.nomineeName || '', e.nomineeRelation || '', e.nomineeDob ? U.fmtDate(e.nomineeDob) : '', e.nomineeMobile || '', e.nomineeShare || '']) };
    }
    return base(type, month);
  };

  // ================= FESTIVAL THEMES =================
  const THEMES = {
    default: { c: ['#DA251D', '#B51C15', '#FDECEB', '#F5F3F2'], e: '', en: 'Default', hi: 'डिफ़ॉल्ट' },
    diwali: { c: ['#E65100', '#BF360C', '#FFF3E0', '#FFF8EE'], e: '🪔✨🪔', en: 'Happy Diwali!', hi: 'शुभ दीपावली!', g: 'linear-gradient(90deg,#7b1f00,#e65100,#ffb300,#e65100,#7b1f00)' },
    dhanteras: { c: ['#C79100', '#9C6F00', '#FFF8E1', '#FFFBF0'], e: '🪙✨', en: 'Happy Dhanteras!', hi: 'धनतेरस की शुभकामनाएं!', g: 'linear-gradient(90deg,#8d6e00,#ffca28,#8d6e00)' },
    holi: { c: ['#D81B60', '#AD1457', '#FCE4EC', '#FFF5FA'], e: '🎨🌈💦', en: 'Happy Holi!', hi: 'होली की शुभकामनाएं!', g: 'linear-gradient(90deg,#e91e63,#ff9800,#ffeb3b,#4caf50,#2196f3,#9c27b0)' },
    independence: { c: ['#E67E00', '#B85F00', '#FFF4E5', '#F4FAF2'], e: '🇮🇳', en: 'Happy Independence Day!', hi: 'स्वतंत्रता दिवस की शुभकामनाएं!', g: 'linear-gradient(180deg,#FF9933 0 33%,#ffffff 33% 66%,#138808 66%)', dark: true },
    republic: { c: ['#E67E00', '#B85F00', '#FFF4E5', '#F4FAF2'], e: '🇮🇳', en: 'Happy Republic Day!', hi: 'गणतंत्र दिवस की शुभकामनाएं!', g: 'linear-gradient(180deg,#FF9933 0 33%,#ffffff 33% 66%,#138808 66%)', dark: true },
    navratri: { c: ['#8E24AA', '#6A1B9A', '#F3E5F5', '#FBF5FC'], e: '🪔🌺', en: 'Happy Navratri!', hi: 'नवरात्रि की शुभकामनाएं!', g: 'linear-gradient(90deg,#6a1b9a,#d81b60,#ff9800,#d81b60,#6a1b9a)' },
    dussehra: { c: ['#EF6C00', '#C43E00', '#FFF3E0', '#FFF9F2'], e: '🏹🔥', en: 'Happy Dussehra!', hi: 'दशहरा की शुभकामनाएं!', g: 'linear-gradient(90deg,#c43e00,#ff9800,#c43e00)' },
    rakhi: { c: ['#EC407A', '#C2185B', '#FCE4EC', '#FFF7FA'], e: '🪢💝', en: 'Happy Raksha Bandhan!', hi: 'रक्षाबंधन की शुभकामनाएं!', g: 'linear-gradient(90deg,#c2185b,#ff80ab,#ffd54f,#ff80ab,#c2185b)' },
    janmashtami: { c: ['#1565C0', '#0D47A1', '#E3F2FD', '#F4F9FF'], e: '🦚🪈', en: 'Happy Janmashtami!', hi: 'जन्माष्टमी की शुभकामनाएं!', g: 'linear-gradient(90deg,#0d47a1,#00897b,#fbc02d,#00897b,#0d47a1)' },
    ganesh: { c: ['#FF8F00', '#E65100', '#FFF8E1', '#FFFBF2'], e: '🐘🌺', en: 'Ganpati Bappa Morya!', hi: 'गणपति बप्पा मोरया!', g: 'linear-gradient(90deg,#e65100,#ffb300,#e53935,#ffb300,#e65100)' },
    makar: { c: ['#F9A825', '#F57F17', '#FFFDE7', '#FFFDF4'], e: '🪁☀️', en: 'Happy Makar Sankranti!', hi: 'मकर संक्रांति की शुभकामनाएं!', g: 'linear-gradient(90deg,#29b6f6,#ffee58,#ff7043,#29b6f6)' },
    eid: { c: ['#2E7D32', '#1B5E20', '#E8F5E9', '#F4FBF4'], e: '🌙✨', en: 'Eid Mubarak!', hi: 'ईद मुबारक!', g: 'linear-gradient(90deg,#1b5e20,#43a047,#c0ca33,#43a047,#1b5e20)' },
    christmas: { c: ['#C62828', '#8E0000', '#FFEBEE', '#F7FBF7'], e: '🎄🎅⭐', en: 'Merry Christmas!', hi: 'मेरी क्रिसमस!', g: 'linear-gradient(90deg,#1b5e20,#c62828,#1b5e20)' },
    newyear: { c: ['#3949AB', '#1A237E', '#E8EAF6', '#F5F6FC'], e: '🎉🎆', en: 'Happy New Year!', hi: 'नववर्ष की शुभकामनाएं!', g: 'linear-gradient(90deg,#1a237e,#7c4dff,#ffd740,#7c4dff,#1a237e)' }
  };
  App.THEMES = THEMES;

  App.applyTheme = function () {
    let st = S.settings || null;
    if (!st) { try { st = JSON.parse(localStorage.getItem('themeCache') || 'null'); } catch (e) { st = null; } }
    st = st || {};
    let key = st.theme || 'default';
    if (st.themeUntil && st.themeUntil < U.dateKey()) key = 'default';
    const th = THEMES[key] || THEMES.default;
    const r = document.documentElement.style;
    r.setProperty('--red', th.c[0]); r.setProperty('--red-d', th.c[1]); r.setProperty('--red-l', th.c[2]); r.setProperty('--bg', th.c[3]);
    document.body.dataset.theme = key;
    const meta = document.querySelector('meta[name=theme-color]'); if (meta) meta.setAttribute('content', th.c[0]);
    try { if (S.settings) localStorage.setItem('themeCache', JSON.stringify({ theme: st.theme, themeUntil: st.themeUntil, themeGreeting: st.themeGreeting })); } catch (e) { }
    U.$$('.fest-bar').forEach((x) => x.remove());
    if (key === 'default') return;
    const msg = (st.themeGreeting || '').trim() || (I18N.lang === 'hi' ? th.hi : th.en);
    const bar = document.createElement('div');
    bar.className = 'fest-bar' + (th.dark ? ' dark' : '');
    bar.style.background = th.g || th.c[0];
    bar.innerHTML = '<span>' + th.e + '</span> <b>' + esc(msg) + '</b> <span>' + th.e + '</span> <small>— ' + esc(PDF.company().name) + '</small>';
    const host = document.querySelector('.topbar') || document.querySelector('.login-page');
    if (host) { if (host.classList.contains('topbar')) host.after(bar); else host.prepend(bar); }
  };

  V.adminTheme = async function (el) {
    const st = S.settings || {};
    let sel = st.theme || 'default';
    el.innerHTML = '<h2 class="page-title">🎨 ' + T('festivalTheme') + '</h2><p class="muted small">' + T('themeNote') + '</p>' +
      '<div class="theme-grid">' + Object.keys(THEMES).map((k) => { const th = THEMES[k]; return '<button class="theme-card' + (k === sel ? ' on' : '') + '" data-t="' + k + '"><i style="background:' + (th.g || th.c[0]) + '"></i><b>' + (th.e || '🎨') + '</b><span>' + esc(I18N.lang === 'hi' ? th.hi : th.en) + '</span></button>'; }).join('') + '</div>' +
      '<form id="thf" class="card form">' + U.field('themeGreeting', T('customGreeting'), st.themeGreeting || '', { placeholder: T('greetingPh') }) + U.field('themeUntil', T('themeUntil'), st.themeUntil || '', { type: 'date' }) +
      '<p class="muted small">' + T('themeUntilNote') + '</p><button class="btn block">' + T('save') + '</button></form>';
    U.$$('[data-t]').forEach((b) => b.onclick = () => {
      sel = b.dataset.t; U.$$('[data-t]').forEach((x) => x.classList.toggle('on', x === b));
      const keep = S.settings.theme; S.settings.theme = sel; App.applyTheme(); S.settings.theme = keep;
    });
    U.$('#thf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const upd = { theme: sel, themeGreeting: d.themeGreeting, themeUntil: d.themeUntil };
      try { await DB.set('settings', 'app', upd, true); Object.assign(S.settings, upd); App.applyTheme(); U.toast(T('saved'), 'ok'); } catch (e) { U.toast(e.message, 'err'); }
    };
  };
})();
