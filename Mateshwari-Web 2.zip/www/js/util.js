// ---------- Utility helpers ----------
(function () {
  const U = {};

  U.esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  U.$ = (sel, root) => (root || document).querySelector(sel);
  U.$$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  U.pad = (n) => String(n).padStart(2, '0');
  U.dateKey = (d) => { d = d || new Date(); return d.getFullYear() + '-' + U.pad(d.getMonth() + 1) + '-' + U.pad(d.getDate()); };
  U.monthKey = (d) => { d = d || new Date(); return d.getFullYear() + '-' + U.pad(d.getMonth() + 1); };
  U.daysInMonth = (m) => { const [y, mo] = m.split('-').map(Number); return new Date(y, mo, 0).getDate(); };
  U.toDate = (v) => {
    if (!v) return null;
    if (v.toDate) return v.toDate();
    if (v instanceof Date) return v;
    if (typeof v === 'number') return new Date(v);
    if (typeof v === 'string') return new Date(v);
    if (v.seconds) return new Date(v.seconds * 1000);
    return null;
  };
  U.fmtDate = (v) => {
    const d = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? new Date(v + 'T00:00:00') : U.toDate(v);
    if (!d || isNaN(d)) return '-';
    return U.pad(d.getDate()) + '-' + U.pad(d.getMonth() + 1) + '-' + d.getFullYear();
  };
  U.fmtTime = (v) => {
    const d = U.toDate(v); if (!d || isNaN(d)) return '-';
    let h = d.getHours(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
    return U.pad(h) + ':' + U.pad(d.getMinutes()) + ' ' + ap;
  };
  U.fmtDT = (v) => { const d = U.toDate(v); return d ? U.fmtDate(d) + ' ' + U.fmtTime(d) : '-'; };
  U.monthLabel = (m) => {
    const [y, mo] = m.split('-').map(Number);
    const names = I18N.lang === 'hi'
      ? ['जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर']
      : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return names[mo - 1] + ' ' + y;
  };
  U.money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  U.moneyPlain = (n) => 'Rs. ' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  U.num = (v) => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };
  U.round2 = (n) => Math.round(n * 100) / 100;

  // Indian number to words (for DPN / letters)
  U.numToWords = function (num) {
    num = Math.round(Number(num) || 0);
    if (num === 0) return 'Zero';
    const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    const two = (n) => n < 20 ? a[n] : b[Math.floor(n / 10)] + (n % 10 ? ' ' + a[n % 10] : '');
    const three = (n) => (n >= 100 ? a[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' : '') : '') + (n % 100 ? two(n % 100) : '');
    let out = [];
    const crore = Math.floor(num / 10000000); num %= 10000000;
    const lakh = Math.floor(num / 100000); num %= 100000;
    const thousand = Math.floor(num / 1000); num %= 1000;
    if (crore) out.push(three(crore) + ' Crore');
    if (lakh) out.push(two(lakh) + ' Lakh');
    if (thousand) out.push(two(thousand) + ' Thousand');
    if (num) out.push(three(num));
    return out.join(' ');
  };

  U.emi = function (P, ratePA, months) {
    P = U.num(P); months = Math.max(1, parseInt(months) || 1);
    const r = U.num(ratePA) / 12 / 100;
    if (!r) return U.round2(P / months);
    return U.round2(P * r * Math.pow(1 + r, months) / (Math.pow(1 + r, months) - 1));
  };

  // Haversine distance in meters
  U.distance = function (lat1, lon1, lat2, lon2) {
    const R = 6371000, toR = (x) => x * Math.PI / 180;
    const dLat = toR(lat2 - lat1), dLon = toR(lon2 - lon1);
    const s = Math.sin(dLat / 2) ** 2 + Math.cos(toR(lat1)) * Math.cos(toR(lat2)) * Math.sin(dLon / 2) ** 2;
    return Math.round(2 * R * Math.asin(Math.sqrt(s)));
  };

  U.getLocation = async function () {
    const C = window.Capacitor;
    const geo = C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.Geolocation;
    if (geo) {
      try {
        const perm = await geo.checkPermissions();
        if (perm.location !== 'granted') await geo.requestPermissions();
      } catch (e) { /* ignore */ }
      const p = await geo.getCurrentPosition({ enableHighAccuracy: true, timeout: 25000, maximumAge: 0 });
      return { lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy || 0), mocked: !!p.coords.isMock };
    }
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('GPS not supported'));
      navigator.geolocation.getCurrentPosition(
        (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy || 0), mocked: false }),
        (e) => reject(new Error(e.code === 1 ? T('gpsDenied') : T('gpsFailed'))),
        { enableHighAccuracy: true, timeout: 25000, maximumAge: 0 });
    });
  };

  // Compress an image File to a JPEG dataURL
  U.compressImage = function (file, maxSide, quality) {
    maxSide = maxSide || 800; quality = quality || 0.75;
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onerror = () => reject(new Error('read failed'));
      fr.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error('image failed'));
        img.onload = () => {
          let w = img.width, h = img.height;
          const sc = Math.min(1, maxSide / Math.max(w, h));
          w = Math.round(w * sc); h = Math.round(h * sc);
          const c = document.createElement('canvas'); c.width = w; c.height = h;
          const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          resolve(c.toDataURL('image/jpeg', quality));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  };
  U.fileToDataURL = (file) => new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(file); });

  U.pickFile = function (accept) {
    return new Promise((resolve) => {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = accept || '*/*';
      inp.style.display = 'none';
      inp.onchange = () => { resolve(inp.files && inp.files[0]); inp.remove(); };
      document.body.appendChild(inp); inp.click();
    });
  };

  // Save / share a file (base64 without prefix)
  U.saveFile = async function (filename, base64, mime) {
    const C = window.Capacitor;
    if (C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.Filesystem) {
      const FS = C.Plugins.Filesystem;
      const r = await FS.writeFile({ path: filename, data: base64, directory: 'CACHE' });
      try {
        await C.Plugins.Share.share({ title: filename, files: [r.uri], dialogTitle: filename });
      } catch (e) {
        if (!/cancel/i.test(String(e && e.message))) {
          try { await FS.writeFile({ path: filename, data: base64, directory: 'DOCUMENTS' }); U.toast(T('savedDocuments')); }
          catch (e2) { U.toast(T('saveFailed') + ': ' + (e2.message || e2), 'err'); }
        }
      }
      return;
    }
    const a = document.createElement('a');
    a.href = 'data:' + (mime || 'application/octet-stream') + ';base64,' + base64;
    a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  };
  U.openDataUrl = function (name, dataUrl) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(dataUrl || '');
    if (!m) return;
    U.saveFile(name, m[2], m[1]);
  };

  // ---------- UI: toast / modal / loader ----------
  U.toast = function (msg, type) {
    U.$$('.toast').forEach((t) => t.remove());
    const el = document.createElement('div');
    el.className = 'toast ' + (type || '');
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.classList.add('show'), 10);
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3200);
  };

  U.loading = function (on, text) {
    let el = document.getElementById('loader');
    if (on) {
      if (!el) { el = document.createElement('div'); el.id = 'loader'; document.body.appendChild(el); }
      el.innerHTML = '<div class="spin"></div><div>' + U.esc(text || T('pleaseWait')) + '</div>';
      el.style.display = 'flex';
    } else if (el) el.style.display = 'none';
  };

  // modal(html, {title, onOpen, wide}) -> returns {el, close}
  U.modal = function (title, bodyHtml, opts) {
    opts = opts || {};
    const wrap = document.createElement('div');
    wrap.className = 'modal-wrap';
    wrap.innerHTML = '<div class="modal ' + (opts.wide ? 'wide' : '') + '"><div class="modal-head"><h3>' + U.esc(title) +
      '</h3><button class="icon-btn" data-close>✕</button></div><div class="modal-body">' + bodyHtml + '</div></div>';
    document.body.appendChild(wrap);
    const close = () => { wrap.remove(); if (opts.onClose) opts.onClose(); };
    wrap.querySelector('[data-close]').onclick = close;
    wrap.addEventListener('click', (e) => { if (e.target === wrap && !opts.sticky) close(); });
    const api = { el: wrap, close };
    if (opts.onOpen) opts.onOpen(wrap, api);
    return api;
  };

  U.confirm = function (msg, okText) {
    return new Promise((resolve) => {
      const m = U.modal(T('confirm'), '<p>' + U.esc(msg) + '</p><div class="row-btns"><button class="btn ghost" data-no>' + T('cancel') +
        '</button><button class="btn" data-yes>' + U.esc(okText || T('yes')) + '</button></div>', { onClose: () => resolve(false) });
      m.el.querySelector('[data-no]').onclick = () => { m.close(); };
      m.el.querySelector('[data-yes]').onclick = () => { resolve(true); m.el.remove(); };
    });
  };

  U.prompt = function (title, label, def, type) {
    return new Promise((resolve) => {
      const m = U.modal(title, '<label class="fld"><span>' + U.esc(label) + '</span>' +
        (type === 'textarea' ? '<textarea data-in rows="4">' + U.esc(def || '') + '</textarea>' : '<input data-in type="' + (type || 'text') + '" value="' + U.esc(def || '') + '">') +
        '</label><div class="row-btns"><button class="btn ghost" data-no>' + T('cancel') + '</button><button class="btn" data-yes>' + T('ok') + '</button></div>',
        { onClose: () => resolve(null) });
      const inp = m.el.querySelector('[data-in]'); inp.focus();
      m.el.querySelector('[data-no]').onclick = () => m.close();
      m.el.querySelector('[data-yes]').onclick = () => { const v = inp.value; m.el.remove(); resolve(v); };
    });
  };

  // read form values: inputs with name attr inside root
  U.formData = function (root) {
    const o = {};
    U.$$('[name]', root).forEach((el) => {
      if (el.type === 'checkbox') o[el.name] = el.checked;
      else if (el.type === 'number') o[el.name] = el.value === '' ? '' : Number(el.value);
      else o[el.name] = el.value.trim();
    });
    return o;
  };

  U.field = function (name, label, value, opts) {
    opts = opts || {};
    const v = value == null ? '' : value;
    const ro = opts.readonly ? ' readonly' : '';
    const req = opts.required ? ' required' : '';
    let input;
    if (opts.type === 'select') {
      input = '<select name="' + name + '"' + (opts.readonly ? ' disabled' : '') + '>' + opts.options.map((o) => {
        const val = typeof o === 'object' ? o.v : o, lab = typeof o === 'object' ? o.l : o;
        return '<option value="' + U.esc(val) + '"' + (String(val) === String(v) ? ' selected' : '') + '>' + U.esc(lab) + '</option>';
      }).join('') + '</select>';
    } else if (opts.type === 'textarea') {
      input = '<textarea name="' + name + '" rows="' + (opts.rows || 3) + '"' + ro + req + '>' + U.esc(v) + '</textarea>';
    } else if (opts.type === 'checkbox') {
      return '<label class="chk"><input type="checkbox" name="' + name + '"' + (v ? ' checked' : '') + (opts.readonly ? ' disabled' : '') + '> <span>' + U.esc(label) + '</span></label>';
    } else {
      input = '<input name="' + name + '" type="' + (opts.type || 'text') + '" value="' + U.esc(v) + '"' + ro + req +
        (opts.placeholder ? ' placeholder="' + U.esc(opts.placeholder) + '"' : '') + (opts.step ? ' step="' + opts.step + '"' : '') +
        (opts.min != null ? ' min="' + opts.min + '"' : '') + '>';
    }
    return '<label class="fld' + (opts.auto ? ' auto' : '') + '"><span>' + U.esc(label) + (opts.required ? ' *' : '') +
      (opts.auto ? ' <em>' + T('autoFilled') + '</em>' : '') + '</span>' + input + '</label>';
  };

  U.badge = function (status) {
    const map = {
      pending: 'warn', applied: 'warn', in_process: 'info', approved: 'ok', rejected: 'bad',
      present: 'ok', half: 'info', absent: 'bad', disbursed: 'ok', closed: 'muted', unread: 'warn'
    };
    return '<span class="badge ' + (map[status] || 'muted') + '">' + U.esc(T('st_' + status)) + '</span>';
  };

  U.empty = (msg) => '<div class="empty">' + U.esc(msg || T('noData')) + '</div>';

  U.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  U.monthOptions = function (count) {
    const out = []; const d = new Date(); d.setDate(1);
    for (let i = 0; i < (count || 13); i++) { out.push(U.monthKey(d)); d.setMonth(d.getMonth() - 1); }
    return out;
  };

  U.sundaysUpTo = function (month, uptoDay) {
    const [y, m] = month.split('-').map(Number);
    let c = 0;
    for (let d = 1; d <= uptoDay; d++) if (new Date(y, m - 1, d).getDay() === 0) c++;
    return c;
  };

  U.fillTemplate = function (tpl, vars) {
    return String(tpl || '').replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null ? vars[k] : m));
  };

  window.U = U;
})();
