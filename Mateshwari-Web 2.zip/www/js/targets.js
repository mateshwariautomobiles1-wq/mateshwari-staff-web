// ---------- Targets, campaigns, wallet, vouchers, payout release ----------
(function () {
  const V = window.Views, esc = U.esc;
  const TG = window.Targets = {};

  // payout for a target doc
  TG.calc = function (t) {
    const tq = U.num(t.targetQty), ach = U.num(t.achieved), rate = U.num(t.rate), bonus = U.num(t.fullBonus);
    const full = tq > 0 && ach >= tq;
    const earned = U.round2(ach * rate + (full ? bonus : 0));
    const potential = U.round2((tq > 0 ? tq * rate + bonus : 0));
    const pct = tq > 0 ? Math.min(100, Math.round(ach / tq * 100)) : (ach > 0 ? 100 : 0);
    return { tq, ach, rate, bonus, full, earned, potential, pct, remaining: Math.max(0, tq - ach) };
  };

  TG.balance = (tx) => U.round2(tx.reduce((s, x) => s + (x.type === 'credit' ? 1 : -1) * U.num(x.amount), 0));

  function targetCard(t, admin, extra) {
    const c = TG.calc(t);
    const closed = t.status === 'closed';
    return '<div class="card tg-card' + (closed ? ' closed' : '') + '" data-t="' + esc(t.id) + '">' +
      '<div class="row-between"><div><span class="badge ' + (t.kind === 'campaign' ? 'info' : 'warn') + '">' + T(t.kind === 'campaign' ? 'campaign' : 'target') + '</span> <b>' + esc(t.title) + '</b>' +
      (admin ? '<br><small class="muted">' + esc(t.empName) + '</small>' : '') + '</div>' + (closed ? '<span class="badge muted">' + T('st_closed') + '</span>' : c.full ? '<span class="badge ok">🏆 ' + T('achieved') + '</span>' : '') + '</div>' +
      '<small class="muted">' + U.fmtDate(t.startDate) + ' → ' + U.fmtDate(t.endDate) + (t.description ? ' · ' + esc(t.description) : '') + '</small>' +
      (c.tq > 0 ? '<div class="row-between tg-nums"><span>' + T('achievedLabel') + ' <b>' + c.ach + ' / ' + c.tq + '</b> ' + esc(t.unit || '') + '</span><b class="' + (c.pct >= 100 ? 'good' : c.pct >= 50 ? 'mid' : 'low') + '">' + c.pct + '%</b></div>' +
        '<div class="bar"><i class="' + (c.pct >= 100 ? 'good' : c.pct >= 50 ? 'mid' : 'low') + '" style="width:' + c.pct + '%"></i></div>'
        : '<div class="tg-nums">' + T('achievedLabel') + ' <b>' + c.ach + '</b> ' + esc(t.unit || '') + '</div>') +
      '<div class="tg-grid"><span>' + T('ratePerUnit') + '<b>' + U.money(c.rate) + '</b></span>' + (c.bonus ? '<span>' + T('fullBonus') + '<b>' + U.money(c.bonus) + '</b></span>' : '') +
      '<span>' + T('payoutEarned') + '<b class="good">' + U.money(c.earned) + '</b></span>' + (c.tq > 0 ? '<span>' + T('payoutOnFull') + '<b>' + U.money(c.potential) + '</b></span>' : '') + '</div>' +
      (c.tq > 0 && !c.full && !closed ? '<small class="muted">🎯 ' + T('remainingMsg').replace('{n}', c.remaining + ' ' + (t.unit || '')).replace('{a}', U.money(U.round2(c.potential - c.earned))) + '</small>' : '') +
      '<div class="small muted">💼 ' + T('creditedToWallet') + ': ' + U.money(t.credited || 0) + '</div>' + (extra || '') + '</div>';
  }
  TG.cardHtml = targetCard;

  function entriesHtml(t) {
    const en = (t.entries || []).slice().reverse();
    return en.length ? '<div class="timeline">' + en.map((x) => '<div><b>' + (x.qty > 0 ? '+' : '') + x.qty + ' ' + esc(t.unit || '') + '</b> · ' + U.fmtDate(x.date) +
      (x.note ? '<br><small>' + esc(x.note) + '</small>' : '') + '</div>').join('') + '</div>' : U.empty();
  }

  function txList(tx, showEmp) {
    tx = tx.slice().sort((a, b) => (b.date || '').localeCompare(a.date || '') || ((U.toDate(b.at) || 0) - (U.toDate(a.at) || 0)));
    if (!tx.length) return U.empty(T('noTransactions'));
    return '<div class="card list">' + tx.map((x) => '<div class="li"><div class="tx-ic ' + x.type + '">' + (x.source === 'release' ? '🏦' : x.source === 'voucher' ? '🎁' : x.type === 'credit' ? '＋' : '－') + '</div><div class="grow"><b>' +
      esc(T('src_' + (x.source || 'adjust'))) + (showEmp ? ' · ' + esc(x.empName) : '') + '</b><small>' + U.fmtDate(x.date) + (x.title ? ' · ' + esc(x.title) : '') + (x.mode ? ' · ' + esc(x.mode) : '') +
      (x.ref ? ' · Ref: ' + esc(x.ref) : '') + (x.note ? ' · ' + esc(x.note) : '') + '</small></div><b class="' + (x.type === 'credit' ? 'good' : 'low') + '">' + (x.type === 'credit' ? '+' : '−') + U.money(x.amount) + '</b></div>').join('') + '</div>';
  }

  // ================= EMPLOYEE =================
  V.empTargets = async function (el, p) {
    const tab = p.tab || 'targets';
    el.innerHTML = '<h2 class="page-title">' + T('targetsWallet') + '</h2><div class="tabs">' +
      [['targets', '🎯 ' + T('targets')], ['wallet', '💼 ' + T('wallet')]].map((t) => '<button class="' + (t[0] === tab ? 'on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>').join('') + '</div><div id="tb"></div>';
    U.$$('[data-tab]').forEach((b) => b.onclick = () => App.go('empTargets', { tab: b.dataset.tab }));
    const tb = U.$('#tb');
    if (tab === 'targets') {
      const list = (await DB.query('targets', [['empId', '==', S.user.empId]])).sort((a, b) => (a.status === 'closed') - (b.status === 'closed') || String(b.startDate).localeCompare(a.startDate));
      const active = list.filter((t) => t.status !== 'closed');
      const totEarned = U.round2(active.reduce((s, t) => s + TG.calc(t).earned, 0));
      const totPot = U.round2(active.reduce((s, t) => s + TG.calc(t).potential, 0));
      tb.innerHTML = '<div class="stats4 two"><div><b>' + U.money(totEarned) + '</b><small>' + T('payoutEarned') + '</small></div><div><b>' + U.money(totPot) + '</b><small>' + T('payoutOnFull') + '</small></div></div>' +
        (list.length ? list.map((t) => targetCard(t, false)).join('') : U.empty(T('noTargets')));
      U.$$('[data-t]', tb).forEach((c) => c.onclick = () => {
        const t = list.find((x) => x.id === c.dataset.t);
        U.modal(t.title, targetCard(t, false) + '<h4>' + T('achievementHistory') + '</h4>' + entriesHtml(t), { wide: true });
      });
    } else {
      const tx = await DB.query('wallet', [['empId', '==', S.user.empId]]);
      const bal = TG.balance(tx);
      const credit = U.round2(tx.filter((x) => x.type === 'credit').reduce((s, x) => s + U.num(x.amount), 0));
      const released = U.round2(tx.filter((x) => x.source === 'release').reduce((s, x) => s + U.num(x.amount), 0));
      tb.innerHTML = '<div class="card wallet-card"><small>' + T('walletBalance') + '</small><div class="wbal">' + U.money(bal) + '</div><small>' + T('walletNote') + '</small></div>' +
        '<div class="stats4 two"><div><b>' + U.money(credit) + '</b><small>' + T('totalCredited') + '</small></div><div><b>' + U.money(released) + '</b><small>' + T('totalReleased') + '</small></div></div>' +
        '<h3 class="sec-title">' + T('transactions') + '</h3>' + txList(tx);
    }
  };

  // ================= ADMIN: TARGETS & CAMPAIGNS =================
  V.adminTargets = async function (el, p) {
    const filter = p.filter || 'active';
    const camps = (await DB.all('campaigns')).sort((a, b) => String(b.startDate).localeCompare(a.startDate));
    const tg = await DB.all('targets');
    const shown = camps.filter((c) => filter === 'all' || (filter === 'closed' ? c.status === 'closed' : c.status !== 'closed'));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">🎯 ' + T('targetsCampaigns') + '</h2><button class="btn" onclick="App.go(\'adminTargetEdit\')">+ ' + T('new') + '</button></div>' +
      '<div class="chips">' + ['active', 'closed', 'all'].map((f) => '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + T(f === 'active' ? 'active' : f === 'closed' ? 'st_closed' : 'all') + '</button>').join('') +
      '<button class="chip" onclick="App.go(\'adminWallet\')">💼 ' + T('walletPayouts') + '</button></div>' +
      (shown.length ? shown.map((c) => {
        const mine = tg.filter((t) => t.campaignId === c.id);
        const earned = U.round2(mine.reduce((s, t) => s + TG.calc(t).earned, 0));
        const ach = mine.reduce((s, t) => s + U.num(t.achieved), 0), tq = mine.reduce((s, t) => s + U.num(t.targetQty), 0);
        const pct = tq ? Math.min(100, Math.round(ach / tq * 100)) : 0;
        return '<div class="card" data-c="' + c.id + '"><div class="row-between"><div><span class="badge ' + (c.kind === 'campaign' ? 'info' : 'warn') + '">' + T(c.kind === 'campaign' ? 'campaign' : 'target') + '</span> <b>' + esc(c.title) + '</b></div>' +
          (c.status === 'closed' ? '<span class="badge muted">' + T('st_closed') + '</span>' : '') + '</div><small class="muted">' + U.fmtDate(c.startDate) + ' → ' + U.fmtDate(c.endDate) + ' · ' + mine.length + ' ' + T('employees') + '</small>' +
          (tq ? '<div class="bar"><i class="' + (pct >= 100 ? 'good' : pct >= 50 ? 'mid' : 'low') + '" style="width:' + pct + '%"></i></div><small>' + ach + ' / ' + tq + ' ' + esc(c.unit || '') + ' (' + pct + '%)</small>' : '<small>' + ach + ' ' + esc(c.unit || '') + '</small>') +
          '<div class="small">' + T('payoutEarned') + ': <b>' + U.money(earned) + '</b></div></div>';
      }).join('') : U.empty(T('noTargets')));
    U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('adminTargets', { filter: b.dataset.f }));
    U.$$('[data-c]').forEach((c) => c.onclick = () => App.go('adminTargetDetail', { id: c.dataset.c }));
  };

  V.adminTargetEdit = async function (el, p) {
    const c = p.id ? await DB.get('campaigns', p.id) : { kind: 'target', unit: 'Vehicles', startDate: U.monthKey() + '-01', endDate: U.monthKey() + '-' + U.daysInMonth(U.monthKey()), rate: 0, fullBonus: 0, targetQty: 10 };
    const emps = await Admin.employees();
    const isNew = !p.id;
    el.innerHTML = '<h2 class="page-title">' + (isNew ? T('newTargetCampaign') : T('edit')) + '</h2><form id="tf" class="form"><div class="card">' +
      U.field('kind', T('type'), c.kind, { type: 'select', options: [{ v: 'target', l: '🎯 ' + T('target') }, { v: 'campaign', l: '📣 ' + T('campaign') }] }) +
      U.field('title', T('title'), c.title, { required: true, placeholder: 'e.g. November Bike Sales / Diwali Dhamaka' }) +
      U.field('description', T('description'), c.description, { type: 'textarea', rows: 2 }) +
      '<div class="grid2f">' + U.field('unit', T('unit'), c.unit, { placeholder: 'Vehicles / Insurance / Accessories ₹' }) +
      U.field('targetQty', T('targetQty') + ' (' + T('perEmployee') + ')', c.targetQty, { type: 'number', min: 0, step: 'any' }) +
      U.field('rate', T('ratePerUnit') + ' (₹)', c.rate, { type: 'number', step: 'any' }) + U.field('fullBonus', T('fullBonus') + ' (₹)', c.fullBonus, { type: 'number', step: 'any' }) +
      U.field('startDate', T('startDate'), c.startDate, { type: 'date', required: true }) + U.field('endDate', T('endDate'), c.endDate, { type: 'date', required: true }) + '</div>' +
      '<p class="muted small">' + T('payoutFormula') + '</p></div>' +
      (isNew ? '<div class="card"><h3>' + T('assignTo') + '</h3>' + U.field('_all', T('allEmployees'), true, { type: 'checkbox' }) +
        '<div id="empPick" class="pick-list">' + emps.map((e) => '<label class="chk"><input type="checkbox" data-emp="' + esc(e.id) + '" checked> <span>' + esc(e.name) + ' <small class="muted">' + esc(e.id) + '</small></span></label>').join('') + '</div>' +
        U.field('notify', T('notifyStaff'), true, { type: 'checkbox' }) + '</div>' : '') +
      '<button class="btn block">' + T('save') + '</button></form>';
    const f = U.$('#tf');
    const all = f.querySelector('[name=_all]');
    if (all) all.onchange = () => U.$$('[data-emp]').forEach((x) => { x.checked = all.checked; });
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      if (d.endDate < d.startDate) return U.toast(T('invalidRange'), 'err');
      const data = { kind: d.kind, title: d.title, description: d.description, unit: d.unit, targetQty: U.num(d.targetQty), rate: U.num(d.rate), fullBonus: U.num(d.fullBonus), startDate: d.startDate, endDate: d.endDate };
      U.loading(true);
      try {
        if (isNew) {
          const chosen = U.$$('[data-emp]').filter((x) => x.checked).map((x) => emps.find((e) => e.id === x.dataset.emp));
          if (!chosen.length) throw new Error(T('selectEmployee'));
          const id = await DB.add('campaigns', Object.assign(data, { status: 'active', createdAt: DB.now() }));
          for (const e of chosen) await DB.set('targets', id + '_' + e.id, Object.assign({}, data, { campaignId: id, empId: e.id, empName: e.name, achieved: 0, credited: 0, entries: [], status: 'active' }));
          if (d.notify) {
            if (chosen.length === emps.length) await DB.add('notifications', { target: 'all', targetName: 'All', title: (d.kind === 'campaign' ? '📣 ' : '🎯 ') + d.title, body: T('newTargetMsg'), at: DB.now(), by: S.user.name || 'Admin' });
            else for (const e of chosen) await DB.add('notifications', { target: e.id, targetName: e.name, title: '🎯 ' + d.title, body: T('newTargetMsg'), at: DB.now(), by: S.user.name || 'Admin' });
          }
          App.go('adminTargetDetail', { id });
        } else {
          await DB.update('campaigns', p.id, data);
          const list = await DB.query('targets', [['campaignId', '==', p.id]]);
          for (const t of list) {
            const nt = Object.assign({}, t, { title: data.title, description: data.description, unit: data.unit, rate: data.rate, fullBonus: data.fullBonus, startDate: data.startDate, endDate: data.endDate, kind: data.kind });
            await applyTarget(t, nt, T('rateChanged'));
          }
          App.go('adminTargetDetail', { id: p.id });
        }
        U.toast(T('saved'), 'ok');
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  // save target doc and post wallet difference (earned - credited)
  async function applyTarget(old, nt, reason) {
    const c = TG.calc(nt);
    const delta = U.round2(c.earned - U.num(old.credited));
    const upd = {
      title: nt.title, description: nt.description || '', unit: nt.unit || '', rate: U.num(nt.rate), fullBonus: U.num(nt.fullBonus), targetQty: U.num(nt.targetQty),
      startDate: nt.startDate, endDate: nt.endDate, kind: nt.kind || 'target', achieved: U.num(nt.achieved), entries: nt.entries || [], credited: c.earned
    };
    await DB.update('targets', old.id, upd);
    if (delta !== 0) {
      await DB.add('wallet', {
        empId: old.empId, empName: old.empName, type: delta > 0 ? 'credit' : 'debit', source: nt.kind === 'campaign' ? 'campaign' : 'target', amount: Math.abs(delta),
        title: nt.title, refId: old.id, note: reason || '', date: U.dateKey(), month: U.monthKey(), at: DB.now(), by: S.user.name || 'Admin'
      });
    }
    return delta;
  }

  V.adminTargetDetail = async function (el, p) {
    const c = await DB.get('campaigns', p.id);
    if (!c) { el.innerHTML = U.empty(); return; }
    const list = (await DB.query('targets', [['campaignId', '==', p.id]])).sort((a, b) => TG.calc(b).pct - TG.calc(a).pct);
    const closed = c.status === 'closed';
    const earned = U.round2(list.reduce((s, t) => s + TG.calc(t).earned, 0));
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'adminTargets\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><div class="row-between"><div><span class="badge ' + (c.kind === 'campaign' ? 'info' : 'warn') + '">' + T(c.kind === 'campaign' ? 'campaign' : 'target') + '</span> <b>' + esc(c.title) + '</b></div>' +
      (closed ? '<span class="badge muted">' + T('st_closed') + '</span>' : '') + '</div><small class="muted">' + U.fmtDate(c.startDate) + ' → ' + U.fmtDate(c.endDate) + (c.description ? ' · ' + esc(c.description) : '') + '</small>' +
      '<div class="tg-grid"><span>' + T('targetQty') + '<b>' + (c.targetQty || '-') + ' ' + esc(c.unit || '') + '</b></span><span>' + T('ratePerUnit') + '<b>' + U.money(c.rate) + '</b></span><span>' + T('fullBonus') + '<b>' + U.money(c.fullBonus) + '</b></span><span>' + T('payoutEarned') + '<b>' + U.money(earned) + '</b></span></div>' +
      '<div class="row-btns left">' + (!closed ? '<button class="btn sm ghost" onclick="App.go(\'adminTargetEdit\',{id:\'' + esc(c.id) + '\'})">✏️ ' + T('edit') + '</button><button class="btn sm ghost" id="addEmp">+ ' + T('employee') + '</button><button class="btn sm ghost" id="close">🔒 ' + T('close') + '</button>' : '<button class="btn sm ghost" id="reopen">' + T('reopen') + '</button>') +
      '<button class="btn sm ghost" id="tx">⬇ Excel</button></div></div>' +
      (list.length ? list.map((t) => targetCard(t, true, (!closed ? '<div class="row-btns left"><button class="btn sm" data-add="' + esc(t.id) + '">+ ' + T('addAchievement') + '</button><button class="btn sm ghost" data-q="' + esc(t.id) + '">🎯 ' + T('changeTarget') + '</button><button class="btn sm ghost" data-h="' + esc(t.id) + '">🕘</button><button class="btn sm ghost" data-rm="' + esc(t.id) + '">🗑</button></div>' : ''))).join('') : U.empty());
    const find = (id) => list.find((t) => t.id === id);
    U.$$('[data-add]').forEach((b) => b.onclick = (ev) => { ev.stopPropagation(); addAchievement(find(b.dataset.add)); });
    U.$$('[data-h]').forEach((b) => b.onclick = (ev) => { ev.stopPropagation(); const t = find(b.dataset.h); U.modal(t.empName + ' · ' + t.title, entriesHtml(t)); });
    U.$$('[data-q]').forEach((b) => b.onclick = async (ev) => {
      ev.stopPropagation(); const t = find(b.dataset.q);
      const v = await U.prompt(T('changeTarget'), T('targetQty') + ' (' + esc(t.empName) + ')', t.targetQty, 'number'); if (v == null || v === '') return;
      U.loading(true);
      try { await applyTarget(t, Object.assign({}, t, { targetQty: U.num(v) }), T('targetChanged')); App.refresh(); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
    U.$$('[data-rm]').forEach((b) => b.onclick = async (ev) => {
      ev.stopPropagation(); const t = find(b.dataset.rm);
      if (!(await U.confirm(T('removeFromTarget').replace('{n}', t.empName), T('delete')))) return;
      U.loading(true);
      try { await applyTarget(t, Object.assign({}, t, { achieved: 0, entries: [] }), T('removedFromTarget')); await DB.del('targets', t.id); App.refresh(); }
      catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
    const ae = U.$('#addEmp');
    if (ae) ae.onclick = async () => {
      const emps = (await Admin.employees()).filter((e) => !list.find((t) => t.empId === e.id));
      if (!emps.length) return U.toast(T('allAssigned'));
      const m = U.modal(T('employee'), '<form class="form" id="aef">' + U.field('empId', T('employee'), '', { type: 'select', options: emps.map((e) => ({ v: e.id, l: e.name })) }) +
        U.field('qty', T('targetQty'), c.targetQty, { type: 'number', step: 'any' }) + '<button class="btn block">' + T('save') + '</button></form>');
      U.$('#aef', m.el).onsubmit = async (ev) => {
        ev.preventDefault(); const d = U.formData(ev.target); const e = emps.find((x) => x.id === d.empId);
        await DB.set('targets', c.id + '_' + e.id, { kind: c.kind, title: c.title, description: c.description || '', unit: c.unit || '', targetQty: U.num(d.qty), rate: U.num(c.rate), fullBonus: U.num(c.fullBonus),
          startDate: c.startDate, endDate: c.endDate, campaignId: c.id, empId: e.id, empName: e.name, achieved: 0, credited: 0, entries: [], status: 'active' });
        m.close(); App.refresh();
      };
    };
    const cl = U.$('#close');
    if (cl) cl.onclick = async () => {
      if (!(await U.confirm(T('closeTargetConfirm')))) return;
      await DB.update('campaigns', c.id, { status: 'closed', closedAt: DB.now() });
      for (const t of list) await DB.update('targets', t.id, { status: 'closed' });
      App.refresh();
    };
    const ro = U.$('#reopen');
    if (ro) ro.onclick = async () => {
      await DB.update('campaigns', c.id, { status: 'active' });
      for (const t of list) await DB.update('targets', t.id, { status: 'active' });
      App.refresh();
    };
    U.$('#tx').onclick = () => PDF.tableXlsx(c.title, U.fmtDate(c.startDate) + ' to ' + U.fmtDate(c.endDate),
      ['Emp ID', 'Name', 'Target', 'Achieved', '%', 'Rate', 'Full Bonus', 'Payout Earned', 'Payout on Full'],
      list.map((t) => { const k = TG.calc(t); return [t.empId, t.empName, k.tq, k.ach, k.pct + '%', k.rate, k.bonus, k.earned, k.potential]; }));
  };

  function addAchievement(t) {
    const m = U.modal(T('addAchievement') + ' · ' + t.empName, '<form class="form" id="acf">' +
      '<div class="grid2f">' + U.field('qty', T('quantity') + ' (' + (t.unit || '') + ')', 1, { type: 'number', step: 'any', required: true }) + U.field('date', T('date'), U.dateKey(), { type: 'date', required: true }) + '</div>' +
      U.field('note', T('noteExample'), '') + '<p class="muted small">' + T('negativeHint') + '</p><button class="btn block">' + T('save') + '</button></form>');
    U.$('#acf', m.el).onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const qty = U.num(d.qty); if (!qty) return U.toast(T('enterAmount'), 'err');
      U.loading(true);
      try {
        const before = TG.calc(t);
        const nt = Object.assign({}, t, { achieved: U.round2(U.num(t.achieved) + qty), entries: (t.entries || []).concat([{ qty, date: d.date, note: d.note, at: Date.now() }]) });
        const delta = await applyTarget(t, nt, (qty > 0 ? '+' : '') + qty + ' ' + (t.unit || ''));
        const after = TG.calc(nt);
        if (delta > 0) await DB.add('notifications', { target: t.empId, targetName: t.empName, title: '💰 ' + T('payoutCredited'),
          body: t.title + ': ' + after.ach + (after.tq ? '/' + after.tq : '') + ' ' + (t.unit || '') + ' · +' + U.money(delta) + (after.full && !before.full ? ' 🏆 ' + T('targetAchievedMsg') : ''), at: DB.now(), by: S.user.name || 'Admin' });
        m.close(); U.toast(T('saved') + (delta ? ' · ' + (delta > 0 ? '+' : '') + U.money(delta) : ''), 'ok'); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  }

  // ================= ADMIN: WALLET & PAYOUTS =================
  V.adminWallet = async function (el) {
    const [emps, tx] = await Promise.all([Admin.employees(true), DB.all('wallet')]);
    const rows = emps.map((e) => { const mine = tx.filter((x) => x.empId === e.id); return { e, bal: TG.balance(mine), n: mine.length }; }).filter((r) => r.e.active !== false || r.bal !== 0);
    const total = U.round2(rows.reduce((s, r) => s + r.bal, 0));
    el.innerHTML = '<h2 class="page-title">💼 ' + T('walletPayouts') + '</h2>' +
      '<div class="card wallet-card"><small>' + T('totalPendingPayout') + '</small><div class="wbal">' + U.money(total) + '</div></div>' +
      '<div class="row-btns left"><button class="btn ghost sm" id="hist">🕘 ' + T('allTransactions') + '</button><button class="btn ghost sm" onclick="App.go(\'adminTargets\')">🎯 ' + T('targetsCampaigns') + '</button></div>' +
      (rows.length ? rows.map((r) => '<div class="card"><div class="row-between"><div class="row">' + App.empAvatar(r.e, 38) + '<div><b>' + esc(r.e.name) + '</b><br><small class="muted">' + esc(r.e.id) + '</small></div></div><b class="big ' + (r.bal > 0 ? 'good' : '') + '">' + U.money(r.bal) + '</b></div>' +
        '<div class="row-btns left"><button class="btn sm" data-rel="' + esc(r.e.id) + '"' + (r.bal <= 0 ? ' disabled' : '') + '>🏦 ' + T('releasePayout') + '</button><button class="btn sm ghost" data-vou="' + esc(r.e.id) + '">🎁 ' + T('giveVoucher') + '</button>' +
        '<button class="btn sm ghost" data-st="' + esc(r.e.id) + '">📄 ' + T('statement') + '</button></div></div>').join('') : U.empty(T('noEmployees')));
    const get = (id) => rows.find((r) => r.e.id === id);
    U.$('#hist').onclick = () => U.modal(T('allTransactions'), txList(tx, true), { wide: true });
    U.$$('[data-st]').forEach((b) => b.onclick = () => { const r = get(b.dataset.st); U.modal(r.e.name + ' · ' + U.money(r.bal), txList(tx.filter((x) => x.empId === r.e.id)), { wide: true }); });
    U.$$('[data-vou]').forEach((b) => b.onclick = () => {
      const r = get(b.dataset.vou);
      const m = U.modal('🎁 ' + T('giveVoucher') + ' · ' + r.e.name, '<form class="form" id="vf">' + U.field('title', T('voucherName'), '', { required: true, placeholder: 'Best Salesman / Festival gift' }) +
        U.field('amount', T('amount') + ' (₹)', '', { type: 'number', required: true, min: 1 }) + U.field('note', T('note'), '') + '<button class="btn block">' + T('save') + '</button></form>');
      U.$('#vf', m.el).onsubmit = async (ev) => {
        ev.preventDefault(); const d = U.formData(ev.target); if (!(d.amount > 0)) return U.toast(T('enterAmount'), 'err');
        U.loading(true);
        try {
          await DB.add('wallet', { empId: r.e.id, empName: r.e.name, type: 'credit', source: 'voucher', amount: U.num(d.amount), title: d.title, note: d.note, date: U.dateKey(), month: U.monthKey(), at: DB.now(), by: S.user.name || 'Admin' });
          await DB.add('notifications', { target: r.e.id, targetName: r.e.name, title: '🎁 ' + T('voucherReceived'), body: d.title + ' · ' + U.money(d.amount), at: DB.now(), by: S.user.name || 'Admin' });
          m.close(); U.toast(T('saved'), 'ok'); App.refresh();
        } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      };
    });
    U.$$('[data-rel]').forEach((b) => b.onclick = () => {
      const r = get(b.dataset.rel);
      const m = U.modal('🏦 ' + T('releasePayout') + ' · ' + r.e.name, '<form class="form" id="rf"><div class="note">' + T('walletBalance') + ': <b>' + U.money(r.bal) + '</b></div>' +
        U.field('amount', T('amount') + ' (₹)', r.bal, { type: 'number', required: true, min: 1, step: 'any' }) +
        '<div class="grid2f">' + U.field('mode', T('mode'), 'Cash', { type: 'select', options: ['Cash', 'Bank Transfer', 'UPI', 'Cheque'] }) + U.field('date', T('date'), U.dateKey(), { type: 'date' }) + '</div>' +
        U.field('ref', T('refNo'), '', { placeholder: 'UTR / Cheque No.' }) + U.field('note', T('note'), '') + '<button class="btn block">' + T('releasePayout') + '</button></form>');
      U.$('#rf', m.el).onsubmit = async (ev) => {
        ev.preventDefault(); const d = U.formData(ev.target);
        const amt = U.num(d.amount);
        if (!(amt > 0) || amt > r.bal + 0.001) return U.toast(T('amountExceeds') + ' ' + U.money(r.bal), 'err');
        if (!(await U.confirm(T('releaseConfirm').replace('{a}', U.money(amt)).replace('{n}', r.e.name).replace('{m}', d.mode), T('releasePayout')))) return;
        U.loading(true);
        try {
          await DB.add('wallet', { empId: r.e.id, empName: r.e.name, type: 'debit', source: 'release', amount: amt, mode: d.mode, ref: d.ref, note: d.note, date: d.date || U.dateKey(), month: (d.date || U.dateKey()).slice(0, 7), at: DB.now(), by: S.user.name || 'Admin' });
          await DB.add('notifications', { target: r.e.id, targetName: r.e.name, title: '🏦 ' + T('payoutReleased'), body: U.money(amt) + ' · ' + d.mode + (d.ref ? ' · Ref ' + d.ref : ''), at: DB.now(), by: S.user.name || 'Admin' });
          m.close(); U.toast(T('saved'), 'ok'); App.refresh();
        } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      };
    });
  };
})();
