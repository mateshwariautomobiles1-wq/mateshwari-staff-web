// ---------- Admin reports (preview + Excel/PDF export) ----------
(function () {
  const V = window.Views, esc = U.esc;
  const R = window.Reports = {};

  const TYPES = R.TYPES = ['attSummary', 'attDetail', 'muster', 'salary', 'payments', 'loans', 'employees'];

  R.build = async function (type, month) {
    const A = window.Admin;
    if (type === 'attSummary') {
      const [emps, att, hol] = await Promise.all([A.employees(), DB.query('attendance', [['month', '==', month]]), Cal.holidays(month)]);
      const s = A.attSummary(emps, att, month, hol);
      return {
        title: 'Attendance Summary', columns: ['Emp ID', 'Name', 'Full Days', 'Half Days', 'Present', 'Pending', 'Rejected', 'Weekly Off', 'Holidays', 'Working Days', 'Attendance %'],
        rows: s.map((r) => [r.emp.id, r.emp.name, r.full, r.half, r.present, r.pending, r.rejected, r.offs, r.hols, r.working, r.pct + '%'])
      };
    }
    if (type === 'attDetail') {
      const att = (await DB.query('attendance', [['month', '==', month]])).sort((a, b) => a.date.localeCompare(b.date) || String(a.empName).localeCompare(b.empName));
      return {
        title: 'Attendance Detail', columns: ['Date', 'Emp ID', 'Name', 'Check In', 'Check Out', 'Hours', 'In Dist (m)', 'Status', 'Day', 'Remarks'],
        rows: att.map((a) => [U.fmtDate(a.date), a.empId, a.empName, a.checkIn ? U.fmtTime(a.checkIn.at) : '-', a.checkOut ? U.fmtTime(a.checkOut.at) : '-',
        a.checkIn && a.checkOut ? U.round2((a.checkOut.at - a.checkIn.at) / 3600000) : '', a.checkIn && a.checkIn.dist != null ? a.checkIn.dist : '',
        a.status, a.status === 'approved' ? (a.dayType === 'half' ? 'Half' : 'Full') : '', a.note || ''])
      };
    }
    if (type === 'muster') {
      const [emps, att, hol] = await Promise.all([A.employees(), DB.query('attendance', [['month', '==', month]]), Cal.holidays(month)]);
      const D = U.daysInMonth(month);
      const map = {}; att.forEach((a) => { map[a.empId + '_' + a.date] = a; });
      const cols = ['Name'];
      for (let d = 1; d <= D; d++) cols.push(String(d));
      cols.push('P');
      const rows = emps.map((e) => {
        let p = 0; const r = [e.name];
        for (let d = 1; d <= D; d++) {
          const a = map[e.id + '_' + month + '-' + U.pad(d)];
          const c = Cal.dayCode(e, month, d, a, hol);
          if (c === 'P') p += 1; else if (c === 'H') p += 0.5;
          r.push(c);
        }
        r.push(p); return r;
      });
      return { title: 'Muster Roll', columns: cols, rows, legend: 'P=Present H=Half A=Absent WO=Weekly Off HO=Holiday ?=Pending R=Rejected' };
    }
    if (type === 'salary') {
      const rows = await A.salaryRows(month);
      const t = (k) => U.round2(rows.reduce((s, r) => s + U.num(r[k]), 0));
      return {
        title: 'Salary Sheet', columns: ['Emp ID', 'Name', 'Monthly', 'Present', 'Paid WO', 'Paid Hol', 'Extra', 'Payable Days', 'Earned', 'Bonus', 'Deduction', 'Loan EMI', 'Paid/Advance', 'Net Payable'],
        rows: rows.map((r) => [r.emp.id, r.emp.name, r.monthly, r.present, r.paidSun, r.paidHol, r.extra, r.payable, r.earned, r.bonus, r.ded, r.emi, r.paid, r.net]),
        foot: ['', 'TOTAL', t('monthly'), '', '', '', '', '', t('earned'), t('bonus'), t('ded'), t('emi'), t('paid'), t('net')]
      };
    }
    if (type === 'payments') {
      const list = (await DB.query('payments', [['month', '==', month]])).sort((a, b) => a.date.localeCompare(b.date));
      const tot = U.round2(list.reduce((s, p) => s + U.num(p.amount), 0));
      return {
        title: 'Payment Ledger', columns: ['Date', 'Emp ID', 'Name', 'Type', 'Mode', 'Amount', 'Note', 'Entered By'],
        rows: list.map((p) => [U.fmtDate(p.date), p.empId, p.empName, p.type, p.mode, U.num(p.amount), p.note || '', p.enteredByName || '']),
        foot: ['', '', 'TOTAL', '', '', tot, '', '']
      };
    }
    if (type === 'loans') {
      const list = (await DB.all('loans')).sort((a, b) => (U.toDate(a.createdAt) || 0) - (U.toDate(b.createdAt) || 0));
      return {
        title: 'Loan Register', all: true, columns: ['Loan No', 'Applied', 'Emp ID', 'Name', 'Amount', 'Tenure', 'ROI', 'Type', 'EMI', 'Charges', 'Net Paid', 'Disbursed', 'Outstanding', 'Overdue EMI', 'Status', 'Guarantor'],
        rows: list.map((l) => { const t = Loan.terms(l); return [l.loanNo || '-', U.fmtDate(l.createdAt), l.empId, l.empName, t.P, t.n, t.rate, t.type, t.emi, t.charges, t.net,
          l.disbursedAt ? U.fmtDate(l.disbursedAt) : '', ['disbursed', 'closed'].includes(l.status) ? Loan.outstanding(l) : '', Loan.overdueCount(l) || '', l.status, l.guarantor ? l.guarantor.name : '']; })
      };
    }
    // employees
    const emps = await A.employees(true);
    return {
      title: 'Employee List', all: true, columns: ['Emp ID', 'Name', 'Father', 'Designation', 'Mobile', 'DOB', 'Joined', 'Aadhaar', 'PAN', 'Bank A/c', 'IFSC', 'Status'],
      rows: emps.map((e) => [e.id, e.name, e.fatherName || '', e.designation || '', e.mobile || '', U.fmtDate(e.dob), U.fmtDate(e.joinDate), e.aadhaar || '', e.pan || '', e.accountNo || '', e.ifsc || '', e.active === false ? 'Inactive' : 'Active'])
    };
  };

  R.export = async function (type, month, fmt) {
    U.loading(true);
    try {
      const r = await R.build(type, month);
      const sub = r.all ? 'All' : r.sub || (U.monthLabel(month).replace(/[^\x20-\x7E]/g, '') || month);
      const subtitle = I18N.lang === 'hi' ? month : sub;
      if (fmt === 'xlsx') await PDF.tableXlsx(r.title, subtitle, r.columns, r.rows, r.foot);
      else await PDF.tablePdf(r.title, subtitle, r.columns, r.rows, r.foot, r.legend);
    } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
  };

  V.adminReports = async function (el, p) {
    const type = p.type || 'attSummary', month = p.month || U.monthKey();
    el.innerHTML = '<h2 class="page-title">' + T('reports') + '</h2>' +
      '<div class="card form"><div class="grid2f"><label class="fld"><span>' + T('reportType') + '</span><select id="rt">' + TYPES.map((t) => '<option value="' + t + '"' + (t === type ? ' selected' : '') + '>' + T('rep_' + t) + '</option>').join('') +
      '</select></label><label class="fld"><span>' + T('month') + '</span>' + App.monthSelect('rm', month) + '</label></div>' +
      '<div class="row-btns"><button class="btn" id="rx">⬇ Excel</button><button class="btn" id="rp">⬇ PDF</button></div></div><div id="rprev"><div class="skeleton"></div></div>';
    const go = () => App.go('adminReports', { type: U.$('#rt').value, month: U.$('#rm').value });
    U.$('#rt').onchange = go; U.$('#rm').onchange = go;
    U.$('#rx').onclick = () => R.export(type, month, 'xlsx');
    U.$('#rp').onclick = () => R.export(type, month, 'pdf');
    const r = await R.build(type, month);
    const fmt = (c) => typeof c === 'number' ? c.toLocaleString('en-IN') : esc(c);
    U.$('#rprev').innerHTML = '<div class="card"><b>' + esc(r.title) + '</b> · <small class="muted">' + (r.all ? T('all') : U.monthLabel(month)) + ' · ' + r.rows.length + ' rows</small>' +
      (r.legend ? '<p class="muted small">' + esc(r.legend) + '</p>' : '') +
      '<div class="table-wrap"><table class="tbl' + (type === 'muster' ? ' muster' : '') + '"><thead><tr>' + r.columns.map((c) => '<th>' + esc(c) + '</th>').join('') + '</tr></thead><tbody>' +
      (r.rows.length ? r.rows.map((row) => '<tr>' + row.map((c) => '<td class="c-' + esc(String(c)).replace(/[^\w]/g, '').slice(0, 2) + '">' + fmt(c) + '</td>').join('') + '</tr>').join('') :
        '<tr><td colspan="' + r.columns.length + '">' + T('noData') + '</td></tr>') + '</tbody>' +
      (r.foot ? '<tfoot><tr>' + r.foot.map((c) => '<td>' + fmt(c) + '</td>').join('') + '</tr></tfoot>' : '') + '</table></div></div>';
  };
})();
