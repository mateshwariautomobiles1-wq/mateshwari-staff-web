// ---------- To-do list with reminders (phone notifications even when app is closed) ----------
(function () {
  const V = window.Views, esc = U.esc;
  const Rem = window.Reminders = {};
  const native = () => { const C = window.Capacitor; return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.LocalNotifications; };
  const nid = (s) => { let h = 7; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h % 2000000000) + 1000; };
  const REMIND = [0, 5, 15, 30, 60, 120, 1440];
  const remLabel = (m) => m === 0 ? T('atTime') : m < 60 ? m + ' ' + T('minBefore') : m < 1440 ? (m / 60) + ' ' + T('hrBefore') : T('dayBefore');
  let webTimers = [];

  function nextOccurrence(t) {
    let at = Number(t.dueAt) - (Number(t.remindMins) || 0) * 60000;
    if (!t.repeat || t.repeat === 'none') return at;
    const now = Date.now(); const d = new Date(at);
    while (d.getTime() <= now) {
      if (t.repeat === 'daily') d.setDate(d.getDate() + 1);
      else if (t.repeat === 'weekly') d.setDate(d.getDate() + 7);
      else d.setMonth(d.getMonth() + 1);
    }
    return d.getTime();
  }

  // build the list of reminders: undone todos + upcoming EMI dues
  async function collect() {
    const out = [];
    try {
      const todos = await DB.query('todos', [['empId', '==', S.user.empId]]);
      todos.filter((t) => !t.done && t.dueAt).forEach((t) => {
        const at = nextOccurrence(t);
        if (at > Date.now()) out.push({ id: nid('todo' + t.id), at, title: '📝 ' + t.title, body: (t.note || '') + (t.by === 'admin' ? ' · ' + T('assignedByAdmin') : ''), repeat: t.repeat, t });
      });
    } catch (e) { }
    try {
      const loans = (await DB.query('loans', [['empId', '==', S.user.empId]])).filter((l) => l.status === 'disbursed');
      loans.forEach((l) => {
        Loan.scheduleStatus(l).filter((x) => x.status !== 'paid').slice(0, 3).forEach((x) => {
          const d = new Date(x.due + 'T10:00:00'); d.setDate(d.getDate() - 1);
          if (d.getTime() > Date.now()) out.push({ id: nid('emi' + l.id + x.n), at: d.getTime(), title: '💰 ' + T('emiReminderTitle'), body: T('emiReminderBody').replace('{a}', U.money(x.emi)).replace('{d}', U.fmtDate(x.due)) });
        });
      });
    } catch (e) { }
    return out;
  }

  Rem.sync = async function () {
    if (!S.user || S.isAdmin) return;
    const list = await collect();
    const LNP = native();
    if (LNP) {
      try {
        let perm = await LNP.checkPermissions();
        if (perm.display !== 'granted') perm = await LNP.requestPermissions();
        if (perm.display !== 'granted') return;
        try { await LNP.createChannel({ id: 'reminders', name: 'Reminders', importance: 5, visibility: 1, vibration: true }); } catch (e) { }
        const pend = await LNP.getPending();
        if (pend.notifications && pend.notifications.length) await LNP.cancel({ notifications: pend.notifications.map((n) => ({ id: n.id })) });
        if (!list.length) return;
        await LNP.schedule({
          notifications: list.slice(0, 60).map((r) => {
            const d = new Date(r.at);
            let schedule = { at: d, allowWhileIdle: true };
            if (r.repeat === 'daily') schedule = { on: { hour: d.getHours(), minute: d.getMinutes() }, allowWhileIdle: true };
            else if (r.repeat === 'weekly') schedule = { on: { weekday: d.getDay() + 1, hour: d.getHours(), minute: d.getMinutes() }, allowWhileIdle: true };
            else if (r.repeat === 'monthly') schedule = { on: { day: d.getDate(), hour: d.getHours(), minute: d.getMinutes() }, allowWhileIdle: true };
            return { id: r.id, title: r.title, body: r.body || ' ', schedule, channelId: 'reminders', smallIcon: 'ic_stat_notify', iconColor: '#DA251D' };
          })
        });
      } catch (e) { console.warn('reminders', e); }
      return;
    }
    // web / browser: in-page timers while the app is open
    webTimers.forEach(clearTimeout); webTimers = [];
    list.filter((r) => r.at - Date.now() < 24 * 3600000).forEach((r) => {
      webTimers.push(setTimeout(() => {
        U.toast(r.title, 'info');
        try { if ('Notification' in window && Notification.permission === 'granted') new Notification(r.title, { body: r.body, icon: 'img/logo.png' }); } catch (e) { }
      }, Math.max(0, r.at - Date.now())));
    });
  };
  Rem.askWebPermission = function () { try { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission(); } catch (e) { } };

  // ================= EMPLOYEE TO-DO =================
  function dtLocal(ms) { const d = new Date(ms); return U.dateKey(d) + 'T' + U.pad(d.getHours()) + ':' + U.pad(d.getMinutes()); }
  function todoRow(t, admin) {
    const over = !t.done && t.dueAt && t.dueAt < Date.now() && (!t.repeat || t.repeat === 'none');
    return '<div class="card todo' + (t.done ? ' done' : '') + (over ? ' over' : '') + '"><div class="row"><input type="checkbox" class="tchk" data-done="' + esc(t.id) + '"' + (t.done ? ' checked' : '') + (admin ? ' disabled' : '') + '>' +
      '<div class="grow"><b>' + (t.priority === 'high' ? '🔴 ' : '') + esc(t.title) + '</b>' + (admin ? ' <small class="muted">· ' + esc(t.empName) + '</small>' : '') +
      '<br><small class="muted">' + (t.dueAt ? '⏰ ' + U.fmtDT(t.dueAt) : '') + (t.repeat && t.repeat !== 'none' ? ' · 🔁 ' + T('rp_' + t.repeat) : '') + (t.dueAt ? ' · 🔔 ' + remLabel(Number(t.remindMins) || 0) : '') +
      (t.by === 'admin' ? ' · 👤 ' + T('assignedByAdmin') : '') + (t.done && t.doneAt ? ' · ✔ ' + U.fmtDT(t.doneAt) : '') + '</small>' + (t.note ? '<div class="small">' + esc(t.note) + '</div>' : '') + '</div>' +
      ((admin || t.by !== 'admin') ? '<button class="icon-btn" data-ted="' + esc(t.id) + '">✏️</button><button class="icon-btn" data-tdel="' + esc(t.id) + '">🗑</button>' : '') + '</div></div>';
  }

  V.empTodo = async function (el, p) {
    const filter = p.filter || 'pending';
    const all = (await DB.query('todos', [['empId', '==', S.user.empId]])).sort((a, b) => (a.done - b.done) || ((a.dueAt || 9e15) - (b.dueAt || 9e15)));
    const list = all.filter((t) => filter === 'all' || (filter === 'done' ? t.done : !t.done));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">📝 ' + T('todoList') + '</h2><button class="btn" id="tnew">+ ' + T('addTask') + '</button></div>' +
      '<p class="muted small">' + T('todoNote') + '</p>' +
      '<div class="chips">' + ['pending', 'done', 'all'].map((f) => '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + T('tf_' + f) + ' (' + all.filter((t) => f === 'all' || (f === 'done' ? t.done : !t.done)).length + ')</button>').join('') + '</div>' +
      (list.length ? list.map((t) => todoRow(t, false)).join('') : U.empty(T('noTasks')));
    U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('empTodo', { filter: b.dataset.f }));
    U.$('#tnew').onclick = () => editTodo(null, false);
    bindRows(el, all, false);
    Rem.askWebPermission();
  };

  function bindRows(el, all, admin) {
    const find = (id) => all.find((t) => t.id === id);
    U.$$('[data-done]', el).forEach((c) => c.onchange = async () => {
      const t = find(c.dataset.done);
      try {
        await DB.update('todos', t.id, { done: c.checked, doneAt: c.checked ? Date.now() : null });
        if (c.checked && t.by === 'admin') await DB.add('notifications', { target: 'admin', targetName: 'Admin', title: '✔ ' + T('taskDone'), body: S.emp.name + ' · ' + t.title, at: DB.now(), by: S.emp.name }).catch(() => { });
        Rem.sync(); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); c.checked = !c.checked; }
    });
    U.$$('[data-ted]', el).forEach((b) => b.onclick = () => editTodo(find(b.dataset.ted), admin));
    U.$$('[data-tdel]', el).forEach((b) => b.onclick = async () => { if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('todos', b.dataset.tdel); Rem.sync(); App.refresh(); } });
  }

  async function editTodo(t, admin) {
    const emps = admin ? await Admin.employees() : [];
    const def = t || { dueAt: Date.now() + 3600000, remindMins: 15, repeat: 'none', priority: 'normal' };
    const m = U.modal(t ? T('editTask') : T('addTask'), '<form class="form" id="tf">' + (admin && !t ? App.empPickerHtml(emps, { all: false, label: T('assignTo') }) : '') +
      U.field('title', T('task'), def.title, { required: true }) + U.field('note', T('note'), def.note, { type: 'textarea', rows: 2 }) +
      '<div class="grid2f">' + U.field('dueAt', T('dateTime'), dtLocal(def.dueAt || Date.now()), { type: 'datetime-local', required: true }) +
      U.field('remindMins', T('remindMe'), def.remindMins, { type: 'select', options: REMIND.map((x) => ({ v: x, l: remLabel(x) })) }) +
      U.field('repeat', T('repeat'), def.repeat || 'none', { type: 'select', options: ['none', 'daily', 'weekly', 'monthly'].map((x) => ({ v: x, l: T('rp_' + x) })) }) +
      U.field('priority', T('priority'), def.priority || 'normal', { type: 'select', options: [{ v: 'normal', l: T('normal') }, { v: 'high', l: '🔴 ' + T('high') }] }) + '</div>' +
      '<button class="btn block">' + T('save') + '</button></form>', { wide: true });
    const f = U.$('#tf', m.el);
    if (admin && !t) App.bindEmpPicker(f);
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const due = new Date(d.dueAt).getTime(); if (!due) return U.toast(T('dateTime') + '?', 'err');
      const data = { title: d.title, note: d.note, dueAt: due, remindMins: Number(d.remindMins) || 0, repeat: d.repeat, priority: d.priority };
      U.loading(true);
      try {
        if (t) await DB.update('todos', t.id, data);
        else if (admin) {
          const pick = App.readEmpPicker(f, emps); if (!pick.list.length) throw new Error(T('selectEmployee'));
          for (const e of pick.list) {
            await DB.add('todos', Object.assign({ empId: e.id, empName: e.name, done: false, by: 'admin', byName: S.user.name || 'Admin', at: DB.now() }, data));
            await DB.add('notifications', { target: e.id, targetName: e.name, title: '📝 ' + T('newTaskAssigned') + ': ' + d.title, body: '⏰ ' + U.fmtDT(due), at: DB.now(), by: S.user.name || 'Admin' });
          }
        } else await DB.add('todos', Object.assign({ empId: S.user.empId, empName: S.emp.name, done: false, by: 'self', at: DB.now() }, data));
        m.close(); U.toast(T('saved'), 'ok'); Rem.sync(); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  }

  // ================= ADMIN: tasks =================
  V.adminTodos = async function (el, p) {
    const filter = p.filter || 'pending';
    const all = (await DB.query('todos', [['by', '==', 'admin']])).sort((a, b) => (a.done - b.done) || ((a.dueAt || 0) - (b.dueAt || 0)));
    const list = all.filter((t) => filter === 'all' || (filter === 'done' ? t.done : !t.done));
    el.innerHTML = '<div class="row-between"><h2 class="page-title">📝 ' + T('staffTasks') + '</h2><button class="btn" id="tnew">+ ' + T('assignTask') + '</button></div>' +
      '<div class="chips">' + ['pending', 'done', 'all'].map((f) => '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + T('tf_' + f) + ' (' + all.filter((t) => f === 'all' || (f === 'done' ? t.done : !t.done)).length + ')</button>').join('') + '</div>' +
      (list.length ? list.map((t) => todoRow(t, true)).join('') : U.empty(T('noTasks')));
    U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('adminTodos', { filter: b.dataset.f }));
    U.$('#tnew').onclick = () => editTodo(null, true);
    bindRows(el, all, true);
  };
})();
