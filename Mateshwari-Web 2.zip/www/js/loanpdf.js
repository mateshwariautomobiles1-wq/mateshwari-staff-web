// ---------- Loan documents: Sanction letter, DPN (ROI blank), Agreement, Statement, EMI card, SOA ----------
// Documents are issued in the name of the lender: the company itself, or the lending partner chosen at sanction.
(function () {
  const P = window.PDF, H = P._, esc = U.esc, LN = window.Loan;
  const n2 = (v) => Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

  // ---------- lending partners ----------
  let pCache = null, pAt = 0;
  LN.loadPartners = async function (fresh) {
    if (!fresh && pCache && Date.now() - pAt < 60000) return pCache;
    try { pCache = (await DB.all('partners')).sort((a, b) => String(a.name).localeCompare(b.name)); } catch (e) { pCache = pCache || []; }
    pAt = Date.now(); return pCache;
  };
  LN.partnerFor = async function (l) {
    if (!l || !l.partnerId) return null;
    const list = await LN.loadPartners();
    return list.find((x) => x.id === l.partnerId) || null;
  };
  const brandOf = (pt) => pt ? { name: pt.name, address: pt.address || '', phone: pt.phone || '', email: pt.email || '', gstin: pt.gstin || '', cin: pt.cin || '', reg: pt.reg || '',
    logo: pt.logo || '', sign: pt.sign || '', signName: pt.signName || '', signDesig: pt.signDesig || 'Authorised Signatory' } : null;
  // template: partner override -> global loan setting
  const tpl = (pt, k) => (pt && String(pt[k] || '').trim()) ? pt[k] : LN.settings()[k];

  async function borrower(l) {
    if (!S.isAdmin && S.emp && S.emp.id === l.empId) return S.emp;
    try { return (await DB.get('employees', l.empId)) || {}; } catch (e) { return {}; }
  }

  // run fn with lender brand + borrower signature set
  async function ctx(l, fn) {
    const pt = await LN.partnerFor(l), emp = await borrower(l);
    const oldSign = P.borrowerSign; P.borrowerSign = emp.signature || null;
    try { return await P.withBrand(brandOf(pt), () => fn(pt, emp)); } finally { P.borrowerSign = oldSign; }
  }

  function vars(l, pt) {
    const a = l.applicant || {}, t = LN.terms(l), g = l.guarantor || {};
    const lender = pt ? pt.name : P.company().name;
    return {
      t, name: a.name || l.empName, empId: l.empId, father: a.fatherName || '________', address: a.address || '________', designation: a.designation || '',
      amount: n2(t.P), amountWords: U.numToWords(t.P), tenure: t.n, emi: n2(t.emi), netAmount: n2(t.net), charges: n2(t.charges), interest: '________',
      loanNo: l.loanNo || '-', date: U.fmtDate(l.approvedAt || new Date()), showroom: lender, lender, dealer: P.company().name,
      guarantor: g.name ? g.name + ' (' + g.empId + ')' : '-'
    };
  }
  const showRoi = () => S.isAdmin || LN.can('roi');
  function termsRows(l, v, withRoi, pt) {
    const t = v.t;
    const rows = [['Loan No.', v.loanNo]];
    if (pt) rows.push(['Lender', pt.name], ['Sourced through', v.dealer]);
    rows.push(['Sanctioned Amount', 'Rs. ' + v.amount + ' (' + v.amountWords + ' Only)'], ['Tenure', t.n + ' months'], ['Monthly EMI', 'Rs. ' + v.emi]);
    if (withRoi) rows.push(['Rate of Interest', LN.roiText(t)], ['Total Interest', 'Rs. ' + n2(t.totalInterest)], ['Total Payable', 'Rs. ' + n2(t.totalPayable)]);
    rows.push(['Processing Fee', 'Rs. ' + n2(t.pf)], ['GST on Processing Fee', 'Rs. ' + n2(t.gst)], ['Documentation Charges', 'Rs. ' + n2(t.doc)], ['Stamp Duty', 'Rs. ' + n2(t.stamp)],
      ['Total Charges (deducted)', 'Rs. ' + n2(t.charges)], ['Net Amount to Account', 'Rs. ' + n2(t.net)]);
    if (l.firstEmiDate) rows.push(['First EMI Date', U.fmtDate(l.firstEmiDate)]);
    if (l.guarantor) rows.push(['Guarantor', v.guarantor]);
    return rows;
  }
  const tableHtml = (rows) => '<table class="tbl doc-tbl">' + rows.map((r) => '<tr><td>' + esc(r[0]) + '</td><td><b>' + esc(r[1]) + '</b></td></tr>').join('') + '</table>';
  function autoTable(doc, y, rows, head, opts) {
    doc.autoTable(Object.assign({ startY: y, head: head ? [head] : undefined, body: rows.map((r) => r.map((c) => H.L(c))), theme: 'grid', styles: { fontSize: 9.5, cellPadding: 1.8 },
      headStyles: { fillColor: [218, 37, 29] }, columnStyles: head ? {} : { 0: { cellWidth: 70, fontStyle: 'bold', fillColor: [250, 246, 246] } }, margin: { left: 14, right: 14 } }, opts || {}));
    return doc.lastAutoTable.finalY + 6;
  }
  const closeAndReset = () => {};

  // ---------- Sanction letter ----------
  P.showLoanLetter = (l) => ctx(l, async (pt, emp) => {
    const v = vars(l, pt), ls = LN.settings();
    const m = U.modal(T('sanctionLetter'), '<div class="letter">' + H.headHtml('LOAN SANCTION LETTER') +
      '<div class="row-between"><span>Ref: ' + esc(v.loanNo) + '</span><span>Date: ' + esc(v.date) + '</span></div>' +
      '<p>To,<br><b>' + esc(v.name) + '</b><br>' + esc(v.designation) + ' (Emp ID: ' + esc(v.empId) + ')</p><p><b>Subject: Sanction of Staff Loan</b></p>' +
      '<p>' + esc(U.fillTemplate(tpl(pt, 'letterTemplate'), v)).replace(/\n/g, '<br>') + '</p>' + tableHtml(termsRows(l, v, showRoi(), pt)) +
      (tpl(pt, 'terms') ? '<p class="small"><b>Terms &amp; Conditions</b><br>' + esc(tpl(pt, 'terms')).replace(/\n/g, '<br>') + '</p>' : '') +
      P.signHtml('Borrower Signature', 'For ' + v.lender + '\nAuthorised Signatory', emp.signature) + '</div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.loanLetterPdf(l);
  });
  P.loanLetterPdf = (l) => ctx(l, async (pt) => {
    const v = vars(l, pt);
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'LOAN SANCTION LETTER');
    const W = doc.internal.pageSize.getWidth();
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    doc.text('Ref: ' + H.L(v.loanNo), 14, y); doc.text('Date: ' + v.date, W - 14, y, { align: 'right' }); y += 9;
    y = H.paragraph(doc, 'To,\n' + v.name + '\n' + v.designation + ' (Emp ID: ' + v.empId + ')', y, 10.5) + 3;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.text('Subject: Sanction of Staff Loan', 14, y); y += 7;
    y = H.paragraph(doc, U.fillTemplate(tpl(pt, 'letterTemplate'), v), y, 10) + 2;
    y = autoTable(doc, y, termsRows(l, v, showRoi(), pt));
    const terms = tpl(pt, 'terms');
    if (terms) { if (y > 240) { doc.addPage(); y = 20; } doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5); doc.text('Terms & Conditions', 14, y); y = H.paragraph(doc, terms, y + 5, 9); }
    if (y > 250) { doc.addPage(); y = 20; }
    H.signature(doc, y, 'Borrower Signature', 'For ' + v.lender + ' (Authorised Signatory)');
    await P.savePdf(doc, 'Sanction_Letter_' + safeName(v.loanNo) + '.pdf');
  });

  // ---------- DPN (ROI always blank) ----------
  P.showDPN = (l) => ctx(l, async (pt, emp) => {
    const v = vars(l, pt);
    const m = U.modal('DPN', '<div class="letter">' + H.headHtml('DEMAND PROMISSORY NOTE') +
      '<div class="row-between"><b>Rs. ' + esc(v.amount) + '/-</b><span>Date: ________</span></div><p>Place: ________________</p>' +
      '<p>' + esc(U.fillTemplate(tpl(pt, 'dpnTemplate'), v)).replace(/\n/g, '<br>') + '</p><div class="stamp">Revenue<br>Stamp</div>' +
      P.signHtml('Witness 1\nName: ____________', '') + P.signHtml('Witness 2\nName: ____________', 'Signature of Borrower\n' + v.name) + '</div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.dpnPdf(l);
  });
  P.dpnPdf = (l) => ctx(l, async (pt) => {
    const v = vars(l, pt);
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'DEMAND PROMISSORY NOTE');
    const W = doc.internal.pageSize.getWidth();
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text('Rs. ' + v.amount + '/-', 14, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.text('Date: ____________', W - 14, y, { align: 'right' }); y += 7;
    doc.text('Place: ____________________', 14, y); y += 10;
    y = H.paragraph(doc, U.fillTemplate(tpl(pt, 'dpnTemplate'), v), y, 11.5) + 8;
    doc.rect(W - 44, y, 30, 30); doc.setFontSize(8); doc.text('Affix Revenue', W - 29, y + 13, { align: 'center' }); doc.text('Stamp', W - 29, y + 17, { align: 'center' });
    y += 40;
    H.signature(doc, y, 'Witness 1 (Name & Sign)', '', { rightImg: '' });
    H.signature(doc, y + 22, 'Witness 2 (Name & Sign)', 'Signature of Borrower: ' + v.name, { rightImg: P.borrowerSign || '' });
    await P.savePdf(doc, 'DPN_' + safeName(v.loanNo) + '.pdf');
  });

  // ---------- Loan Agreement ----------
  const agreementTerms = (pt) => String(tpl(pt, 'agreementTerms') || '').split('\n').map((x) => x.trim()).filter(Boolean);
  function partiesText(v, pt, g) {
    return 'This Loan Agreement is made on ' + v.date + ' between ' + v.lender + (pt ? ' (the "Lender"), through ' + v.dealer + ' (the "Employer")' : ' (the "Company")') + ', and ' + v.name +
      ', S/o / D/o ' + v.father + ', Employee ID ' + v.empId + ', ' + v.designation + ', residing at ' + v.address + ' (the "Borrower")' +
      (g.name ? ', and ' + g.name + ', Employee ID ' + g.empId + (g.fatherName ? ', S/o / D/o ' + g.fatherName : '') + (g.address ? ', residing at ' + g.address : '') + ' (the "Guarantor")' : '') + '.';
  }
  P.showAgreement = (l) => ctx(l, async (pt, emp) => {
    const v = vars(l, pt), r1 = l.ref1 || {}, g = l.guarantor || {};
    const m = U.modal(T('loanAgreement'), '<div class="letter">' + H.headHtml('STAFF LOAN AGREEMENT') + '<p>' + esc(partiesText(v, pt, g)) + '</p>' +
      '<h4>1. Loan Details</h4>' + tableHtml(termsRows(l, v, true, pt)) +
      '<h4>2. References</h4><p>Reference 1: ' + esc(r1.name || '-') + ' (' + esc(r1.relation || '-') + '), Mob: ' + esc(r1.mobile || '-') + ', ' + esc(r1.address || '') + '<br>Reference 2 / Guarantor: ' + esc(v.guarantor) +
      (g.mobile ? ', Mob: ' + esc(g.mobile) : '') + '</p>' +
      '<h4>3. Terms &amp; Conditions</h4><ol class="small">' + agreementTerms(pt).map((x) => '<li>' + esc(x) + '</li>').join('') + '</ol>' +
      P.signHtml('Borrower', 'Guarantor', emp.signature) + P.signHtml('Witness', 'For ' + v.lender + '\nAuthorised Signatory') + '</div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.agreementPdf(l);
  });
  P.agreementPdf = (l) => ctx(l, async (pt) => {
    const v = vars(l, pt), r1 = l.ref1 || {}, g = l.guarantor || {};
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'STAFF LOAN AGREEMENT');
    y = H.paragraph(doc, partiesText(v, pt, g), y, 10) + 3;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('1. Loan Details', 14, y); y += 3;
    y = autoTable(doc, y, termsRows(l, v, true, pt));
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('2. Repayment Schedule', 14, y); y += 3;
    y = autoTable(doc, y, LN.terms(l).schedule.map((x) => [x.n, U.fmtDate(x.due), n2(x.emi), n2(x.principal), n2(x.interest), n2(x.balance)]), ['#', 'Due Date', 'EMI', 'Principal', 'Interest', 'Balance']);
    if (y > 240) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('3. References', 14, y); y += 6;
    y = H.paragraph(doc, 'Reference 1: ' + (r1.name || '-') + ' (' + (r1.relation || '-') + '), Mob: ' + (r1.mobile || '-') + ', ' + (r1.address || '') + '\nReference 2 / Guarantor: ' + v.guarantor + (g.mobile ? ', Mob: ' + g.mobile : ''), y, 10) + 3;
    if (y > 230) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('4. Terms & Conditions', 14, y); y += 6;
    y = H.paragraph(doc, agreementTerms(pt).map((x, i) => (i + 1) + '. ' + x).join('\n'), y, 9.5) + 4;
    if (y > 230) { doc.addPage(); y = 20; }
    H.signature(doc, y, 'Borrower: ' + v.name, 'Guarantor: ' + (g.name || '________'), { rightImg: '' });
    H.signature(doc, y + 26, 'Witness (Name & Sign)', 'For ' + v.lender + ' (Authorised Signatory)');
    await P.savePdf(doc, 'Loan_Agreement_' + safeName(v.loanNo) + '.pdf');
  });

  // ---------- helpers for statement-type docs ----------
  async function photoBlock(doc, emp, x, y, w, h) {
    if (emp.photo) { await P.addImageFit(doc, emp.photo, x, y, w, h); doc.setDrawColor(200); doc.rect(x, y, w, h); }
    else { doc.setDrawColor(200); doc.rect(x, y, w, h); doc.setFontSize(7); doc.setTextColor(150); doc.text('PHOTO', x + w / 2, y + h / 2, { align: 'center' }); doc.setTextColor(20); }
  }
  function borrowerRows(l, emp, v) {
    const a = l.applicant || {};
    return [['Borrower', v.name + ' (' + v.empId + ')'], ['Designation', a.designation || emp.designation || '-'], ['Father\'s Name', a.fatherName || emp.fatherName || '-'],
      ['Mobile', a.mobile || emp.mobile || '-'], ['Address', a.address || emp.address || '-']];
  }

  // ---------- Loan statement ----------
  P.loanStatementPdf = (l) => ctx(l, async (pt) => {
    const v = vars(l, pt);
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'LOAN ACCOUNT STATEMENT');
    y = autoTable(doc, y, [['Borrower', v.name + ' (' + v.empId + ')'], ['Loan No.', v.loanNo], ['Loan Amount', 'Rs. ' + v.amount], ['EMI', 'Rs. ' + v.emi + ' x ' + v.tenure],
      ['Disbursed On', U.fmtDate(l.disbursedAt)], ['Outstanding', 'Rs. ' + n2(LN.outstanding(l))], ['Statement Date', U.fmtDate(new Date())]]);
    y = autoTable(doc, y, LN.ledgerRows(l).map((e) => [U.fmtDate(e.date), (I18N.dict.en['lt_' + e.type] || e.type) + (e.note ? ' - ' + e.note : '') + (e.mode ? ' [' + e.mode + (e.ref ? ' ' + e.ref : '') + ']' : ''),
      U.num(e.debit) ? n2(e.debit) : '', U.num(e.credit) ? n2(e.credit) : '', n2(e.balance)]), ['Date', 'Particulars', 'Debit', 'Credit', 'Balance']);
    await P.savePdf(doc, 'Loan_Statement_' + safeName(v.loanNo) + '.pdf');
  });

  // ---------- EMI card (only EMI amounts, no principal / interest) ----------
  P.emiCardPdf = (l) => ctx(l, async (pt, emp) => {
    const v = vars(l, pt), t = v.t;
    const rows = ['disbursed', 'closed'].includes(l.status) ? LN.scheduleStatus(l) : t.schedule.map((x) => Object.assign({ status: 'due', paidAmt: 0 }, x));
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'EMI CARD');
    const W = doc.internal.pageSize.getWidth();
    await photoBlock(doc, emp, W - 42, y - 4, 28, 33);
    const info = [['Name', v.name + ' (' + v.empId + ')'], ['Loan No.', v.loanNo], ['Loan Amount', 'Rs. ' + v.amount], ['Monthly EMI', 'Rs. ' + v.emi], ['No. of EMIs', String(t.n)],
      ['First EMI', U.fmtDate(l.firstEmiDate || (t.schedule[0] || {}).due)], ['Lender', v.lender]];
    y = autoTable(doc, y - 4, info, null, { margin: { left: 14, right: 48 }, columnStyles: { 0: { cellWidth: 40, fontStyle: 'bold', fillColor: [250, 246, 246] } } });
    y = Math.max(y, 90);
    const st = { paid: 'PAID', partial: 'PART PAID', overdue: 'OVERDUE', due: '' };
    y = autoTable(doc, y, rows.map((x) => [x.n, U.fmtDate(x.due), 'Rs. ' + n2(x.emi), st[x.status] || '', '']), ['EMI No.', 'Due Date', 'EMI Amount', 'Status', 'Remark / Sign'],
      { styles: { fontSize: 10, cellPadding: 2.4 }, didParseCell: (d) => { if (d.section === 'body' && d.column.index === 3) { const s = String(d.cell.raw); if (s === 'PAID') d.cell.styles.textColor = [30, 142, 78]; if (s === 'OVERDUE') d.cell.styles.textColor = [198, 40, 40]; } } });
    doc.setFontSize(8.5); doc.setTextColor(110);
    doc.text(H.L('Please pay your EMI on or before the due date. Late payment will attract penalty as per terms.'), 14, Math.min(y, 280));
    doc.setTextColor(20);
    await P.savePdf(doc, 'EMI_Card_' + safeName(v.loanNo) + '.pdf');
  });

  // ---------- SOA: complete statement of account with photo ----------
  P.soaPdf = (l) => ctx(l, async (pt, emp) => {
    const v = vars(l, pt), t = v.t, roi = showRoi(), detail = S.isAdmin || LN.can('scheduleDetail');
    const sch = LN.scheduleStatus(l), led = LN.ledgerRows(l);
    const doc = H.newDoc(); let y = await H.letterhead(doc, 'STATEMENT OF ACCOUNT');
    const W = doc.internal.pageSize.getWidth();
    doc.setFontSize(9); doc.text('As on: ' + U.fmtDate(new Date()), W - 14, y - 4, { align: 'right' });
    await photoBlock(doc, emp, W - 42, y, 28, 33);
    y = autoTable(doc, y, borrowerRows(l, emp, v), null, { margin: { left: 14, right: 48 }, columnStyles: { 0: { cellWidth: 38, fontStyle: 'bold', fillColor: [250, 246, 246] } } });
    y = Math.max(y, 88);
    const paid = sch.filter((x) => x.status === 'paid').length, od = sch.filter((x) => x.status === 'overdue' || (x.status === 'partial' && x.due < U.dateKey()));
    const odAmt = od.reduce((s, x) => s + x.emi - x.paidAmt, 0);
    const dr = led.reduce((s, e) => s + U.num(e.debit), 0), cr = led.reduce((s, e) => s + U.num(e.credit), 0);
    const loanRows = [['Loan No.', v.loanNo], ['Lender', v.lender], ['Sanction Date', U.fmtDate(l.approvedAt)], ['Disbursal Date', U.fmtDate(l.disbursedAt) + (l.disburseMode ? ' (' + l.disburseMode + (l.disburseRef ? ' ' + l.disburseRef : '') + ')' : '')],
      ['Loan Amount', 'Rs. ' + v.amount], ['Tenure / EMI', t.n + ' months / Rs. ' + v.emi]];
    if (roi) loanRows.push(['Rate of Interest', LN.roiText(t)]);
    loanRows.push(['Charges Deducted', 'Rs. ' + n2(t.charges)], ['Net Disbursed', 'Rs. ' + n2(t.net)], ['Guarantor', v.guarantor], ['Loan Status', String(l.status).toUpperCase()]);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('Loan Details', 14, y); y += 2;
    y = autoTable(doc, y, loanRows);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('Account Summary', 14, y); y += 2;
    y = autoTable(doc, y, [['Total Debits', 'Rs. ' + n2(dr)], ['Total Credits (paid)', 'Rs. ' + n2(cr)], ['Outstanding', 'Rs. ' + n2(LN.outstanding(l))],
      ['EMIs Paid', paid + ' of ' + t.n], ['Overdue EMIs', od.length + (od.length ? ' (Rs. ' + n2(odAmt) + ')' : '')]]);
    if (y > 230) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('Transactions', 14, y); y += 2;
    y = autoTable(doc, y, led.map((e) => [U.fmtDate(e.date), (I18N.dict.en['lt_' + e.type] || e.type) + (e.note ? ' - ' + e.note : '') + (e.mode ? ' [' + e.mode + (e.ref ? ' ' + e.ref : '') + ']' : ''),
      U.num(e.debit) ? n2(e.debit) : '', U.num(e.credit) ? n2(e.credit) : '', n2(e.balance)]), ['Date', 'Particulars', 'Debit', 'Credit', 'Balance'], { styles: { fontSize: 8.5, cellPadding: 1.5 } });
    if (y > 230) { doc.addPage(); y = 20; }
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.text('Repayment Schedule', 14, y); y += 2;
    const stx = { paid: 'Paid', partial: 'Partial', overdue: 'Overdue', due: 'Due' };
    y = autoTable(doc, y, sch.map((x) => detail ? [x.n, U.fmtDate(x.due), n2(x.emi), n2(x.principal), n2(x.interest), n2(x.paidAmt), stx[x.status]] : [x.n, U.fmtDate(x.due), n2(x.emi), n2(x.paidAmt), stx[x.status]]),
      detail ? ['#', 'Due', 'EMI', 'Principal', 'Interest', 'Paid', 'Status'] : ['#', 'Due', 'EMI', 'Paid', 'Status'], { styles: { fontSize: 8.5, cellPadding: 1.5 } });
    if (y > 250) { doc.addPage(); y = 20; }
    H.signature(doc, y, '', 'For ' + v.lender + ' (Authorised Signatory)');
    doc.setFontSize(7.5); doc.setTextColor(120); doc.text('This is a system generated statement.', 14, doc.internal.pageSize.getHeight() - 8); doc.setTextColor(20);
    await P.savePdf(doc, 'SOA_' + safeName(v.loanNo) + '.pdf');
  });
})();
