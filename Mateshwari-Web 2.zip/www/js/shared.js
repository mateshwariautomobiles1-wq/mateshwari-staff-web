// ---------- Shared modules: documents, cashier, attendance approval ----------
(function () {
  const V = window.Views, esc = U.esc;
  const DOC_CATS = ['Aadhaar Card', 'PAN Card', 'Bank Passbook / Cheque', 'Driving Licence', 'Photo', 'Education Certificate', 'Experience Letter', 'Agreement', 'Other'];

  const Docs = window.Docs = {};

  Docs.listHtml = function (docs, o) {
    if (!docs.length) return U.empty(T('noDocuments'));
    docs.sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    return '<div class="card list">' + docs.map((d) => {
      const canMod = o.admin || (o.canEdit && d.status !== 'approved');
      return '<div class="li"><div class="doc-ic">' + (/pdf/.test(d.mime) ? '📕' : '🖼️') + '</div><div class="grow"><b>' + esc(d.name) + '</b><small>' + esc(d.category) + ' · ' +
        U.fmtDate(d.at) + ' · ' + Math.round((d.size || 0) / 1024) + ' KB' + (o.showEmp ? ' · ' + esc(d.empName) : '') + '</small><div class="row-btns left">' +
        '<button class="btn sm ghost" data-view="' + d.id + '">👁 ' + T('view') + '</button>' +
        (canMod ? '<button class="btn sm ghost" data-edit="' + d.id + '">✏️</button><button class="btn sm ghost" data-del="' + d.id + '">🗑</button>' : '') +
        (o.admin && d.status === 'pending' ? '<button class="btn sm" data-ok="' + d.id + '">✔ ' + T('approve') + '</button><button class="btn sm danger" data-no="' + d.id + '">✕</button>' : '') +
        '</div></div>' + U.badge(d.status) + '</div>';
    }).join('') + '</div>';
  };

  Docs.bind = function (el, docs, o) {
    const find = (id) => docs.find((d) => d.id === id);
    U.$$('[data-view]', el).forEach((b) => b.onclick = () => Docs.view(find(b.dataset.view)));
    U.$$('[data-edit]', el).forEach((b) => b.onclick = () => Docs.edit(find(b.dataset.edit), o));
    U.$$('[data-del]', el).forEach((b) => b.onclick = async () => {
      if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return;
      U.loading(true);
      try { await DB.del('documents', b.dataset.del); await Files.del('docfiles', b.dataset.del); U.toast(T('deleted'), 'ok'); o.reload(); }
      catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
    U.$$('[data-ok]', el).forEach((b) => b.onclick = async () => { await DB.update('documents', b.dataset.ok, { status: 'approved', reviewedAt: DB.now() }); U.toast(T('approved'), 'ok'); o.reload(); });
    U.$$('[data-no]', el).forEach((b) => b.onclick = async () => { await DB.update('documents', b.dataset.no, { status: 'rejected', reviewedAt: DB.now() }); o.reload(); });
  };

  async function readFile(file) {
    if (/^image\//.test(file.type)) {
      const data = await U.compressImage(file, 1400, 0.72);
      return { data, mime: 'image/jpeg', size: Math.round(data.length * 0.75) };
    }
    if (file.type === 'application/pdf') {
      if (file.size > Files.MAX_PDF) throw new Error(T('pdfTooBig'));
      const data = await U.fileToDataURL(file);
      return { data, mime: 'application/pdf', size: file.size };
    }
    throw new Error(T('onlyImagePdf'));
  }

  Docs.upload = function (empId, empName, isAdmin, done) {
    const m = U.modal(T('uploadDocument'), '<form class="form" id="upf">' +
      U.field('category', T('docType'), DOC_CATS[0], { type: 'select', options: DOC_CATS }) +
      U.field('name', T('docName'), '', { placeholder: 'e.g. Aadhaar front' }) +
      '<label class="fld"><span>' + T('chooseFile') + ' (JPG/PNG/PDF)</span><input type="file" name="_file" accept="image/*,application/pdf" required></label>' +
      '<button class="btn block">' + T('upload') + '</button></form>');
    U.$('#upf', m.el).onsubmit = async (ev) => {
      ev.preventDefault();
      const f = ev.target.querySelector('[name=_file]').files[0];
      if (!f) return U.toast(T('chooseFile'), 'err');
      const fd = U.formData(ev.target); const cat = fd.category, name = fd.name || cat;
      U.loading(true, T('uploading'));
      try {
        const r = await readFile(f);
        const id = U.uid();
        const autoOk = isAdmin || App.can('docsApprove');
        await Files.put('docfiles', id, { empId }, r.data);
        await DB.set('documents', id, { empId, empName, name, category: cat, mime: r.mime, size: r.size, status: autoOk ? 'approved' : 'pending', uploadedBy: isAdmin ? 'admin' : 'self', at: DB.now() });
        m.close(); U.toast(T('uploaded'), 'ok'); done && done();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  Docs.view = async function (d) {
    U.loading(true);
    try {
      const f = await Files.get('docfiles', d.id);
      if (!f) throw new Error(T('fileMissing'));
      if (/^data:image/.test(f.data)) {
        const m = U.modal(d.name, '<img src="' + f.data + '" class="doc-img" alt=""><div class="row-btns"><button class="btn" data-dl>⬇ ' + T('download') + '</button></div>', { wide: true });
        m.el.querySelector('[data-dl]').onclick = () => U.openDataUrl(safeName(d.name) + '.jpg', f.data);
      } else U.openDataUrl(safeName(d.name) + '.pdf', f.data);
    } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
  };
  const safeName = (s) => String(s || 'file').replace(/[^\w\-]+/g, '_');
  window.safeName = safeName;

  Docs.edit = function (d, o) {
    const m = U.modal(T('editDocument'), '<form class="form" id="edf">' +
      U.field('category', T('docType'), d.category, { type: 'select', options: DOC_CATS }) +
      U.field('name', T('docName'), d.name) +
      '<label class="fld"><span>' + T('replaceFile') + '</span><input type="file" name="_file" accept="image/*,application/pdf"></label>' +
      '<button class="btn block">' + T('save') + '</button></form>');
    U.$('#edf', m.el).onsubmit = async (ev) => {
      ev.preventDefault();
      const f = ev.target.querySelector('[name=_file]').files[0];
      U.loading(true);
      try {
        const fd = U.formData(ev.target);
        const upd = { category: fd.category, name: fd.name || d.name };
        if (f) {
          const r = await readFile(f);
          await Files.del('docfiles', d.id); await Files.put('docfiles', d.id, { empId: d.empId }, r.data);
          upd.mime = r.mime; upd.size = r.size;
          if (!o.admin && !App.can('docsApprove')) upd.status = 'pending';
        }
        await DB.update('documents', d.id, upd);
        m.close(); U.toast(T('saved'), 'ok'); o.reload();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  // ===== Directory (names list readable by cashier / approver) =====
  App.directory = async function () {
    const list = await DB.all('directory');
    return list.filter((d) => d.active !== false).sort((a, b) => String(a.name).localeCompare(b.name));
  };

  // ===== CASHIER / PAYMENT LEDGER ENTRY =====
  const PAY_TYPES = ['salary', 'advance', 'incentive', 'reimbursement', 'other'];
  V.cashier = async function (el, p) {
    if (!App.can('cashier')) { el.innerHTML = '<div class="note">' + T('noRight') + '</div>'; return; }
    const month = p.month || U.monthKey();
    const emps = await App.directory();
    const filterEmp = p.emp || '';
    let list = await DB.query('payments', [['month', '==', month]]);
    if (filterEmp) list = list.filter((x) => x.empId === filterEmp);
    list.sort((a, b) => b.date.localeCompare(a.date) || ((U.toDate(b.at) || 0) - (U.toDate(a.at) || 0)));
    const total = list.reduce((s, x) => s + U.num(x.amount), 0);
    el.innerHTML = '<h2 class="page-title">' + T('paymentLedger') + '</h2>' +
      '<form id="payf" class="card form"><h3>' + T('newPaymentEntry') + '</h3>' +
      U.field('empId', T('employee'), filterEmp, { type: 'select', options: [{ v: '', l: '-- ' + T('select') + ' --' }].concat(emps.map((e) => ({ v: e.id, l: e.name + ' (' + e.id + ')' }))) }) +
      '<div class="grid2f">' + U.field('date', T('date'), U.dateKey(), { type: 'date', required: true }) +
      U.field('amount', T('amount'), '', { type: 'number', required: true, min: 1 }) +
      U.field('type', T('paymentType'), 'advance', { type: 'select', options: PAY_TYPES.map((t) => ({ v: t, l: T('pt_' + t) })) }) +
      U.field('mode', T('mode'), 'Cash', { type: 'select', options: ['Cash', 'UPI', 'Bank Transfer', 'Cheque'] }) + '</div>' +
      U.field('note', T('note'), '') + '<button class="btn block">' + T('saveEntry') + '</button></form>' +
      '<div class="row-between filters">' + App.monthSelect('pm', month) +
      '<select id="pe"><option value="">' + T('allEmployees') + '</option>' + emps.map((e) => '<option value="' + esc(e.id) + '"' + (e.id === filterEmp ? ' selected' : '') + '>' + esc(e.name) + '</option>').join('') + '</select></div>' +
      '<div class="card total-bar">' + T('total') + ': <b>' + U.money(total) + '</b> (' + list.length + ')</div>' +
      (list.length ? '<div class="card list">' + list.map((x) => '<div class="li"><div class="grow"><b>' + esc(x.empName) + '</b><small>' + U.fmtDate(x.date) + ' · ' + esc(T('pt_' + (x.type || 'other'))) + ' · ' + esc(x.mode) +
        (x.note ? ' · ' + esc(x.note) : '') + ' · ' + T('by') + ' ' + esc(x.enteredByName || '') + '</small></div><b class="amt">' + U.money(x.amount) + '</b>' +
        (S.isAdmin ? '<button class="icon-btn" data-pdel="' + x.id + '">🗑</button>' : '') + '</div>').join('') + '</div>' : U.empty(T('noPayments')));
    const go = () => App.go('cashier', { month: U.$('#pm').value, emp: U.$('#pe').value });
    U.$('#pm').onchange = go; U.$('#pe').onchange = go;
    U.$('#payf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      if (!d.empId) return U.toast(T('selectEmployee'), 'err');
      if (!(d.amount > 0)) return U.toast(T('enterAmount'), 'err');
      const emp = emps.find((e) => e.id === d.empId);
      const ok = await U.confirm(T('confirmPayment').replace('{a}', U.money(d.amount)).replace('{n}', emp.name), T('save'));
      if (!ok) return;
      U.loading(true);
      try {
        await DB.add('payments', {
          empId: d.empId, empName: emp.name, date: d.date, month: d.date.slice(0, 7), amount: Number(d.amount), type: d.type, mode: d.mode, note: d.note,
          enteredBy: DB.auth.currentUser.uid, enteredByName: S.isAdmin ? (S.user.name || 'Admin') : S.emp.name, at: DB.now()
        });
        U.toast(T('saved'), 'ok'); App.go('cashier', { month: d.date.slice(0, 7), emp: filterEmp });
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
    U.$$('[data-pdel]').forEach((b) => b.onclick = async () => {
      if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return;
      await DB.del('payments', b.dataset.pdel); U.toast(T('deleted'), 'ok'); App.refresh();
    });
  };

  // ===== ATTENDANCE APPROVAL (admin + employees with right) =====
  V.attApprove = async function (el, p) {
    if (!App.can('approveAttendance')) { el.innerHTML = '<div class="note">' + T('noRight') + '</div>'; return; }
    const month = p.month || U.monthKey();
    const filter = p.filter || 'pending';
    let list = await DB.query('attendance', [['month', '==', month]]);
    const counts = { pending: 0, approved: 0, rejected: 0 };
    list.forEach((a) => { counts[a.status] = (counts[a.status] || 0) + 1; });
    if (filter !== 'all') list = list.filter((a) => a.status === filter);
    if (p.date) list = list.filter((a) => a.date === p.date);
    list.sort((a, b) => b.date.localeCompare(a.date) || String(a.empName).localeCompare(b.empName));
    el.innerHTML = (S.isAdmin ? '' : '<h2 class="page-title">' + T('approveAttendance') + '</h2>') +
      '<div class="row-between filters">' + App.monthSelect('am', month) + '<input type="date" id="ad" value="' + esc(p.date || '') + '"></div>' +
      '<div class="chips">' + ['pending', 'approved', 'rejected', 'all'].map((f) => '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + T(f === 'all' ? 'all' : 'st_' + f) +
        (counts[f] != null ? ' (' + counts[f] + ')' : '') + '</button>').join('') + '</div>' +
      (filter === 'pending' && list.length ? '<button class="btn sm" id="apAll">✔ ' + T('approveAllShown') + ' (' + list.length + ')</button>' : '') +
      (list.length ? list.map(attCard).join('') : U.empty());
    const nav = (o) => App.go(S.view, Object.assign({}, S.params, { month: U.$('#am').value, filter, date: U.$('#ad').value }, o));
    U.$('#am').onchange = () => nav({ date: '' });
    U.$('#ad').onchange = () => nav({});
    U.$$('[data-f]').forEach((b) => b.onclick = () => nav({ filter: b.dataset.f }));
    U.$$('[data-ap]').forEach((b) => b.onclick = () => review(b.dataset.ap, b.dataset.v, list));
    U.$$('[data-map]').forEach((b) => b.onclick = () => {
      const a = list.find((x) => x.id === b.dataset.map);
      const pt = a[b.dataset.k];
      U.modal(T('location'), '<p>Lat: ' + pt.lat + '<br>Lng: ' + pt.lng + '<br>±' + pt.acc + 'm' + (pt.dist != null ? '<br>' + T('distanceFromShowroom') + ': ' + pt.dist + 'm' : '') +
        '</p><p class="muted small">' + T('openMapHint') + '</p><input readonly value="https://maps.google.com/?q=' + pt.lat + ',' + pt.lng + '" onclick="this.select()">');
    });
    const aa = U.$('#apAll');
    if (aa) aa.onclick = async () => {
      if (!(await U.confirm(T('approveAllConfirm').replace('{n}', list.length), T('approve')))) return;
      U.loading(true);
      try {
        for (const a of list) await DB.update('attendance', a.id, { status: 'approved', dayType: a.dayType || 'full', reviewedBy: reviewerName(), reviewedAt: DB.now() });
        U.toast(T('approved'), 'ok'); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };
  const reviewerName = () => S.isAdmin ? (S.user.name || 'Admin') : S.emp.name;

  function attCard(a) {
    const ci = a.checkIn, co = a.checkOut;
    const hrs = ci && co ? ((co.at - ci.at) / 3600000).toFixed(1) : null;
    const late = ci && S.settings.officeStart && U.fmtTime(ci.at) && isLate(ci.at);
    return '<div class="card att-row"><div class="row-between"><div><b>' + esc(a.empName) + '</b> <small class="muted">' + esc(a.empId) + '</small><br><small>' + U.fmtDate(a.date) +
      (a.manual ? ' · ' + T('manualEntry') : '') + '</small></div>' + U.badge(a.status) + '</div>' +
      '<div class="att-times"><div>' + T('in') + ': <b>' + (ci ? U.fmtTime(ci.at) : '-') + '</b>' + (late ? ' <span class="badge bad">' + T('late') + '</span>' : '') +
      (ci && ci.lat ? ' <a data-map="' + a.id + '" data-k="checkIn">📍' + (ci.dist != null ? ci.dist + 'm' : '') + '</a>' : '') + (ci && ci.inside === false ? ' <span class="badge bad">' + T('outside') + '</span>' : '') + '</div>' +
      '<div>' + T('out') + ': <b>' + (co ? U.fmtTime(co.at) : '-') + '</b>' + (co && co.lat ? ' <a data-map="' + a.id + '" data-k="checkOut">📍' + (co.dist != null ? co.dist + 'm' : '') + '</a>' : '') +
      (co && co.inside === false ? ' <span class="badge bad">' + T('outside') + '</span>' : '') + '</div>' + (hrs ? '<div>' + T('hours') + ': <b>' + hrs + '</b></div>' : '') + '</div>' +
      (a.note ? '<small class="muted">' + T('note') + ': ' + esc(a.note) + '</small>' : '') +
      '<div class="row-btns left">' + (a.status !== 'approved' || a.dayType === 'half' ? '<button class="btn sm" data-ap="' + a.id + '" data-v="full">✔ ' + T('fullDay') + '</button>' : '') +
      (a.dayType !== 'half' || a.status !== 'approved' ? '<button class="btn sm ghost" data-ap="' + a.id + '" data-v="half">½ ' + T('halfDay') + '</button>' : '') +
      (a.status !== 'rejected' ? '<button class="btn sm danger" data-ap="' + a.id + '" data-v="reject">✕ ' + T('reject') + '</button>' : '') + '</div></div>';
  }
  function isLate(ts) {
    const d = U.toDate(ts); const [h, m] = String(S.settings.officeStart || '09:30').split(':').map(Number);
    return d.getHours() * 60 + d.getMinutes() > h * 60 + m + 10;
  }

  async function review(id, v, list) {
    let note = '';
    if (v === 'reject') { note = await U.prompt(T('reject'), T('reasonOptional'), ''); if (note == null) return; }
    const upd = v === 'reject' ? { status: 'rejected', note } : { status: 'approved', dayType: v };
    upd.reviewedBy = reviewerName(); upd.reviewedAt = DB.now();
    try { await DB.update('attendance', id, upd); U.toast(v === 'reject' ? T('rejected') : T('approved'), 'ok'); App.refresh(); }
    catch (e) { U.toast(e.message, 'err'); }
  }
})();

// ---------- Calendar helpers: weekly off, holidays, attendance summary ----------
(function () {
  const Cal = window.Cal = {};
  const DAYS_EN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const DAYS_HI = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];
  Cal.dayName = (i) => (I18N.lang === 'hi' ? DAYS_HI : DAYS_EN)[i];
  Cal.weeklyOffOptions = (withDefault) => (withDefault ? [{ v: '', l: T('useShowroomDefault') }] : [])
    .concat([0, 1, 2, 3, 4, 5, 6].map((i) => ({ v: i, l: Cal.dayName(i) }))).concat([{ v: -1, l: T('noWeeklyOff') }]);

  // Showroom weekly off: 0-6 = day, -1 = none (all days working)
  Cal.showroomOff = function () {
    const s = S.settings || {};
    if (s.weeklyOff !== undefined && s.weeklyOff !== null && s.weeklyOff !== '') return Number(s.weeklyOff);
    return s.sundayPaid === false ? -1 : 0;
  };
  Cal.weeklyOff = function (e) {
    const v = e && e.weeklyOff;
    if (v !== undefined && v !== null && v !== '') return Number(v);
    return Cal.showroomOff();
  };

  const cache = {};
  // returns {date: name}
  Cal.holidays = async function (month, fresh) {
    if (!fresh && cache[month] && Date.now() - cache[month].t < 60000) return cache[month].m;
    const list = await DB.query('holidays', [['month', '==', month]]);
    const m = {}; list.forEach((h) => { m[h.date] = h.name; });
    cache[month] = { m, t: Date.now() };
    return m;
  };
  Cal.clearCache = () => { Object.keys(cache).forEach((k) => delete cache[k]); };

  Cal.upto = function (month) {
    const cur = U.monthKey();
    if (month === cur) return new Date().getDate();
    if (month > cur) return 0;
    return U.daysInMonth(month);
  };

  // Summary for one employee. att = that employee's attendance docs for the month
  Cal.summary = function (e, att, month, hol) {
    hol = hol || {};
    const [y, m] = month.split('-').map(Number);
    const upto = Cal.upto(month);
    const wo = Cal.weeklyOff(e);
    let startDay = 1;
    if (e && e.joinDate && e.joinDate.slice(0, 7) === month) startDay = Number(e.joinDate.slice(8, 10)) || 1;
    if (e && e.joinDate && e.joinDate.slice(0, 7) > month) startDay = 99;
    const byDate = {}; att.forEach((a) => { byDate[a.date] = a; });
    const ap = att.filter((a) => a.status === 'approved');
    const full = ap.filter((a) => a.dayType !== 'half').length;
    const half = ap.filter((a) => a.dayType === 'half').length;
    const present = full + half * 0.5;
    const approvedSet = new Set(ap.map((a) => a.date));
    let working = 0, offs = 0, hols = 0, paidWO = 0, paidHol = 0;
    for (let d = startDay; d <= upto; d++) {
      const dt = new Date(y, m - 1, d), key = U.dateKey(dt);
      const isOff = wo >= 0 && dt.getDay() === wo;
      const isHol = !!hol[key];
      if (isOff) {
        offs++;
        // weekly off is paid if employee worked at least one day in the 6 days before it
        for (let k = 1; k <= 6; k++) { if (approvedSet.has(U.dateKey(new Date(y, m - 1, d - k)))) { paidWO++; break; } }
      } else if (isHol) {
        hols++;
        if (!approvedSet.has(key)) paidHol++;
      } else working++;
    }
    if (present === 0) { paidWO = 0; paidHol = 0; }
    return {
      emp: e, full, half, present, pending: att.filter((a) => a.status === 'pending').length,
      rejected: att.filter((a) => a.status === 'rejected').length, working, offs, hols, paidWO, paidHol, weeklyOff: wo,
      pct: working ? Math.min(100, Math.round(present / working * 100)) : (present ? 100 : 0)
    };
  };

  const wo0 = (e, dt) => { const w = Cal.weeklyOff(e); return w >= 0 && dt.getDay() === w; };
  // Day code for muster / calendars
  Cal.dayCode = function (e, month, d, a, hol) {
    const [y, m] = month.split('-').map(Number);
    const dt = new Date(y, m - 1, d), key = U.dateKey(dt);
    if (a) {
      if (a.status === 'approved') return a.dayType === 'half' ? 'H' : 'P';
      if (a.status === 'pending') return '?';
      return 'R';
    }
    if (dt > new Date()) return hol[key] ? 'HO' : '';
    if (e && e.joinDate && key < e.joinDate) return '';
    if (hol[key]) return 'HO';
    if (key === U.dateKey() && !a) {
      const [eh, em] = String((S.settings && S.settings.officeEnd) || '19:00').split(':').map(Number);
      const n = new Date(); if (n.getHours() * 60 + n.getMinutes() < eh * 60 + em) return wo0(e, dt) ? 'WO' : '';
    }
    const wo = Cal.weeklyOff(e);
    if (wo >= 0 && dt.getDay() === wo) return 'WO';
    if (e && e.joinDate && key < e.joinDate) return '';
    return 'A';
  };
})();

// ---------- Month calendar widget ----------
(function () {
  App.calendarHtml = function (e, month, att, hol) {
    const [y, m] = month.split('-').map(Number);
    const D = U.daysInMonth(month);
    const first = new Date(y, m - 1, 1).getDay();
    const map = {}; att.forEach((a) => { map[a.date] = a; });
    let cells = '';
    for (let i = 0; i < first; i++) cells += '<i></i>';
    for (let d = 1; d <= D; d++) {
      const key = month + '-' + U.pad(d);
      const c = Cal.dayCode(e, month, d, map[key], hol);
      cells += '<i class="cd c-' + (c === '?' ? 'Q' : c || 'N') + (key === U.dateKey() ? ' today' : '') + '" title="' + U.esc(hol[key] || '') + '"><b>' + d + '</b><small>' + (c || '') + '</small></i>';
    }
    const heads = [0, 1, 2, 3, 4, 5, 6].map((i) => '<span>' + Cal.dayName(i).slice(0, I18N.lang === 'hi' ? 3 : 2) + '</span>').join('');
    return '<div class="card"><div class="cal-head">' + heads + '</div><div class="cal">' + cells + '</div>' +
      '<div class="cal-legend small muted">P=' + T('present') + ' · H=' + T('halfDay') + ' · A=' + T('st_absent') + ' · WO=' + T('weeklyOff') + ' · HO=' + T('holiday') + ' · ?=' + T('pending') + '</div></div>';
  };
})();

// ---------- Attendance day-wise list incl. absent / weekly off / holiday rows ----------
(function () {
  App.attListHtml = function (e, month, att, hol) {
    const esc = U.esc;
    const [y, m] = month.split('-').map(Number);
    const map = {}; att.forEach((a) => { map[a.date] = a; });
    const upto = Cal.upto(month);
    const rows = [];
    for (let d = upto; d >= 1; d--) {
      const key = month + '-' + U.pad(d), a = map[key];
      const code = Cal.dayCode(e, month, d, a, hol);
      if (a) {
        rows.push('<div class="li"><div class="grow"><b>' + U.fmtDate(key) + '</b><small>' + T('in') + ' ' + (a.checkIn ? U.fmtTime(a.checkIn.at) : '-') + ' · ' + T('out') + ' ' + (a.checkOut ? U.fmtTime(a.checkOut.at) : '-') +
          (a.dayType === 'half' ? ' · ' + T('halfDay') : '') + (hol[key] ? ' · 🎉 ' + esc(hol[key]) : '') + (a.note ? '<br>' + esc(a.note) : '') + '</small></div>' + U.badge(a.status) + '</div>');
      } else if (code === 'A') {
        rows.push('<div class="li abs-row"><div class="grow"><b>' + U.fmtDate(key) + '</b><small>' + T('noCheckIn') + '</small></div>' + U.badge('absent') + '</div>');
      } else if (code === 'WO') {
        rows.push('<div class="li off-row"><div class="grow"><b>' + U.fmtDate(key) + '</b><small>' + Cal.dayName(new Date(y, m - 1, d).getDay()) + '</small></div><span class="badge muted">' + T('weeklyOff') + '</span></div>');
      } else if (code === 'HO') {
        rows.push('<div class="li off-row"><div class="grow"><b>' + U.fmtDate(key) + '</b><small>🎉 ' + esc(hol[key] || '') + '</small></div><span class="badge hol">' + T('holiday') + '</span></div>');
      }
    }
    // future holidays of the month
    Object.keys(hol).filter((k) => k.startsWith(month) && !map[k] && Number(k.slice(8)) > upto).sort().forEach((k) => {
      rows.unshift('<div class="li off-row"><div class="grow"><b>' + U.fmtDate(k) + '</b><small>🎉 ' + esc(hol[k]) + '</small></div><span class="badge hol">' + T('holiday') + '</span></div>');
    });
    return rows.length ? '<div class="card list">' + rows.join('') + '</div>' : U.empty();
  };
})();
