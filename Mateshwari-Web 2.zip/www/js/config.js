// =====================================================================
//  MATESHWARI AUTOMOBILES - STAFF APP CONFIG
//  Firebase Console > Project settings > Your apps > Web app > Config
//  Neeche apni Firebase config paste karein (sirf yahi file badalni hai)
// =====================================================================
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAfd60w6ARCH1eSddXoh1SM9HGlOvF3X-k",
  authDomain: "mateshwari-staff.firebaseapp.com",
  projectId: "mateshwari-staff",
  storageBucket: "mateshwari-staff.firebasestorage.app",
  messagingSenderId: "869746141888",
  appId: "1:869746141888:web:7fcb86066de1edf6d75b25"
};

window.APP_INFO = {
  showroom: "MATESHWARI AUTOMOBILES",
  tagline: "Authorised Dealer",
  // Staff login ke liye internal email domain (badalne ki zarurat nahi)
  staffDomain: "staff.mateshwari.app",
  version: "1.3.0"
};
