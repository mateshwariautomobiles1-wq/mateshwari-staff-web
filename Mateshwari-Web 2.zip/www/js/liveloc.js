// ---------- Live location (only during duty: checked-in and not checked-out) ----------
(function () {
  const V = window.Views, esc = U.esc;
  const LL = window.LiveLoc = {};
  let timer = null, busy = false, trail = null, lastOk = 0;

  LL.enabled = () => S.settings && S.settings.liveTracking !== false;

  LL.start = function () {
    LL.stop();
    if (S.isAdmin || !LL.enabled()) return;
    const mins = Math.max(2, Number(S.settings.trackMins) || 5);
    timer = setInterval(LL.tick, mins * 60000);
    setTimeout(LL.tick, 4000);
    document.addEventListener('visibilitychange', onVis);
  };
  LL.stop = function () { if (timer) clearInterval(timer); timer = null; document.removeEventListener('visibilitychange', onVis); trail = null; };
  function onVis() { if (document.visibilityState === 'visible' && Date.now() - lastOk > 60000) LL.tick(); }

  LL.onDuty = async function () {
    const a = await DB.get('attendance', S.user.empId + '_' + U.dateKey());
    return !!(a && a.checkIn && !a.checkOut);
  };

  LL.tick = async function (force) {
    if (busy || !S.user || S.isAdmin || !LL.enabled()) return;
    busy = true;
    try {
      if (!force && !(await LL.onDuty())) return;
      const loc = await U.getLocation();
      const today = U.dateKey();
      if (!trail) {
        try { const d = await DB.get('liveloc', S.user.empId); trail = d && d.date === today ? (d.points || []) : []; } catch (e) { trail = []; }
      }
      if (trail.length && trail[0].d !== today) trail = [];
      trail.push({ lat: Number(loc.lat.toFixed(6)), lng: Number(loc.lng.toFixed(6)), acc: loc.acc, at: Date.now(), d: today });
      if (trail.length > 60) trail = trail.slice(-60);
      const st = S.settings;
      const dist = st.lat != null ? U.distance(loc.lat, loc.lng, st.lat, st.lng) : null;
      await DB.set('liveloc', S.user.empId, {
        empId: S.user.empId, empName: S.emp.name, designation: S.emp.designation || '', lat: loc.lat, lng: loc.lng, acc: loc.acc, dist,
        at: Date.now(), serverAt: DB.now(), date: today, points: trail
      });
      lastOk = Date.now();
    } catch (e) { console.warn('liveloc', e && e.message); }
    finally { busy = false; }
  };

  LL.ago = function (ms) {
    const m = Math.round((Date.now() - ms) / 60000);
    if (m < 1) return T('justNow');
    if (m < 60) return m + ' ' + T('minAgo');
    const h = Math.floor(m / 60);
    if (h < 24) return h + ' ' + T('hrAgo');
    return U.fmtDT(ms);
  };
  const dot = (ms) => { const m = (Date.now() - ms) / 60000; return m <= 15 ? '🟢' : m <= 90 ? '🟡' : '⚪'; };

  function mapHtml(lat, lng) {
    const d = 0.004;
    const src = 'https://www.openstreetmap.org/export/embed.html?bbox=' + (lng - d) + '%2C' + (lat - d) + '%2C' + (lng + d) + '%2C' + (lat + d) + '&layer=mapnik&marker=' + lat + '%2C' + lng;
    return '<iframe class="map-frame" src="' + src + '" loading="lazy"></iframe><a href="https://maps.google.com/?q=' + lat + ',' + lng + '" target="_blank" rel="noopener">🗺️ ' + T('openMap') + '</a>';
  }
  LL.mapHtml = mapHtml;

  V.adminLiveLoc = async function (el) {
    el.innerHTML = '<div class="row-between"><h2 class="page-title">📍 ' + T('liveLocation') + '</h2><span class="pill" id="llc"></span></div>' +
      '<p class="muted small">' + T('liveLocNote') + '</p>' + (LL.enabled() ? '' : '<div class="note">' + T('liveLocOff') + '</div>') + '<div id="lll"><div class="skeleton"></div></div>';
    let list = [];
    const render = () => {
      const box = U.$('#lll'); if (!box) return;
      list.sort((a, b) => (b.at || 0) - (a.at || 0));
      const today = U.dateKey();
      const live = list.filter((x) => Date.now() - x.at <= 15 * 60000).length;
      U.$('#llc').textContent = '🟢 ' + live + ' ' + T('liveNow');
      box.innerHTML = list.length ? list.map((x) => '<div class="card ll-row" data-e="' + esc(x.empId) + '"><div class="row-between"><div><b>' + dot(x.at) + ' ' + esc(x.empName) + '</b><br><small class="muted">' + esc(x.designation || x.empId) + '</small></div>' +
        '<div class="right"><small>' + LL.ago(x.at) + '</small><br><small class="muted">' + (x.dist != null ? (x.dist > 1000 ? (x.dist / 1000).toFixed(1) + ' km' : x.dist + ' m') + ' ' + T('fromShowroom') : '') + '</small></div></div>' +
        '<small class="muted">±' + x.acc + 'm · ' + (x.date === today ? (x.points || []).length + ' ' + T('pointsToday') : T('notToday')) + '</small></div>').join('') : U.empty(T('noLiveData'));
      U.$$('.ll-row', box).forEach((c) => c.onclick = () => {
        const x = list.find((z) => z.empId === c.dataset.e);
        const pts = (x.points || []).slice().reverse();
        U.modal('📍 ' + x.empName, mapHtml(x.lat, x.lng) + '<p class="small">' + T('lastSeen') + ': <b>' + U.fmtDT(x.at) + '</b> · ±' + x.acc + 'm</p>' +
          '<h4>' + T('todayTrail') + '</h4>' + (pts.length ? '<div class="card list">' + pts.map((p) => '<div class="li"><div class="grow"><b>' + U.fmtTime(p.at) + '</b><small>' + p.lat + ', ' + p.lng +
            (S.settings.lat != null ? ' · ' + U.distance(p.lat, p.lng, S.settings.lat, S.settings.lng) + ' m' : '') + '</small></div><a href="https://maps.google.com/?q=' + p.lat + ',' + p.lng + '" target="_blank" rel="noopener">🗺️</a></div>').join('') + '</div>' : U.empty()), { wide: true });
      });
    };
    const un = DB.watch('liveloc', [], (l) => { list = l; render(); }, () => { const b = U.$('#lll'); if (b) b.innerHTML = U.empty(T('error')); });
    S.unsubs.push(un);
    const iv = setInterval(() => { if (!U.$('#lll')) { clearInterval(iv); try { un(); } catch (e) { } return; } render(); }, 30000);
  };
})();
