// ---------- Notifications with attachment & multiple recipients, document requests, staff insurance ----------
(function () {
  const V = window.Views, esc = U.esc;
  const by = () => S.isAdmin ? (S.user.name || 'Admin') : (S.emp && S.emp.name) || '';
  const BASE_CATS = ['Aadhaar Card', 'PAN Card', 'Bank Passbook / Cheque', 'Driving Licence', 'Photo', 'Education Certificate', 'Experience Letter', 'Agreement', 'Other'];
  const INS = 'Staff Insurance';
  const cats = () => (S.isAdmin || (S.settings && S.settings.insuranceUpload) ? [INS] : []).concat(BASE_CATS);

  // ================= multi-employee picker =================
  App.empPickerHtml = function (emps, opts) {
    opts = opts || {};
    return '<div class="fld"><span>' + esc(opts.label || T('sendTo')) + '</span>' + U.field('_all', '📢 ' + T('allEmployees'), opts.all !== false, { type: 'checkbox' }) +
      '<input class="search" id="epq" placeholder="🔍 ' + T('search') + '" style="' + (opts.all !== false ? 'display:none' : '') + '">' +
      '<div id="empPick" class="pick-list"' + (opts.all !== false ? ' style="display:none"' : '') + '>' + emps.map((e) => '<label class="chk" data-q="' + esc((e.name + ' ' + e.id).toLowerCase()) + '"><input type="checkbox" data-emp="' + esc(e.id) + '"' +
        ((opts.selected || []).includes(e.id) ? ' checked' : '') + '> <span>' + esc(e.name) + ' <small class="muted">' + esc(e.id) + '</small></span></label>').join('') + '</div><small class="muted" id="epc"></small></div>';
  };
  App.bindEmpPicker = function (root) {
    const all = U.$('[name=_all]', root), list = U.$('#empPick', root), q = U.$('#epq', root), c = U.$('#epc', root);
    const cnt = () => { const n = U.$$('[data-emp]', root).filter((x) => x.checked).length; c.textContent = all.checked ? '' : n + ' ' + T('selected'); };
    all.onchange = () => { list.style.display = all.checked ? 'none' : ''; q.style.display = all.checked ? 'none' : ''; cnt(); };
    q.oninput = () => { const s = q.value.toLowerCase(); U.$$('label[data-q]', root).forEach((l) => { l.style.display = l.dataset.q.includes(s) ? '' : 'none'; }); };
    U.$$('[data-emp]', root).forEach((x) => x.onchange = cnt); cnt();
  };
  App.readEmpPicker = function (root, emps) {
    if (U.$('[name=_all]', root).checked) return { all: true, list: emps };
    const ids = U.$$('[data-emp]', root).filter((x) => x.checked).map((x) => x.dataset.emp);
    return { all: false, list: emps.filter((e) => ids.includes(e.id)) };
  };

  // ================= NOTIFICATIONS =================
  async function readAttach(input) {
    const f = input.files && input.files[0]; if (!f) return null;
    const r = await App.readDocFile(f); return Object.assign(r, { name: f.name });
  }

  V.adminNotify = async function (el) {
    const emps = await Admin.employees();
    const sent = (S.notifs || []).filter((n) => n.target !== 'admin');
    const groups = []; const gmap = {};
    sent.forEach((n) => { const k = n.groupId || n.id; if (!gmap[k]) { gmap[k] = { k, n, ids: [], names: [] }; groups.push(gmap[k]); } gmap[k].ids.push(n.id); gmap[k].names.push(n.target === 'all' ? T('allEmployees') : (n.targetName || n.target)); });
    const inbox = (S.notifs || []).filter((n) => n.target === 'admin');
    el.innerHTML = '<h2 class="page-title">' + T('notifications') + '</h2><form id="nf" class="card form"><h3>' + T('sendNotification') + '</h3>' + App.empPickerHtml(emps) +
      U.field('title', T('title'), '', { required: true }) + U.field('body', T('message'), '', { type: 'textarea', rows: 4, required: true }) +
      '<label class="fld"><span>📎 ' + T('attachment') + ' (JPG/PNG/PDF, ' + T('optional') + ')</span><input type="file" name="_file" accept="image/*,application/pdf"></label>' +
      U.field('askUpload', T('askReplyUpload'), false, { type: 'checkbox' }) + '<div id="askBox" style="display:none">' + U.field('reqCat', T('docType'), 'Other', { type: 'select', options: cats() }) + '</div>' +
      '<button class="btn block">📤 ' + T('send') + '</button></form>' +
      (inbox.length ? '<h3 class="sec-title">📥 ' + T('fromStaff') + '</h3>' + inbox.slice(0, 20).map((n) => '<div class="card notif"><div class="row-between"><b>' + esc(n.title) + '</b><small class="muted">' + U.fmtDT(n.at) + '</small></div><p>' + esc(n.body) + '</p></div>').join('') : '') +
      '<h3 class="sec-title">' + T('sent') + '</h3>' +
      (groups.length ? groups.map((g) => '<div class="card notif"><div class="row-between"><b>' + esc(g.n.title) + '</b><button class="icon-btn" data-ng="' + esc(g.k) + '">🗑</button></div><p>' + esc(g.n.body).replace(/\n/g, '<br>') + '</p>' +
        (g.n.fileId ? '<button class="btn sm ghost" data-file="' + esc(g.n.fileId) + '" data-fn="' + esc(g.n.fileName || 'file') + '">📎 ' + esc(g.n.fileName || T('attachment')) + '</button>' : '') +
        '<div class="names small"><b>' + T('to') + ' (' + g.names.length + '):</b> ' + g.names.map(esc).join(', ') + '</div><small class="muted">' + U.fmtDT(g.n.at) + '</small></div>').join('') : U.empty());
    const f = U.$('#nf');
    App.bindEmpPicker(f);
    f.askUpload.onchange = () => { U.$('#askBox').style.display = f.askUpload.checked ? '' : 'none'; };
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const pick = App.readEmpPicker(f, emps);
      if (!pick.list.length) return U.toast(T('selectEmployee'), 'err');
      U.loading(true);
      try {
        const att = await readAttach(f.querySelector('[name=_file]'));
        const gid = 'G' + U.uid();
        const base = { title: d.title, body: d.body, at: DB.now(), by: by(), groupId: gid };
        if (att) { await Files.put('notiffiles', gid, { mime: att.mime, name: att.name, all: pick.all, targets: pick.all ? [] : pick.list.map((e) => e.id) }, att.data); Object.assign(base, { fileId: gid, fileName: att.name, fileMime: att.mime }); }
        if (pick.all) await DB.add('notifications', Object.assign({ target: 'all', targetName: 'All' }, base));
        else for (const e of pick.list) await DB.add('notifications', Object.assign({ target: e.id, targetName: e.name }, base));
        if (d.askUpload) for (const e of pick.list) await DB.add('docrequests', { empId: e.id, empName: e.name, title: d.title, category: d.reqCat, note: d.body, status: 'open', at: DB.now(), by: by(), groupId: gid });
        U.toast(T('sent') + ' · ' + (pick.all ? T('allEmployees') : pick.list.length), 'ok'); setTimeout(App.refresh, 500);
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
    U.$$('[data-ng]').forEach((b) => b.onclick = async () => {
      if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return;
      const g = gmap[b.dataset.ng];
      for (const id of g.ids) await DB.del('notifications', id);
      if (g.n.fileId) await Files.del('notiffiles', g.n.fileId);
      setTimeout(App.refresh, 300);
    });
    bindFiles(el);
  };
  function bindFiles(el) {
    U.$$('[data-file]', el).forEach((b) => b.onclick = async () => {
      U.loading(true);
      try { const f = await Files.get('notiffiles', b.dataset.file); App.viewFile(b.dataset.fn, f && f.data); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
  }

  V.notifications = async function (el) {
    if (S.isAdmin) return V.adminNotify(el);
    try { localStorage.setItem(App.lastSeenKey(), String(Date.now())); } catch (e) { }
    App.updateNotifDot();
    const list = S.notifs.filter((n) => n.target === 'all' || n.target === S.user.empId);
    let reqs = [];
    try { reqs = (await DB.query('docrequests', [['empId', '==', S.user.empId]])).filter((r) => r.status === 'open' || r.status === 'rejected'); } catch (e) { }
    el.innerHTML = '<h2 class="page-title">' + T('notifications') + '</h2>' +
      (reqs.length ? '<div class="card warn-card" onclick="App.go(\'empDocs\')">📤 ' + T('docRequestsPending').replace('{n}', reqs.length) + '</div>' : '') +
      (list.length ? list.map((n) => '<div class="card notif"><div class="row-between"><b>' + esc(n.title) + '</b><small class="muted">' + U.fmtDT(n.at) + '</small></div><p>' + esc(n.body).replace(/\n/g, '<br>') + '</p>' +
        (n.fileId ? '<button class="btn sm ghost" data-file="' + esc(n.fileId) + '" data-fn="' + esc(n.fileName || 'file') + '">📎 ' + esc(n.fileName || T('attachment')) + '</button>' : '') + '</div>').join('') : U.empty());
    bindFiles(el);
  };

  // ================= DOCUMENTS =================
  Docs.listHtml = function (docs, o) {
    if (!docs.length) return U.empty(T('noDocuments'));
    docs.sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    return '<div class="card list">' + docs.map((d) => {
      const canMod = o.admin || (o.canEdit && d.status !== 'approved');
      const ins = d.category === INS && d.meta ? '<br>🛡️ ' + esc([d.meta.insurer, d.meta.policyNo, d.meta.sumInsured ? '₹' + d.meta.sumInsured : '', d.meta.expiry ? T('validTill') + ' ' + U.fmtDate(d.meta.expiry) : ''].filter(Boolean).join(' · ')) : '';
      return '<div class="li"><div class="doc-ic">' + (/pdf/.test(d.mime) ? '📕' : d.category === INS ? '🛡️' : '🖼️') + '</div><div class="grow"><b>' + esc(d.name) + '</b><small>' + esc(d.category) + ' · ' +
        U.fmtDate(d.at) + ' · ' + Math.round((d.size || 0) / 1024) + ' KB' + (o.showEmp ? ' · ' + esc(d.empName) : '') + (d.requestId ? ' · 📤 ' + T('requested') : '') + ins +
        (d.remark ? '<br>' + T('remark') + ': ' + esc(d.remark) : '') + '</small><div class="row-btns left">' +
        '<button class="btn sm ghost" data-view="' + d.id + '">👁 ' + T('view') + '</button>' +
        (canMod ? '<button class="btn sm ghost" data-edit="' + d.id + '">✏️</button><button class="btn sm ghost" data-del="' + d.id + '">🗑</button>' : '') +
        (o.admin && d.status !== 'approved' ? '<button class="btn sm" data-ok="' + d.id + '">✔ ' + T('approve') + '</button>' : '') +
        (o.admin && d.status !== 'rejected' ? '<button class="btn sm danger" data-no="' + d.id + '">✕</button>' : '') +
        '</div></div>' + U.badge(d.status) + '</div>';
    }).join('') + '</div>';
  };
  const oldBind = Docs.bind;
  Docs.bind = function (el, docs, o) {
    oldBind(el, docs, o);
    const review = async (id, ok) => {
      const d = docs.find((x) => x.id === id);
      const remark = await U.prompt(ok ? T('approve') : T('reject'), T('remarkOptional'), d.remark || ''); if (remark == null) return;
      await DB.update('documents', id, { status: ok ? 'approved' : 'rejected', remark, reviewedAt: DB.now(), reviewedBy: by() });
      if (d.requestId) await DB.update('docrequests', d.requestId, { status: ok ? 'approved' : 'rejected', remark, reviewedAt: DB.now() }).catch(() => { });
      await DB.add('notifications', { target: d.empId, targetName: d.empName, title: (ok ? '✅ ' : '❌ ') + d.name + ' · ' + (ok ? T('approved') : T('rejected')), body: remark || d.category, at: DB.now(), by: by() }).catch(() => { });
      o.reload();
    };
    U.$$('[data-ok]', el).forEach((b) => b.onclick = () => review(b.dataset.ok, true));
    U.$$('[data-no]', el).forEach((b) => b.onclick = () => review(b.dataset.no, false));
  };

  // upload (optionally for a request)
  Docs.upload = function (empId, empName, isAdmin, done, req) {
    const list = req ? [req.category || 'Other'] : cats();
    const m = U.modal(req ? '📤 ' + req.title : T('uploadDocument'), '<form class="form" id="upf">' +
      (req && req.note ? '<div class="note small">' + esc(req.note) + '</div>' : '') +
      U.field('category', T('docType'), list[0], { type: 'select', options: list }) + U.field('name', T('docName'), req ? req.title : '', { placeholder: 'e.g. Aadhaar front' }) +
      '<div id="insBox" style="display:none"><div class="grid2f">' + U.field('insurer', T('insurer'), '') + U.field('policyNo', T('policyNo'), '') + U.field('sumInsured', T('sumInsured') + ' ₹', '', { type: 'number' }) +
      U.field('expiry', T('validTill'), '', { type: 'date' }) + '</div></div>' +
      '<label class="fld"><span>' + T('chooseFile') + ' (JPG/PNG/PDF)</span><input type="file" name="_file" accept="image/*,application/pdf" required></label>' +
      '<button class="btn block">' + T('upload') + '</button></form>');
    const f = U.$('#upf', m.el);
    const ins = () => { U.$('#insBox', m.el).style.display = f.category.value === INS ? '' : 'none'; };
    f.category.onchange = ins; ins();
    f.onsubmit = async (ev) => {
      ev.preventDefault();
      const file = f.querySelector('[name=_file]').files[0]; if (!file) return U.toast(T('chooseFile'), 'err');
      const fd = U.formData(f); const cat = fd.category, name = fd.name || cat;
      U.loading(true, T('uploading'));
      try {
        const r = await App.readDocFile(file);
        const id = U.uid();
        const autoOk = isAdmin || (!req && App.can('docsApprove'));
        await Files.put('docfiles', id, { empId }, r.data);
        const doc = { empId, empName, name, category: cat, mime: r.mime, size: r.size, status: autoOk ? 'approved' : 'pending', uploadedBy: isAdmin ? 'admin' : 'self', at: DB.now() };
        if (cat === INS) doc.meta = { insurer: fd.insurer, policyNo: fd.policyNo, sumInsured: fd.sumInsured, expiry: fd.expiry };
        if (req) doc.requestId = req.id;
        await DB.set('documents', id, doc);
        if (req) {
          await DB.update('docrequests', req.id, { status: 'submitted', docId: id, submittedAt: DB.now() });
          await DB.add('notifications', { target: 'admin', targetName: 'Admin', title: '📤 ' + T('docSubmitted'), body: empName + ' · ' + req.title, at: DB.now(), by: by() }).catch(() => { });
        }
        m.close(); U.toast(T('uploaded'), 'ok'); done && done();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };

  // employee documents page (requests + own docs + insurance)
  V.empDocs = async function (el) {
    let reqs = [];
    try { reqs = (await DB.query('docrequests', [['empId', '==', S.user.empId]])).sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0)); } catch (e) { }
    const openR = reqs.filter((r) => r.status === 'open' || r.status === 'rejected');
    const canView = App.can('docsView');
    const docs = canView ? await DB.query('documents', [['empId', '==', S.user.empId]]) : [];
    el.innerHTML = '<h2 class="page-title">' + T('myDocuments') + '</h2>' +
      (openR.length ? '<h3 class="sec-title">📤 ' + T('requestedByAdmin') + '</h3>' + openR.map((r) => '<div class="card req-card"><div class="row-between"><b>' + esc(r.title) + '</b>' + U.badge(r.status === 'rejected' ? 'rejected' : 'pending') + '</div>' +
        '<small class="muted">' + esc(r.category || '') + (r.dueDate ? ' · ' + T('dueDate') + ' ' + U.fmtDate(r.dueDate) : '') + '</small>' + (r.note ? '<p class="small">' + esc(r.note) + '</p>' : '') +
        (r.remark ? '<p class="small low">' + T('remark') + ': ' + esc(r.remark) + '</p>' : '') + '<button class="btn sm" data-req="' + esc(r.id) + '">⬆️ ' + T('upload') + '</button></div>').join('') : '') +
      (reqs.filter((r) => r.status === 'submitted' || r.status === 'approved').length ? '<div class="card list">' + reqs.filter((r) => r.status === 'submitted' || r.status === 'approved').map((r) =>
        '<div class="li"><div class="grow"><b>📤 ' + esc(r.title) + '</b><small>' + (r.remark ? esc(r.remark) : esc(r.category || '')) + '</small></div>' + U.badge(r.status === 'submitted' ? 'pending' : 'approved') + '</div>').join('') + '</div>' : '') +
      (canView ? '<h3 class="sec-title">' + T('myDocuments') + '</h3>' + (App.can('docsAdd') ? '<button class="btn" id="upDoc">⬆️ ' + T('uploadDocument') + '</button>' : '') +
        Docs.listHtml(docs, { canEdit: App.can('docsEdit'), admin: false }) : '<div class="note">' + T('noRight') + '</div>');
    U.$$('[data-req]').forEach((b) => b.onclick = () => Docs.upload(S.user.empId, S.emp.name, false, () => App.go('empDocs'), reqs.find((r) => r.id === b.dataset.req)));
    const u = U.$('#upDoc'); if (u) u.onclick = () => Docs.upload(S.user.empId, S.emp.name, false, () => App.go('empDocs'));
    if (canView) Docs.bind(el, docs, { canEdit: App.can('docsEdit'), admin: false, reload: () => App.go('empDocs') });
  };

  // admin documents page with requests
  V.adminDocs = async function (el, p) {
    const filter = p.filter || 'pending';
    if (filter === 'requests') return adminRequests(el);
    const docs = filter === 'all' ? await DB.all('documents') : filter === 'insurance' ? await DB.query('documents', [['category', '==', INS]]) : await DB.query('documents', [['status', '==', filter]]);
    el.innerHTML = '<h2 class="page-title">' + T('documents') + '</h2>' + chips(filter) + Docs.listHtml(docs, { admin: true, showEmp: true });
    bindChips();
    Docs.bind(el, docs, { admin: true, reload: App.refresh });
  };
  const chips = (filter) => '<div class="chips">' + ['pending', 'approved', 'rejected', 'all', 'insurance', 'requests'].map((f) =>
    '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + (f === 'insurance' ? '🛡️ ' + T('insurance') : f === 'requests' ? '📤 ' + T('docRequests') : T(f === 'all' ? 'all' : 'st_' + f)) + '</button>').join('') + '</div>';
  const bindChips = () => U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('adminDocs', { filter: b.dataset.f }));

  async function adminRequests(el) {
    const [reqs, emps] = await Promise.all([DB.all('docrequests'), Admin.employees()]);
    reqs.sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
    el.innerHTML = '<h2 class="page-title">' + T('documents') + '</h2>' + chips('requests') +
      '<form id="rqf" class="card form"><h3>📤 ' + T('newDocRequest') + '</h3>' + App.empPickerHtml(emps, { all: false, label: T('employee') }) +
      U.field('title', T('title'), '', { required: true, placeholder: 'e.g. Upload Staff Insurance policy' }) + U.field('category', T('docType'), INS, { type: 'select', options: [INS].concat(BASE_CATS) }) +
      U.field('dueDate', T('dueDate'), '', { type: 'date' }) + U.field('note', T('note'), '', { type: 'textarea', rows: 2 }) + '<button class="btn block">📤 ' + T('sendRequest') + '</button></form>' +
      (reqs.length ? '<div class="card list">' + reqs.map((r) => '<div class="li"><div class="grow"><b>' + esc(r.empName) + ' · ' + esc(r.title) + '</b><small>' + esc(r.category || '') + ' · ' + U.fmtDate(r.at) +
        (r.dueDate ? ' · ' + T('dueDate') + ' ' + U.fmtDate(r.dueDate) : '') + (r.remark ? '<br>' + T('remark') + ': ' + esc(r.remark) : '') + '</small><div class="row-btns left">' +
        (r.docId ? '<button class="btn sm ghost" data-rv="' + esc(r.docId) + '" data-rn="' + esc(r.title) + '">👁 ' + T('view') + '</button>' : '') +
        (r.status === 'submitted' ? '<button class="btn sm" data-ra="' + r.id + '">✔ ' + T('approve') + '</button><button class="btn sm danger" data-rr="' + r.id + '">✕ ' + T('reject') + '</button>' : '') +
        '<button class="btn sm ghost" data-rd="' + r.id + '">🗑</button></div></div><span class="badge ' + ({ open: 'warn', submitted: 'info', approved: 'ok', rejected: 'bad' }[r.status] || 'muted') + '">' + esc(T('rq_' + r.status)) + '</span></div>').join('') + '</div>' : U.empty());
    bindChips();
    const f = U.$('#rqf'); App.bindEmpPicker(f);
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const pick = App.readEmpPicker(f, emps); if (!pick.list.length) return U.toast(T('selectEmployee'), 'err');
      U.loading(true);
      try {
        const gid = 'R' + U.uid();
        for (const e of pick.list) {
          await DB.add('docrequests', { empId: e.id, empName: e.name, title: d.title, category: d.category, dueDate: d.dueDate, note: d.note, status: 'open', at: DB.now(), by: by(), groupId: gid });
          await DB.add('notifications', { target: e.id, targetName: e.name, title: '📤 ' + d.title, body: T('docRequestMsg') + (d.dueDate ? ' ' + T('dueDate') + ': ' + U.fmtDate(d.dueDate) : ''), at: DB.now(), by: by(), groupId: gid });
        }
        U.toast(T('sent') + ' · ' + pick.list.length, 'ok'); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
    U.$$('[data-rv]').forEach((b) => b.onclick = async () => { U.loading(true); try { const x = await Files.get('docfiles', b.dataset.rv); App.viewFile(b.dataset.rn, x && x.data); } finally { U.loading(false); } });
    const review = async (id, ok) => {
      const r = reqs.find((x) => x.id === id);
      const remark = await U.prompt(ok ? T('approve') : T('reject'), T('remarkOptional'), ''); if (remark == null) return;
      await DB.update('docrequests', id, { status: ok ? 'approved' : 'rejected', remark, reviewedAt: DB.now() });
      if (r.docId) await DB.update('documents', r.docId, { status: ok ? 'approved' : 'rejected', remark, reviewedAt: DB.now(), reviewedBy: by() }).catch(() => { });
      await DB.add('notifications', { target: r.empId, targetName: r.empName, title: (ok ? '✅ ' : '❌ ') + r.title, body: remark || (ok ? T('approved') : T('reuploadMsg')), at: DB.now(), by: by() });
      App.refresh();
    };
    U.$$('[data-ra]').forEach((b) => b.onclick = () => review(b.dataset.ra, true));
    U.$$('[data-rr]').forEach((b) => b.onclick = () => review(b.dataset.rr, false));
    U.$$('[data-rd]').forEach((b) => b.onclick = async () => { if (await U.confirm(T('deleteConfirm'), T('delete'))) { await DB.del('docrequests', b.dataset.rd); App.refresh(); } });
  }
})();
