// ---------- Loan module v2: ROI flat/reducing, charges, references, selfie, schedule, ledger, documents ----------
(function () {
  const V = window.Views, esc = U.esc;
  const LN = window.Loan = {};

  // ================= SETTINGS =================
  const OLD_LETTER_MARK = 'Sanctioned Amount: Rs. {amount}';
  LN.defaults = () => ({
    enabled: true, roiType: 'reducing', interest: 12, showRoi: false,
    pfType: 'pct', pfValue: 1, gstPct: 18, docFee: 0, stampDuty: 0,
    penaltyAmt: 200, foreclosePct: 0, emiDay: 5,
    requireSelfie: true, requireRefs: true,
    requireSignedDocs: true, signedDocTypes: ['Signed Sanction Letter', 'Signed DPN', 'Signed Loan Agreement'],
    empView: { roi: false, charges: true, schedule: true, scheduleDetail: false, statement: true, emiCard: true, soa: true, docs: true },
    maxAmount: 50000, maxTenure: 12, minServiceMonths: 6,
    steps: ['Application Review', 'Document Verification', 'Manager Approval', 'Final Approval'],
    customFields: [],
    letterTemplate:
      'Dear {name},\n\nWith reference to your staff loan application, we are pleased to inform you that the management of {showroom} has sanctioned a loan in your favour on the terms and conditions given below.\n\n' +
      'The EMI will be deducted from your monthly salary / paid by you on or before the due date. In case you leave the organisation, the entire outstanding amount shall become payable immediately and may be adjusted against your dues.\n\n' +
      'Please sign the Demand Promissory Note (DPN) and the Loan Agreement and submit them to the office before disbursement.',
    dpnTemplate:
      'On demand, I, {name}, son/daughter of {father}, residing at {address}, Employee ID {empId}, promise to pay {showroom} or order, the sum of Rs. {amount} ({amountWords} Only) together with interest at the rate of ________ % per annum, for value received in cash.',
    terms: '1. EMI will be deducted from monthly salary or paid on due date.\n2. Full balance becomes payable on resignation/termination.\n3. Late payment will attract penalty as decided by management.\n4. Management decision on loan is final.',
    agreementTerms:
      'The Borrower shall repay the loan in equated monthly instalments (EMI) as per the repayment schedule.\n' +
      'The Borrower authorises the Company to deduct the EMI and any dues from salary, incentives, payouts or full & final settlement.\n' +
      'Any delay in payment of EMI shall attract penalty charges as fixed by the Company from time to time.\n' +
      'On resignation, termination or absconding of the Borrower, the entire outstanding amount shall become immediately due and payable.\n' +
      'The Guarantor jointly and severally guarantees repayment of the loan and agrees that the Company may recover the dues from the Guarantor\'s salary or dues if the Borrower fails to pay.\n' +
      'The Borrower may foreclose the loan by paying the outstanding principal along with applicable charges.\n' +
      'Processing fee, GST, documentation charges and stamp duty are non-refundable.\n' +
      'The Borrower has signed a Demand Promissory Note (DPN) in favour of the Company as security for this loan.\n' +
      'All disputes are subject to the jurisdiction of local courts where the Company is situated.'
  });
  LN.empView = () => Object.assign(LN.defaults().empView, (S.loanSettings || {}).empView || {});
  // can the current viewer see this part of a loan?
  LN.can = (k) => S.isAdmin || !!LN.empView()[k];
  LN.settings = function () {
    const s = Object.assign(LN.defaults(), S.loanSettings || {});
    if (String(s.letterTemplate || '').includes(OLD_LETTER_MARK)) s.letterTemplate = LN.defaults().letterTemplate;
    return s;
  };

  // ================= CALCULATIONS =================
  const r2 = U.round2;
  function addMonths(dateKey, k) {
    const [y, m, d] = dateKey.split('-').map(Number);
    const last = new Date(y, m - 1 + k + 1, 0).getDate();
    return U.dateKey(new Date(y, m - 1 + k, Math.min(d, last)));
  }
  LN.defaultFirstEmi = function (fromKey) {
    const st = LN.settings();
    const base = fromKey ? new Date(fromKey + 'T00:00:00') : new Date();
    const dt = new Date(base.getFullYear(), base.getMonth() + 1, Math.min(28, Number(st.emiDay) || 5));
    return U.dateKey(dt);
  };

  // terms object from loan (or a draft of terms)
  LN.terms = function (l) {
    const P = U.num(l.approvedAmount || l.amount);
    const n = Math.max(1, parseInt(l.tenure) || 1);
    const rate = U.num(l.interest);
    const type = l.roiType === 'flat' ? 'flat' : 'reducing';
    const pf = l.pfType === 'fixed' ? r2(U.num(l.pfValue)) : r2(P * U.num(l.pfValue) / 100);
    const gst = r2(pf * U.num(l.gstPct) / 100);
    const doc = r2(U.num(l.docFee)), stamp = r2(U.num(l.stampDuty));
    const charges = r2(pf + gst + doc + stamp);
    const sch = LN.schedule({ P, n, rate, type, first: l.firstEmiDate || LN.defaultFirstEmi(l.disbursedAt) });
    const totalInterest = r2(sch.reduce((s, x) => s + x.interest, 0));
    return { P, n, rate, type, pf, gst, doc, stamp, charges, net: r2(P - charges), emi: sch.length ? sch[0].emi : 0, totalInterest, totalPayable: r2(P + totalInterest), schedule: sch };
  };

  LN.schedule = function ({ P, n, rate, type, first }) {
    const rows = [];
    if (!(P > 0)) return rows;
    if (type === 'flat') {
      const TI = r2(P * rate / 100 * n / 12);
      const emi = r2((P + TI) / n), pp = r2(P / n), ii = r2(TI / n);
      let bal = P, sp = 0, si = 0;
      for (let i = 1; i <= n; i++) {
        let prin = pp, int = ii;
        if (i === n) { prin = r2(P - sp); int = r2(TI - si); }
        sp = r2(sp + prin); si = r2(si + int); bal = r2(bal - prin);
        rows.push({ n: i, due: addMonths(first, i - 1), emi: i === n ? r2(prin + int) : emi, principal: prin, interest: int, balance: Math.max(0, bal) });
      }
    } else {
      const r = rate / 1200;
      const emi = r ? r2(P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1)) : r2(P / n);
      let bal = P;
      for (let i = 1; i <= n; i++) {
        const int = r2(bal * r);
        let prin = r2(emi - int);
        if (i === n) prin = bal;
        bal = r2(bal - prin);
        rows.push({ n: i, due: addMonths(first, i - 1), emi: r2(prin + int), principal: prin, interest: int, balance: Math.max(0, bal) });
      }
    }
    return rows;
  };

  LN.ledgerRows = function (l) {
    let bal = 0;
    return (l.ledger || []).slice().sort((a, b) => String(a.date).localeCompare(String(b.date)) || (a.at || 0) - (b.at || 0)).map((e) => {
      bal = r2(bal + U.num(e.debit) - U.num(e.credit));
      return Object.assign({}, e, { balance: bal });
    });
  };
  LN.outstanding = (l) => r2((l.ledger || []).reduce((s, e) => s + U.num(e.debit) - U.num(e.credit), 0));

  // schedule with paid status (EMI receipts allocated in order)
  LN.scheduleStatus = function (l) {
    const t = LN.terms(l);
    let paid = (l.ledger || []).filter((e) => e.type === 'emi').reduce((s, e) => s + U.num(e.credit), 0);
    const today = U.dateKey();
    return t.schedule.map((row) => {
      const take = Math.min(paid, row.emi); paid = r2(paid - take);
      const status = take >= row.emi - 0.5 ? 'paid' : take > 0 ? 'partial' : row.due < today ? 'overdue' : 'due';
      return Object.assign({}, row, { paidAmt: r2(take), status });
    });
  };
  LN.overdueCount = (l) => l.status === 'disbursed' ? LN.scheduleStatus(l).filter((x) => x.status === 'overdue' || (x.status === 'partial' && x.due < U.dateKey())).length : 0;

  LN.roiText = (t) => t.rate + '% p.a. (' + (t.type === 'flat' ? 'Flat' : 'Reducing') + ')';
  LN.isRunning = (l) => ['approved', 'disbursed'].includes(l.status);

  // ================= SHARED UI =================
  const kv = (k, v) => window.kvRow(k, v);
  const STAT = { applied: 'warn', in_process: 'info', approved: 'info', disbursed: 'ok', closed: 'muted', rejected: 'bad' };
  const badge = (s) => '<span class="badge ' + (STAT[s] || 'muted') + '">' + esc(T('ls_' + s)) + '</span>';

  function chargesHtml(t, showRoi) {
    return '<div class="kv">' + kv(T('loanAmount'), U.money(t.P)) + kv(T('tenure'), t.n + ' ' + T('months')) +
      (showRoi ? kv(T('roi'), esc(LN.roiText(t))) : '') + kv('EMI', '<b>' + U.money(t.emi) + '</b>') +
      kv(T('processingFee'), U.money(t.pf)) + kv(T('gstOnPf'), U.money(t.gst)) + kv(T('docFee'), U.money(t.doc)) + kv(T('stampDuty'), U.money(t.stamp)) +
      kv(T('totalCharges'), U.money(t.charges)) + '</div><div class="net-box">💰 ' + T('netToAccount') + ': <b>' + U.money(t.net) + '</b></div>' +
      (showRoi ? '<small class="muted">' + T('totalPayable') + ': ' + U.money(t.totalPayable) + ' (' + T('interest') + ' ' + U.money(t.totalInterest) + ')</small>' : '');
  }
  LN.chargesHtml = chargesHtml;

  function scheduleHtml(l) {
    const rows = LN.isRunning(l) || l.status === 'closed' ? LN.scheduleStatus(l) : LN.terms(l).schedule.map((x) => Object.assign({ status: 'due', paidAmt: 0 }, x));
    const SB = { paid: 'ok', partial: 'info', overdue: 'bad', due: 'muted' };
    if (!LN.can('scheduleDetail')) return '<div class="table-wrap"><table class="tbl"><thead><tr><th>#</th><th>' + T('dueDate') + '</th><th>EMI</th><th>' + T('status') + '</th></tr></thead><tbody>' +
      rows.map((x) => '<tr><td>' + x.n + '</td><td>' + U.fmtDate(x.due) + '</td><td><b>' + U.money(x.emi) + '</b></td><td><span class="badge ' + SB[x.status] + '">' + T('emi_' + x.status) + '</span></td></tr>').join('') + '</tbody></table></div>';
    return '<div class="table-wrap"><table class="tbl"><thead><tr><th>#</th><th>' + T('dueDate') + '</th><th>EMI</th><th>' + T('principal') + '</th><th>' + T('interest') + '</th><th>' + T('balance') + '</th><th>' + T('status') + '</th></tr></thead><tbody>' +
      rows.map((x) => '<tr><td>' + x.n + '</td><td>' + U.fmtDate(x.due) + '</td><td>' + U.money(x.emi) + '</td><td>' + U.money(x.principal) + '</td><td>' + U.money(x.interest) + '</td><td>' + U.money(x.balance) +
        '</td><td><span class="badge ' + SB[x.status] + '">' + T('emi_' + x.status) + '</span></td></tr>').join('') + '</tbody></table></div>';
  }
  function statementHtml(l) {
    const rows = LN.ledgerRows(l);
    if (!rows.length) return U.empty(T('noStatement'));
    return '<div class="table-wrap"><table class="tbl"><thead><tr><th>' + T('date') + '</th><th>' + T('particulars') + '</th><th>' + T('debit') + '</th><th>' + T('credit') + '</th><th>' + T('balance') + '</th></tr></thead><tbody>' +
      rows.map((e) => '<tr><td>' + U.fmtDate(e.date) + '</td><td>' + esc(T('lt_' + e.type)) + (e.note ? '<br><small class="muted">' + esc(e.note) + '</small>' : '') + (e.mode ? '<br><small class="muted">' + esc(e.mode) + (e.ref ? ' · ' + esc(e.ref) : '') + '</small>' : '') +
        '</td><td>' + (U.num(e.debit) ? U.money(e.debit) : '') + '</td><td>' + (U.num(e.credit) ? U.money(e.credit) : '') + '</td><td><b>' + U.money(e.balance) + '</b></td></tr>').join('') +
      '</tbody></table></div><div class="net-box">' + T('outstanding') + ': <b>' + U.money(LN.outstanding(l)) + '</b></div>';
  }
  function refsHtml(l, guarantorFull) {
    const r1 = l.ref1 || {}, g = Object.assign({}, guarantorFull || {}, l.guarantor || {});
    return '<div class="kv">' + kv(T('reference1'), esc(r1.name || '-') + (r1.relation ? ' (' + esc(r1.relation) + ')' : '')) + kv(T('mobile'), esc(r1.mobile || '-')) + kv(T('address'), esc(r1.address || '-')) +
      '</div><h4>' + T('guarantor') + '</h4><div class="kv">' + kv(T('name'), esc((g.name || '-') + (g.empId ? ' · ' + g.empId : ''))) + kv(T('designation'), esc(g.designation || '-')) +
      (g.fatherName ? kv(T('fatherName'), esc(g.fatherName)) : '') + (g.mobile ? kv(T('mobile'), esc(g.mobile)) : '') + (g.address ? kv(T('address'), esc(g.address)) : '') + '</div>';
  }
  LN.refsHtml = refsHtml;
  function docsButtons(l) {
    if (!['approved', 'disbursed', 'closed'].includes(l.status)) return '<p class="muted small">' + T('docsAfterSanction') + '</p>';
    const run = ['disbursed', 'closed'].includes(l.status);
    const b = [];
    if (LN.can('docs')) b.push('<button class="btn sm" data-doc="sanction">📄 ' + T('sanctionLetter') + '</button>', '<button class="btn sm" data-doc="dpn">📝 DPN</button>', '<button class="btn sm" data-doc="agreement">📑 ' + T('loanAgreement') + '</button>');
    if (LN.can('emiCard')) b.push('<button class="btn sm ghost" data-doc="emicard">💳 ' + T('emiCard') + '</button>');
    if (run && LN.can('soa')) b.push('<button class="btn sm ghost" data-doc="soa">📘 ' + T('soa') + '</button>');
    if (run && LN.can('statement') && l.ledger && l.ledger.length) b.push('<button class="btn sm ghost" data-doc="statement">📊 ' + T('statementPdf') + '</button>');
    return b.length ? '<div class="row-btns left">' + b.join('') + '</div>' : U.empty(T('noRight'));
  }
  function bindDocs(root, l) {
    U.$$('[data-doc]', root).forEach((b) => b.onclick = () => {
      const d = b.dataset.doc;
      if (d === 'sanction') PDF.showLoanLetter(l); else if (d === 'dpn') PDF.showDPN(l); else if (d === 'agreement') PDF.showAgreement(l);
      else if (d === 'emicard') PDF.emiCardPdf(l); else if (d === 'soa') PDF.soaPdf(l); else PDF.loanStatementPdf(l);
    });
  }

  // ================= EMPLOYEE =================
  V.empLoan = async function (el) {
    const ls = LN.settings(), e = S.emp;
    const loans = (await DB.query('loans', [['empId', '==', S.user.empId]])).sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    const eligible = ls.enabled && App.can('applyLoan') && e.loanEligible;
    const active = loans.find((l) => ['applied', 'in_process', 'approved', 'disbursed'].includes(l.status));
    el.innerHTML = '<h2 class="page-title">' + T('loan') + '</h2>' +
      (eligible ? (active ? '<div class="note">' + T('loanActiveExists') + '</div>' :
        '<div class="card loan-cta"><div><b>' + T('needLoan') + '</b><small>' + T('maxEligible') + ': ' + U.money(maxLoan()) + ' · ' + T('upTo') + ' ' + ls.maxTenure + ' ' + T('months') +
        '</small></div><button class="btn" onclick="App.go(\'empLoanApply\')">' + T('applyLoan') + '</button></div>') : '<div class="note">' + T('notEligibleLoan') + '</div>') +
      '<h3 class="sec-title">' + T('myLoans') + '</h3>' +
      (loans.length ? loans.map((l) => loanCard(l, false)).join('') : U.empty(T('noLoans')));
    U.$$('[data-loan]').forEach((c) => c.onclick = () => App.go('empLoanDetail', { id: c.dataset.loan }));
  };
  function maxLoan() {
    const a = U.num(S.emp.maxLoanAmount), b = U.num(LN.settings().maxAmount);
    return a && b ? Math.min(a, b) : (a || b);
  }
  function loanCard(l, admin) {
    const t = LN.terms(l), od = LN.overdueCount(l);
    return '<div class="card loan-card" data-loan="' + esc(l.id) + '"><div class="row-between"><div><b>' + (admin ? esc(l.empName) + ' · ' : '') + U.money(t.P) + '</b><small class="muted"> · ' + t.n + ' ' + T('months') + ' · EMI ' + U.money(t.emi) +
      '</small><br><small class="muted">' + (l.partnerName ? '🏦 ' + esc(l.partnerName) + ' · ' : '') + (l.loanNo ? esc(l.loanNo) + ' · ' : '') + T('appliedOn') + ' ' + U.fmtDate(l.createdAt) + '</small></div><div class="right">' + badge(l.status) +
      (od ? '<br><span class="badge bad">' + od + ' ' + T('overdueEmi') + '</span>' : '') + '</div></div>' +
      (l.status === 'disbursed' ? '<div class="small">' + T('outstanding') + ': <b>' + U.money(LN.outstanding(l)) + '</b></div>' : '') +
      (['applied', 'in_process'].includes(l.status) ? window.loanStepper(l) : '') + '</div>';
  }
  LN.loanCard = loanCard;

  V.empLoanDetail = async function (el, p) {
    const l = await DB.get('loans', p.id);
    if (!l || l.empId !== S.user.empId) { el.innerHTML = U.empty(); return; }
    const tab = p.tab || 'summary';
    const ls = LN.settings(), t = LN.terms(l);
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'empLoan\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><div class="row-between"><h2>' + U.money(t.P) + '</h2>' + badge(l.status) + '</div><small class="muted">' + (l.loanNo ? esc(l.loanNo) + ' · ' : '') + T('appliedOn') + ' ' + U.fmtDate(l.createdAt) + '</small>' +
      window.loanStepper(l) + '</div>' + tabsHtml(tab, l, false) + '<div id="ltb"></div>';
    bindTabs('empLoanDetail', l.id);
    const tb = U.$('#ltb');
    if (tab === 'summary') {
      tb.innerHTML = '<div class="card"><h3>' + T('loanTerms') + '</h3>' + (l.partnerName ? '<div class="kv">' + kv(T('lender'), '🏦 ' + esc(l.partnerName)) + '</div>' : '') +
        (LN.can('charges') ? chargesHtml(t, LN.can('roi') || ls.showRoi) : '<div class="kv">' + kv(T('loanAmount'), U.money(t.P)) + kv(T('tenure'), t.n + ' ' + T('months')) + kv('EMI', '<b>' + U.money(t.emi) + '</b>') + '</div>') +
        (l.status === 'disbursed' || l.status === 'closed' ? '<div class="kv">' + kv(T('disbursedOn'), U.fmtDate(l.disbursedAt)) + kv(T('mode'), esc((l.disburseMode || '') + (l.disburseRef ? ' · ' + l.disburseRef : ''))) + kv(T('outstanding'), '<b>' + U.money(LN.outstanding(l)) + '</b>') + '</div>' : '') +
        '</div><div class="card"><h3>' + T('references') + '</h3>' + refsHtml(l) + '</div>' +
        '<div class="card"><h3>' + T('timeline') + '</h3>' + timelineHtml(l) + '</div>';
    } else if (tab === 'schedule') tb.innerHTML = '<div class="card">' + scheduleHtml(l) + '</div>';
    else if (tab === 'statement') tb.innerHTML = '<div class="card">' + statementHtml(l) + '</div>';
    else if (tab === 'signed') await LN.signedDocs(tb, l);
    else { tb.innerHTML = '<div class="card">' + docsButtons(l) + '</div>'; bindDocs(tb, l); }
  };
  function tabsHtml(tab, l, admin) {
    const list = [['summary', T('summary')]];
    if (admin || LN.can('schedule')) list.push(['schedule', T('emiSchedule')]);
    if (admin || LN.can('statement')) list.push(['statement', T('statement')]);
    if (l && ['approved', 'disbursed', 'closed'].includes(l.status)) list.push(['signed', '✍️ ' + T('signedDocs')]);
    list.push(['docs', T('documents')]);
    return '<div class="tabs">' + list.map((x) => '<button class="' + (x[0] === tab ? 'on' : '') + '" data-ltab="' + x[0] + '">' + x[1] + '</button>').join('') + '</div>';
  }
  function bindTabs(view, id) { U.$$('[data-ltab]').forEach((b) => b.onclick = () => App.go(view, { id, tab: b.dataset.ltab })); }
  function timelineHtml(l) {
    return '<div class="timeline">' + (l.history || []).slice().reverse().map((h) => '<div><b>' + esc(h.step) + '</b> — ' + esc(T('st_' + h.status) !== 'st_' + h.status ? T('st_' + h.status) : h.status) +
      '<small class="muted"> · ' + esc(h.by || '') + ' · ' + U.fmtDT(h.at) + '</small>' + (h.note ? '<br><small>' + esc(h.note) + '</small>' : '') + '</div>').join('') + '</div>';
  }

  // ---------- live selfie with GPS ----------
  LN.liveSelfie = function () {
    return new Promise(async (resolve) => {
      let loc = null;
      U.loading(true, T('gettingLocation'));
      try { loc = await U.getLocation(); } catch (e) { U.loading(false); U.toast(e.message, 'err'); return resolve(null); }
      U.loading(false);
      const stamp = (ctx, w, h) => {
        const lines = [U.fmtDT(new Date()), 'Lat ' + loc.lat.toFixed(6) + ', Lng ' + loc.lng.toFixed(6) + ' (±' + loc.acc + 'm)', (S.emp ? S.emp.name + ' · ' + S.emp.id : '')];
        const fs = Math.max(14, Math.round(w / 32));
        ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(0, h - fs * 4.2, w, fs * 4.2);
        ctx.fillStyle = '#fff'; ctx.font = 'bold ' + fs + 'px sans-serif';
        lines.forEach((t, i) => ctx.fillText(t, fs * 0.6, h - fs * 4.2 + fs * 1.25 * (i + 1)));
      };
      const finish = (canvas) => resolve({ data: canvas.toDataURL('image/jpeg', 0.72), lat: loc.lat, lng: loc.lng, acc: loc.acc, at: Date.now() });
      let stream = null;
      try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 } }, audio: false }); } catch (e) { stream = null; }
      if (!stream) {
        // fallback: camera through file input
        const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.setAttribute('capture', 'user');
        inp.onchange = async () => {
          const f = inp.files[0]; if (!f) return resolve(null);
          const url = await U.compressImage(f, 720, 0.85); const img = new Image();
          img.onload = () => { const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0); stamp(ctx, c.width, c.height); finish(c); };
          img.src = url;
        };
        inp.click(); return;
      }
      const m = U.modal('📸 ' + T('liveSelfie'), '<div class="cam"><video autoplay playsinline muted></video></div><p class="muted small center">' + T('selfieHint') + '</p><button class="btn block" data-snap>📸 ' + T('capture') + '</button>',
        { sticky: true, onClose: () => { stream.getTracks().forEach((t) => t.stop()); resolve(null); } });
      const video = m.el.querySelector('video'); video.srcObject = stream;
      m.el.querySelector('[data-snap]').onclick = () => {
        const w = video.videoWidth || 640, h = video.videoHeight || 480;
        const c = document.createElement('canvas'); c.width = w; c.height = h; const ctx = c.getContext('2d');
        ctx.translate(w, 0); ctx.scale(-1, 1); ctx.drawImage(video, 0, 0, w, h); ctx.setTransform(1, 0, 0, 1, 0, 0);
        stamp(ctx, w, h);
        stream.getTracks().forEach((t) => t.stop());
        m.el.remove(); finish(c);
      };
    });
  };

  V.empLoanApply = async function (el) {
    const e = S.emp, ls = LN.settings();
    if (!(ls.enabled && App.can('applyLoan') && e.loanEligible)) { el.innerHTML = '<div class="note">' + T('notEligibleLoan') + '</div>'; return; }
    const basic = [['name', T('fullName')], ['id', T('employeeId')], ['fatherName', T('fatherName')], ['dob', T('dob'), 'date'], ['mobile', T('mobile'), 'tel'], ['address', T('address')],
    ['designation', T('designation')], ['joinDate', T('joinDate'), 'date'], ['aadhaar', T('aadhaar')], ['pan', T('pan')], ['bankName', T('bankName')], ['accountNo', T('accountNo')], ['ifsc', 'IFSC']];
    const max = maxLoan();
    let selfie = null, guarantor = null;
    el.innerHTML = '<h2 class="page-title">' + T('loanApplication') + '</h2><form id="lf" class="form">' +
      '<div class="card"><h3>1. ' + T('basicDetails') + '</h3><p class="muted small">' + T('autoFillNote') + '</p>' +
      basic.map((b) => U.field('b_' + b[0], b[1], e[b[0]], { type: b[2], readonly: !!e[b[0]], auto: !!e[b[0]], required: true })).join('') + '</div>' +
      '<div class="card"><h3>2. ' + T('loanDetails') + '</h3>' +
      U.field('amount', T('loanAmount') + ' (max ' + U.money(max) + ')', '', { type: 'number', required: true, min: 1 }) +
      U.field('tenure', T('tenureMonths'), Math.min(6, ls.maxTenure), { type: 'select', options: Array.from({ length: ls.maxTenure }, (_, i) => i + 1) }) +
      U.field('purpose', T('purpose'), '', { type: 'textarea', required: true }) +
      (ls.customFields || []).map((f) => U.field('c_' + f.key, f.label, '', { type: f.type === 'textarea' ? 'textarea' : f.type, required: !!f.required })).join('') +
      '<div id="est"></div></div>' +
      '<div class="card"><h3>3. ' + T('references') + '</h3><p class="muted small">' + T('refNote') + '</p><b>' + T('reference1') + '</b>' +
      '<div class="grid2f">' + U.field('r1_name', T('name'), '', { required: !!ls.requireRefs }) + U.field('r1_relation', T('relation'), '', { placeholder: 'Father / Friend', required: !!ls.requireRefs }) +
      U.field('r1_mobile', T('mobile'), '', { type: 'tel', required: !!ls.requireRefs }) + '</div>' + U.field('r1_address', T('address'), '', { required: !!ls.requireRefs }) +
      '<b>' + T('reference2Guarantor') + '</b><div class="row"><input id="gcode" class="search grow" placeholder="' + T('employeeCodeEg') + '" style="margin:0"><button type="button" class="btn sm" id="gfetch">' + T('fetch') + '</button></div>' +
      '<div id="ginfo" class="small muted" style="margin-top:8px">' + T('guarantorNote') + '</div></div>' +
      '<div class="card"><h3>4. ' + T('liveSelfie') + (ls.requireSelfie ? ' *' : '') + '</h3><p class="muted small">' + T('selfieNote') + '</p><div id="sbox"></div>' +
      '<button type="button" class="btn ghost" id="snap">📸 ' + T('takeSelfie') + '</button></div>' +
      '<div class="card">' + (ls.terms ? '<div class="terms">' + esc(ls.terms).replace(/\n/g, '<br>') + '</div>' : '') + U.field('agree', T('declaration'), false, { type: 'checkbox' }) + '</div>' +
      '<button class="btn block">' + T('submitApplication') + '</button></form>';
    const f = U.$('#lf');
    const est = () => {
      const d = U.formData(f);
      const t = LN.terms({ amount: d.amount, tenure: d.tenure, interest: ls.interest, roiType: ls.roiType, pfType: ls.pfType, pfValue: ls.pfValue, gstPct: ls.gstPct, docFee: ls.docFee, stampDuty: ls.stampDuty });
      U.$('#est').innerHTML = t.P > 0 ? '<div class="est-box"><b>' + T('estimate') + '</b>' + chargesHtml(t, ls.showRoi) + '<small class="muted">' + T('estimateNote') + '</small></div>' : '';
    };
    f.oninput = (ev) => { if (ev.target.name === 'amount' || ev.target.name === 'tenure') est(); };
    f.onchange = est; est();
    U.$('#gfetch').onclick = async () => {
      const code = U.$('#gcode').value.trim().toUpperCase();
      guarantor = null;
      if (!code) return;
      if (code === S.user.empId) { U.$('#ginfo').innerHTML = '<span class="low">' + T('guarantorSelf') + '</span>'; return; }
      try {
        let d = null;
        try { d = await DB.get('gprofile', code); } catch (e) { d = null; }
        if (!d) { const dd = await DB.get('directory', code); if (dd) d = Object.assign({ empId: code }, dd); }
        if (!d || d.active === false) { U.$('#ginfo').innerHTML = '<span class="low">' + T('guarantorNotFound') + '</span>'; return; }
        const keys = ['name', 'fatherName', 'motherName', 'designation', 'department', 'mobile', 'altMobile', 'address', 'dob', 'joinDate', 'aadhaar', 'pan'];
        guarantor = { empId: code }; keys.forEach((k) => { guarantor[k] = d[k] || ''; });
        U.$('#ginfo').innerHTML = '<div class="g-card"><div class="row">' + App.empAvatar({ name: d.name, photo: d.photo }, 54) + '<div><b>✔ ' + esc(d.name) + '</b><br><small>' + esc(d.designation || '') + ' · ' + esc(code) + '</small></div></div>' +
          '<div class="kv small">' + [['fatherName', 'fatherName'], ['motherName', 'motherName'], ['mobile', 'mobile'], ['address', 'address'], ['dob', 'dob'], ['joinDate', 'joinDate'], ['aadhaar', 'aadhaar'], ['pan', 'pan']]
            .filter((x) => d[x[0]]).map((x) => kv(T(x[1]), esc(/date|dob/i.test(x[0]) ? U.fmtDate(d[x[0]]) : d[x[0]]))).join('') + '</div><small>' + T('guarantorAuto') + '</small></div>';
      } catch (err) { U.$('#ginfo').textContent = err.message; }
    };
    U.$('#snap').onclick = async () => {
      const s = await LN.liveSelfie();
      if (s) { selfie = s; U.$('#sbox').innerHTML = '<img src="' + s.data + '" class="selfie-prev"><small class="muted">📍 ' + s.lat.toFixed(5) + ', ' + s.lng.toFixed(5) + ' · ' + U.fmtDT(s.at) + '</small>'; U.$('#snap').textContent = '📸 ' + T('retake'); }
    };
    f.onsubmit = async (ev) => {
      ev.preventDefault();
      const d = U.formData(f);
      if (!d.agree) return U.toast(T('acceptDeclaration'), 'err');
      if (!(d.amount > 0)) return U.toast(T('enterAmount'), 'err');
      if (max && d.amount > max) return U.toast(T('amountExceeds') + ' ' + U.money(max), 'err');
      if (ls.requireRefs && !guarantor) return U.toast(T('guarantorRequired'), 'err');
      if (ls.requireRefs && String(d.r1_mobile).replace(/\D/g, '').length < 10) return U.toast(T('invalidMobile'), 'err');
      if (ls.requireSelfie && !selfie) return U.toast(T('selfieRequired'), 'err');
      const applicant = {}; basic.forEach((b) => { applicant[b[0]] = d['b_' + b[0]] || ''; });
      const custom = {}; (ls.customFields || []).forEach((cf) => { custom[cf.key] = { label: cf.label, value: d['c_' + cf.key] || '' }; });
      const id = 'L' + Date.now().toString(36).toUpperCase();
      const draft = { amount: Number(d.amount), tenure: Number(d.tenure), interest: U.num(ls.interest), roiType: ls.roiType, pfType: ls.pfType, pfValue: U.num(ls.pfValue), gstPct: U.num(ls.gstPct), docFee: U.num(ls.docFee), stampDuty: U.num(ls.stampDuty) };
      U.loading(true);
      try {
        await DB.set('loans', id, Object.assign(draft, {
          empId: S.user.empId, empName: e.name, applicant, custom, purpose: d.purpose, emi: LN.terms(draft).emi,
          ref1: { name: d.r1_name, relation: d.r1_relation, mobile: d.r1_mobile, address: d.r1_address }, guarantor: guarantor || null,
          selfieGps: selfie ? { lat: selfie.lat, lng: selfie.lng, acc: selfie.acc, at: selfie.at } : null,
          steps: (ls.steps || []).slice(), step: 0, status: 'applied', ledger: [],
          history: [{ step: T('applied'), status: 'applied', at: Date.now(), by: e.name }], createdAt: DB.now(), month: U.monthKey()
        }));
        if (selfie) await DB.set('loanfiles', id, { empId: S.user.empId, selfie: selfie.data, lat: selfie.lat, lng: selfie.lng, acc: selfie.acc, at: selfie.at });
        U.toast(T('loanSubmitted'), 'ok'); App.go('empLoanDetail', { id });
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
  };

  // ================= ADMIN =================
  V.adminLoans = async function (el, p) {
    const filter = p.filter || 'all';
    const loans = (await DB.all('loans')).sort((a, b) => (U.toDate(b.createdAt) || 0) - (U.toDate(a.createdAt) || 0));
    const groups = {
      active: (l) => ['applied', 'in_process'].includes(l.status), approved: (l) => l.status === 'approved', disbursed: (l) => l.status === 'disbursed',
      overdue: (l) => LN.overdueCount(l) > 0, closed: (l) => l.status === 'closed' || l.closed, rejected: (l) => l.status === 'rejected', all: () => true
    };
    const run = loans.filter((l) => l.status === 'disbursed');
    const out = r2(run.reduce((s, l) => s + LN.outstanding(l), 0));
    const disb = r2(loans.filter((l) => ['disbursed', 'closed'].includes(l.status)).reduce((s, l) => s + LN.terms(l).P, 0));
    const od = run.reduce((s, l) => s + LN.overdueCount(l), 0);
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('loans') + '</h2><button class="btn ghost sm" onclick="App.go(\'adminLoanSettings\')">⚙️ ' + T('loanSettings') + '</button></div>' +
      '<div class="stats4"><div><b>' + run.length + '</b><small>' + T('runningLoans') + '</small></div><div><b>' + U.money(out) + '</b><small>' + T('outstanding') + '</small></div><div><b>' + U.money(disb) +
      '</b><small>' + T('totalDisbursed') + '</small></div><div><b class="' + (od ? 'low' : '') + '">' + od + '</b><small>' + T('overdueEmi') + '</small></div></div>' +
      '<div class="chips">' + Object.keys(groups).map((f) => '<button class="chip' + (f === filter ? ' on' : '') + '" data-f="' + f + '">' + T('lf_' + f) + ' (' + loans.filter(groups[f]).length + ')</button>').join('') +
      '<button class="chip" onclick="App.go(\'adminRights\')">🔐 ' + T('eligibility') + '</button></div>' +
      (loans.filter(groups[filter]).map((l) => loanCard(l, true)).join('') || U.empty(T('noLoans')));
    U.$$('[data-f]').forEach((b) => b.onclick = () => App.go('adminLoans', { filter: b.dataset.f }));
    U.$$('[data-loan]').forEach((c) => c.onclick = () => App.go('adminLoanDetail', { id: c.dataset.loan }));
  };

  async function nextLoanNo() {
    const y = new Date().getFullYear();
    const n = (await DB.all('loans')).filter((x) => x.loanNo && x.loanNo.includes('/' + y + '/')).length + 1;
    return 'MA/LN/' + y + '/' + String(n).padStart(3, '0');
  }
  const by = () => S.user.name || 'Admin';
  const notify = (empId, empName, title, body) => DB.add('notifications', { target: empId, targetName: empName, title, body, at: DB.now(), by: by() });

  V.adminLoanDetail = async function (el, p) {
    const l = await DB.get('loans', p.id);
    if (!l) { el.innerHTML = U.empty(); return; }
    const tab = p.tab || 'summary';
    const ls = LN.settings(), t = LN.terms(l);
    const open = ['applied', 'in_process'].includes(l.status);
    if (open) LN._partners = await LN.loadPartners();
    el.innerHTML = '<button class="btn ghost sm" onclick="App.go(\'adminLoans\')">‹ ' + T('back') + '</button>' +
      '<div class="card"><div class="row-between"><div><h2>' + esc(l.empName) + '</h2><small class="muted">' + esc(l.empId) + (l.loanNo ? ' · ' + esc(l.loanNo) : '') + '</small></div>' + badge(l.status) + '</div>' +
      window.loanStepper(l) + actionsHtml(l) + '</div>' + tabsHtml(tab, l, true) + '<div id="ltb"></div>';
    bindTabs('adminLoanDetail', l.id);
    bindActions(l);
    const tb = U.$('#ltb');
    if (tab === 'summary') {
      const [g, file] = await Promise.all([l.guarantor && l.guarantor.empId ? DB.get('employees', l.guarantor.empId).catch(() => null) : null, DB.get('loanfiles', l.id).catch(() => null)]);
      const ap = l.applicant || {};
      tb.innerHTML = (open ? sanctionForm(l, ls) : '') +
        '<div class="card"><h3>' + T('loanTerms') + '</h3>' + '<div class="kv">' + kv(T('lender'), l.partnerName ? '🏦 ' + esc(l.partnerName) : esc(PDF.company().name) + ' (' + T('self') + ')') + '</div>' + chargesHtml(t, true) + '<div class="kv">' + kv(T('purpose'), esc(l.purpose || '-')) + '</div>' +
        (l.disbursedAt ? '<div class="kv">' + kv(T('disbursedOn'), U.fmtDate(l.disbursedAt)) + kv(T('mode'), esc((l.disburseMode || '') + (l.disburseRef ? ' · ' + l.disburseRef : ''))) + kv(T('firstEmi'), U.fmtDate(l.firstEmiDate)) + kv(T('outstanding'), '<b>' + U.money(LN.outstanding(l)) + '</b>') + '</div>' : '') + '</div>' +
        '<div class="card"><h3>📸 ' + T('liveSelfie') + '</h3>' + (file ? '<img src="' + file.selfie + '" class="selfie-prev"><div class="small">📍 ' + U.num(file.lat).toFixed(6) + ', ' + U.num(file.lng).toFixed(6) + ' (±' + file.acc + 'm) · ' + U.fmtDT(file.at) +
          (S.settings.lat != null ? ' · ' + T('distanceFromShowroom') + ' ' + U.distance(file.lat, file.lng, S.settings.lat, S.settings.lng) + 'm' : '') + '</div><a href="https://maps.google.com/?q=' + file.lat + ',' + file.lng + '" target="_blank" rel="noopener">🗺️ ' + T('openMap') + '</a>' : U.empty(T('noSelfie'))) + '</div>' +
        '<div class="card"><h3>' + T('references') + '</h3>' + refsHtml(l, g) + '</div>' +
        '<div class="card"><h3>' + T('applicantDetails') + '</h3><div class="kv">' + Object.keys(ap).map((k) => kv(T(k === 'id' ? 'employeeId' : k === 'ifsc' ? 'IFSC' : k === 'name' ? 'fullName' : k), esc(ap[k] || '-'))).join('') +
        Object.keys(l.custom || {}).map((k) => kv(l.custom[k].label, esc(l.custom[k].value || '-'))).join('') + '</div></div>' +
        '<div class="card"><h3>' + T('timeline') + '</h3>' + timelineHtml(l) + '</div>';
      if (open) bindSanction(l, ls);
    } else if (tab === 'schedule') tb.innerHTML = '<div class="card">' + scheduleHtml(l) + '</div>';
    else if (tab === 'statement') {
      tb.innerHTML = (l.status === 'disbursed' ? '<div class="row-btns left"><button class="btn sm" id="addE">+ ' + T('addLedgerEntry') + '</button><button class="btn sm ghost" id="emiQ">💵 ' + T('receiveEmi') + '</button></div>' : '') +
        '<div class="card">' + statementHtml(l) + '</div>';
      const a = U.$('#addE'); if (a) a.onclick = () => ledgerEntry(l, 'penalty');
      const q = U.$('#emiQ'); if (q) q.onclick = () => ledgerEntry(l, 'emi');
    } else if (tab === 'signed') await LN.signedDocs(tb, l);
    else { tb.innerHTML = '<div class="card">' + docsButtons(l) + '</div>'; bindDocs(tb, l); }
  };

  function actionsHtml(l) {
    const b = [];
    if (['applied', 'in_process'].includes(l.status)) b.push('<button class="btn sm danger" data-act="reject">✕ ' + T('reject') + '</button>');
    if (l.status === 'approved') b.push('<button class="btn sm" data-act="disburse">💸 ' + T('disburse') + '</button>', '<button class="btn sm ghost" data-act="cancel">' + T('cancelSanction') + '</button>');
    if (l.status === 'disbursed') b.push('<button class="btn sm" data-act="emi">💵 ' + T('receiveEmi') + '</button>', '<button class="btn sm ghost" data-act="entry">+ ' + T('penaltyCharge') + '</button>',
      '<button class="btn sm ghost" data-act="foreclose">🔚 ' + T('foreclose') + '</button>', '<button class="btn sm ghost" data-act="close">🔒 ' + T('closeLoan') + '</button>');
    return b.length ? '<div class="row-btns left">' + b.join('') + '</div>' : '';
  }
  function bindActions(l) {
    U.$$('[data-act]').forEach((b) => b.onclick = () => {
      const a = b.dataset.act;
      if (a === 'reject') rejectLoan(l); else if (a === 'disburse') disburse(l); else if (a === 'cancel') cancelSanction(l);
      else if (a === 'emi') ledgerEntry(l, 'emi'); else if (a === 'entry') ledgerEntry(l, 'penalty'); else if (a === 'foreclose') foreclose(l); else closeLoan(l);
    });
  }

  function sanctionForm(l, ls) {
    const steps = l.steps || [], last = l.step >= steps.length - 1;
    const v = (k, d) => (l[k] !== undefined && l[k] !== null && l[k] !== '' ? l[k] : d);
    const partners = (LN._partners || []).filter((x) => x.active !== false);
    return '<div class="card action-card"><h3>' + T('currentStep') + ': ' + esc(steps[l.step] || '') + ' (' + (l.step + 1) + '/' + steps.length + ')</h3><form class="form" id="sf">' +
      U.field('partnerId', '🏦 ' + T('lender'), l.partnerId || '', { type: 'select', options: [{ v: '', l: PDF.company().name + ' (' + T('self') + ')' }].concat(partners.map((x) => ({ v: x.id, l: x.name }))) }) +
      '<div class="grid2f">' + U.field('approvedAmount', T('amountApproved'), v('approvedAmount', l.amount), { type: 'number' }) + U.field('tenure', T('tenureMonths'), l.tenure, { type: 'number', min: 1 }) +
      U.field('roiType', T('roiType'), v('roiType', ls.roiType), { type: 'select', options: [{ v: 'reducing', l: T('reducing') }, { v: 'flat', l: T('flat') }] }) +
      U.field('interest', T('roi') + ' % p.a.', v('interest', ls.interest), { type: 'number', step: '0.01' }) +
      U.field('pfType', T('processingFee'), v('pfType', ls.pfType), { type: 'select', options: [{ v: 'pct', l: '% ' + T('ofLoan') }, { v: 'fixed', l: '₹ ' + T('fixed') }] }) +
      U.field('pfValue', T('processingFee') + ' (%/₹)', v('pfValue', ls.pfValue), { type: 'number', step: '0.01' }) +
      U.field('gstPct', T('gstOnPf') + ' %', v('gstPct', ls.gstPct), { type: 'number', step: '0.01' }) + U.field('docFee', T('docFee') + ' ₹', v('docFee', ls.docFee), { type: 'number' }) +
      U.field('stampDuty', T('stampDuty') + ' ₹', v('stampDuty', ls.stampDuty), { type: 'number' }) + '</div>' +
      '<div id="sprev"></div>' + U.field('note', T('remarks'), '', { type: 'textarea', rows: 2 }) +
      '<div class="row-btns"><button class="btn">✔ ' + (last ? T('finalSanction') : T('approveStep')) + '</button></div></form></div>';
  }
  function readTerms(f) {
    const d = U.formData(f);
    return {
      approvedAmount: U.num(d.approvedAmount), tenure: Math.max(1, parseInt(d.tenure) || 1), roiType: d.roiType, interest: U.num(d.interest),
      pfType: d.pfType, pfValue: U.num(d.pfValue), gstPct: U.num(d.gstPct), docFee: U.num(d.docFee), stampDuty: U.num(d.stampDuty), note: d.note,
      partnerId: d.partnerId || '', partnerName: d.partnerId ? ((LN._partners || []).find((x) => x.id === d.partnerId) || {}).name || '' : ''
    };
  }
  function bindSanction(l, ls) {
    const f = U.$('#sf');
    const prev = () => { U.$('#sprev').innerHTML = '<div class="est-box">' + chargesHtml(LN.terms(Object.assign({}, l, readTerms(f))), true) + '</div>'; };
    f.oninput = prev; f.onchange = (ev) => {
      if (ev && ev.target && ev.target.name === 'partnerId') {
        const pt = (LN._partners || []).find((x) => x.id === ev.target.value) || ls;
        ['roiType', 'interest', 'pfType', 'pfValue', 'gstPct', 'docFee', 'stampDuty'].forEach((k) => { if (pt[k] !== undefined && pt[k] !== '' && f[k]) f[k].value = pt[k]; });
      }
      prev();
    }; prev();
    f.onsubmit = async (ev) => {
      ev.preventDefault();
      const steps = l.steps || [], last = l.step >= steps.length - 1, cur = steps[l.step] || '';
      const tr = readTerms(f); const note = tr.note; delete tr.note;
      if (!(tr.approvedAmount > 0)) return U.toast(T('enterAmount'), 'err');
      if (last && (l.ref1 == null || !l.guarantor) && LN.settings().requireRefs) { if (!(await U.confirm(T('noRefsWarn')))) return; }
      if (!(await U.confirm((last ? T('finalSanction') : T('approveStep')) + ': ' + cur + '?', T('approve')))) return;
      const tt = LN.terms(Object.assign({}, l, tr));
      const upd = Object.assign(tr, { emi: tt.emi, history: (l.history || []).concat([{ step: cur, status: 'approved', at: Date.now(), by: by(), note }]) });
      if (last) { upd.status = 'approved'; upd.step = steps.length; upd.approvedAt = DB.now(); upd.loanNo = await nextLoanNo(); }
      else { upd.status = 'in_process'; upd.step = l.step + 1; }
      U.loading(true);
      try {
        await DB.update('loans', l.id, upd);
        if (last) {
          await notify(l.empId, l.empName, T('loanApprovedTitle'), T('loanSanctionBody').replace('{a}', U.money(tt.P)).replace('{n}', U.money(tt.net)).replace('{e}', U.money(tt.emi)));
          if (l.guarantor) await notify(l.guarantor.empId, l.guarantor.name, T('guarantorTitle'), T('guarantorBody').replace('{n}', l.empName).replace('{a}', U.money(tt.P)));
        } else await notify(l.empId, l.empName, T('loanUpdateTitle'), T('loanStepBody').replace('{s}', cur));
        U.toast(T('saved'), 'ok'); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  }

  async function rejectLoan(l) {
    const note = await U.prompt(T('reject'), T('reason'), '', 'textarea'); if (note == null) return;
    await DB.update('loans', l.id, { status: 'rejected', rejectedAt: DB.now(), history: (l.history || []).concat([{ step: (l.steps || [])[l.step] || '', status: 'rejected', at: Date.now(), by: by(), note }]) });
    await notify(l.empId, l.empName, T('loanRejectedTitle'), note || '-');
    App.refresh();
  }
  async function cancelSanction(l) {
    const note = await U.prompt(T('cancelSanction'), T('reason'), '', 'textarea'); if (note == null) return;
    await DB.update('loans', l.id, { status: 'rejected', history: (l.history || []).concat([{ step: T('cancelSanction'), status: 'rejected', at: Date.now(), by: by(), note }]) });
    App.refresh();
  }

  async function disburse(l) {
    const chk = await LN.signedDocsReady(l);
    if (!chk.ok) {
      if (!(await U.confirm(T('signedDocsPending') + '\n' + chk.missing.join(', ') + '\n\n' + T('disburseAnyway'), T('disburse')))) return App.go('adminLoanDetail', { id: l.id, tab: 'signed' });
    }
    const t = LN.terms(l);
    const m = U.modal('💸 ' + T('disburse') + ' · ' + l.empName, '<div class="est-box">' + chargesHtml(t, true) + '</div><form class="form" id="df"><div class="grid2f">' +
      U.field('date', T('date'), U.dateKey(), { type: 'date', required: true }) + U.field('mode', T('mode'), 'Bank Transfer', { type: 'select', options: ['Bank Transfer', 'UPI', 'Cash', 'Cheque'] }) +
      U.field('ref', T('refNo'), '', { placeholder: 'UTR / Cheque No.' }) + U.field('firstEmiDate', T('firstEmi'), LN.defaultFirstEmi(), { type: 'date', required: true }) + '</div>' +
      '<p class="muted small">' + T('disburseNote') + '</p><button class="btn block">💸 ' + T('disburse') + ' ' + U.money(t.net) + '</button></form>', { wide: true });
    const f = U.$('#df', m.el);
    f.date.onchange = () => { f.firstEmiDate.value = LN.defaultFirstEmi(f.date.value); };
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      if (!(await U.confirm(T('disburseConfirm').replace('{a}', U.money(t.net)).replace('{n}', l.empName), T('disburse')))) return;
      const tt = LN.terms(Object.assign({}, l, { firstEmiDate: d.firstEmiDate, disbursedAt: d.date }));
      const now = Date.now();
      const ledger = [
        { id: U.uid(), type: 'disbursal', date: d.date, debit: tt.P, credit: 0, mode: d.mode, ref: d.ref, note: T('netPaid') + ' ' + U.moneyPlain(tt.net) + ' · ' + T('chargesDeducted') + ' ' + U.moneyPlain(tt.charges), at: now, by: by() },
        { id: U.uid(), type: 'interest', date: d.date, debit: tt.totalInterest, credit: 0, note: LN.roiText(tt) + ' · ' + tt.n + ' EMI × ' + U.moneyPlain(tt.emi), at: now + 1, by: by() }
      ].filter((x) => x.debit > 0);
      U.loading(true);
      try {
        await DB.update('loans', l.id, {
          status: 'disbursed', disbursedAt: d.date, disburseMode: d.mode, disburseRef: d.ref, firstEmiDate: d.firstEmiDate, emi: tt.emi, ledger: (l.ledger || []).concat(ledger),
          history: (l.history || []).concat([{ step: T('disbursed'), status: 'disbursed', at: now, by: by(), note: U.moneyPlain(tt.net) + ' · ' + d.mode + (d.ref ? ' · ' + d.ref : '') }])
        });
        await notify(l.empId, l.empName, '💸 ' + T('loanDisbursedTitle'), T('loanDisbursedBody').replace('{a}', U.money(tt.net)).replace('{m}', d.mode).replace('{d}', U.fmtDate(d.firstEmiDate)).replace('{e}', U.money(tt.emi)));
        m.close(); U.toast(T('saved'), 'ok'); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  }

  const ENTRY_TYPES = [['emi', 'credit'], ['penalty', 'debit'], ['charge', 'debit'], ['waiver', 'credit'], ['adj_debit', 'debit'], ['adj_credit', 'credit']];
  function ledgerEntry(l, def) {
    const ls = LN.settings(), t = LN.terms(l);
    const m = U.modal(T('addLedgerEntry') + ' · ' + l.empName, '<form class="form" id="lef">' +
      U.field('type', T('entryType'), def, { type: 'select', options: ENTRY_TYPES.map((x) => ({ v: x[0], l: T('lt_' + x[0]) + ' (' + T(x[1]) + ')' })) }) +
      '<div class="grid2f">' + U.field('amount', T('amount') + ' ₹', def === 'emi' ? t.emi : ls.penaltyAmt, { type: 'number', step: '0.01', required: true }) + U.field('date', T('date'), U.dateKey(), { type: 'date', required: true }) +
      U.field('mode', T('mode'), 'Salary Deduction', { type: 'select', options: ['Salary Deduction', 'Cash', 'UPI', 'Bank Transfer', 'Cheque', '-'] }) + U.field('ref', T('refNo'), '') + '</div>' +
      U.field('note', T('note'), '') + '<div class="note small">' + T('outstanding') + ': <b>' + U.money(LN.outstanding(l)) + '</b></div><button class="btn block">' + T('save') + '</button></form>');
    const f = U.$('#lef', m.el);
    f.type.onchange = () => { f.amount.value = f.type.value === 'emi' ? t.emi : f.type.value === 'penalty' ? ls.penaltyAmt : ''; };
    f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f);
      const amt = U.num(d.amount); if (!(amt > 0)) return U.toast(T('enterAmount'), 'err');
      const side = ENTRY_TYPES.find((x) => x[0] === d.type)[1];
      const e = { id: U.uid(), type: d.type, date: d.date, debit: side === 'debit' ? amt : 0, credit: side === 'credit' ? amt : 0, mode: ['penalty', 'charge', 'waiver', 'adj_debit', 'adj_credit'].includes(d.type) && d.mode === 'Salary Deduction' ? '' : d.mode, ref: d.ref, note: d.note, at: Date.now(), by: by() };
      U.loading(true);
      try {
        await DB.update('loans', l.id, { ledger: (l.ledger || []).concat([e]) });
        const bal = r2(LN.outstanding(l) + e.debit - e.credit);
        await notify(l.empId, l.empName, (side === 'credit' ? '✅ ' : '⚠️ ') + T('lt_' + d.type) + ' · ' + U.money(amt), (l.loanNo || '') + ' · ' + T('outstanding') + ': ' + U.money(bal));
        m.close(); U.toast(T('saved'), 'ok'); App.go('adminLoanDetail', { id: l.id, tab: 'statement' });
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
  }

  function foreclose(l) {
    const ls = LN.settings();
    const sch = LN.scheduleStatus(l);
    const futureInt = r2(sch.filter((x) => x.status !== 'paid' && x.due >= U.dateKey()).reduce((s, x) => s + x.interest - 0, 0));
    const bal = LN.outstanding(l);
    const principalLeft = r2(Math.max(0, bal - futureInt));
    const fc = r2(principalLeft * U.num(ls.foreclosePct) / 100);
    const payable = r2(principalLeft + fc);
    const m = U.modal('🔚 ' + T('foreclose') + ' · ' + l.empName, '<div class="kv">' + kv(T('outstanding'), U.money(bal)) + kv(T('futureInterestWaived'), U.money(futureInt)) +
      kv(T('forecloseCharge') + ' (' + U.num(ls.foreclosePct) + '%)', U.money(fc)) + kv(T('forecloseAmount'), '<b>' + U.money(payable) + '</b>') + '</div>' +
      '<form class="form" id="ff"><div class="grid2f">' + U.field('amount', T('amountReceived') + ' ₹', payable, { type: 'number', step: '0.01' }) + U.field('date', T('date'), U.dateKey(), { type: 'date' }) +
      U.field('mode', T('mode'), 'Cash', { type: 'select', options: ['Cash', 'UPI', 'Bank Transfer', 'Salary Deduction', 'Cheque'] }) + U.field('ref', T('refNo'), '') + '</div>' +
      '<button class="btn block">🔚 ' + T('forecloseClose') + '</button></form>');
    U.$('#ff', m.el).onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target); const now = Date.now();
      const amt = U.num(d.amount);
      const add = [];
      if (futureInt > 0) add.push({ id: U.uid(), type: 'waiver', date: d.date, debit: 0, credit: futureInt, note: T('futureInterestWaived'), at: now, by: by() });
      if (fc > 0) add.push({ id: U.uid(), type: 'charge', date: d.date, debit: fc, credit: 0, note: T('forecloseCharge'), at: now + 1, by: by() });
      if (amt > 0) add.push({ id: U.uid(), type: 'foreclosure', date: d.date, debit: 0, credit: amt, mode: d.mode, ref: d.ref, at: now + 2, by: by() });
      const newBal = r2(bal - futureInt + fc - amt);
      if (Math.abs(newBal) > 1 && !(await U.confirm(T('balanceNotZero').replace('{b}', U.money(newBal))))) return;
      U.loading(true);
      try {
        await DB.update('loans', l.id, { ledger: (l.ledger || []).concat(add), status: 'closed', closed: true, closedAt: DB.now(), history: (l.history || []).concat([{ step: T('foreclose'), status: 'closed', at: now, by: by() }]) });
        await notify(l.empId, l.empName, '🔚 ' + T('loanClosedTitle'), (l.loanNo || '') + ' · ' + T('foreclose'));
        m.close(); App.refresh();
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  }
  async function closeLoan(l) {
    const bal = LN.outstanding(l);
    if (!(await U.confirm(Math.abs(bal) > 1 ? T('balanceNotZero').replace('{b}', U.money(bal)) : T('closeLoanConfirm')))) return;
    await DB.update('loans', l.id, { status: 'closed', closed: true, closedAt: DB.now(), history: (l.history || []).concat([{ step: T('closeLoan'), status: 'closed', at: Date.now(), by: by() }]) });
    await notify(l.empId, l.empName, '🔒 ' + T('loanClosedTitle'), l.loanNo || '');
    App.refresh();
  }

  V.adminLoanSettings = async function (el) {
    const s = LN.settings();
    el.innerHTML = '<h2 class="page-title">⚙️ ' + T('loanSettings') + '</h2><form id="lsf" class="form">' +
      '<div class="card"><h3>' + T('general') + '</h3>' + U.field('enabled', T('loanModuleOn'), s.enabled, { type: 'checkbox' }) +
      '<div class="grid2f">' + U.field('maxAmount', T('maxLoanAmount') + ' ₹', s.maxAmount, { type: 'number' }) + U.field('maxTenure', T('maxTenure'), s.maxTenure, { type: 'number', min: 1 }) +
      U.field('minServiceMonths', T('minService'), s.minServiceMonths, { type: 'number' }) + U.field('emiDay', T('emiDay'), s.emiDay, { type: 'number', min: 1 }) + '</div></div>' +
      '<div class="card"><h3>' + T('roi') + '</h3><div class="grid2f">' + U.field('roiType', T('roiType'), s.roiType, { type: 'select', options: [{ v: 'reducing', l: T('reducing') }, { v: 'flat', l: T('flat') }] }) +
      U.field('interest', T('roi') + ' % p.a.', s.interest, { type: 'number', step: '0.01' }) + '</div>' + U.field('showRoi', T('showRoiToEmp'), s.showRoi, { type: 'checkbox' }) +
      '<p class="muted small">' + T('roiNote') + '</p></div>' +
      '<div class="card"><h3>' + T('chargesHead') + '</h3><div class="grid2f">' + U.field('pfType', T('processingFee'), s.pfType, { type: 'select', options: [{ v: 'pct', l: '% ' + T('ofLoan') }, { v: 'fixed', l: '₹ ' + T('fixed') }] }) +
      U.field('pfValue', T('processingFee') + ' (%/₹)', s.pfValue, { type: 'number', step: '0.01' }) + U.field('gstPct', T('gstOnPf') + ' %', s.gstPct, { type: 'number', step: '0.01' }) +
      U.field('docFee', T('docFee') + ' ₹', s.docFee, { type: 'number' }) + U.field('stampDuty', T('stampDuty') + ' ₹', s.stampDuty, { type: 'number' }) +
      U.field('penaltyAmt', T('penaltyDefault') + ' ₹', s.penaltyAmt, { type: 'number' }) + U.field('foreclosePct', T('forecloseCharge') + ' %', s.foreclosePct, { type: 'number', step: '0.01' }) + '</div>' +
      '<p class="muted small">' + T('chargesNote') + '</p></div>' +
      '<div class="card"><h3>' + T('applicationRules') + '</h3>' + U.field('requireRefs', T('requireRefs'), s.requireRefs, { type: 'checkbox' }) + U.field('requireSelfie', T('requireSelfie'), s.requireSelfie, { type: 'checkbox' }) +
      U.field('requireSignedDocs', T('requireSignedDocs'), s.requireSignedDocs, { type: 'checkbox' }) + U.field('signedDocTypes', T('signedDocTypes') + ' (' + T('onePerLine') + ')', (s.signedDocTypes || []).join('\n'), { type: 'textarea', rows: 3 }) + '</div>' +
      '<div class="card"><h3>👁️ ' + T('customerView') + '</h3><p class="muted small">' + T('customerViewNote') + '</p><div class="rights-grid">' +
      ['roi', 'charges', 'schedule', 'scheduleDetail', 'statement', 'emiCard', 'soa', 'docs'].map((k) => U.field('ev_' + k, T('ev_' + k), LN.empView()[k], { type: 'checkbox' })).join('') + '</div></div>' +
      '<div class="card"><button type="button" class="btn ghost" onclick="App.go(\'adminPartners\')">🏦 ' + T('lendingPartners') + '</button> <button type="button" class="btn ghost" onclick="App.go(\'adminCompany\')">🏢 ' + T('companyProfile') + '</button></div>' +
      '<div class="card"><h3>' + T('approvalSteps') + '</h3><p class="muted small">' + T('stepsNote') + '</p>' + U.field('steps', T('onePerLine'), (s.steps || []).join('\n'), { type: 'textarea', rows: 5 }) + '</div>' +
      '<div class="card"><h3>' + T('customFields') + '</h3><p class="muted small">' + T('customFieldsNote') + '</p>' +
      U.field('customFields', T('onePerLine'), (s.customFields || []).map((c) => c.label + ' | ' + c.type + (c.required ? ' | required' : '')).join('\n'), { type: 'textarea', rows: 3 }) + '</div>' +
      '<div class="card"><h3>' + T('letterTemplates') + '</h3><p class="muted small">' + T('placeholders') + ': {name} {empId} {father} {address} {amount} {amountWords} {tenure} {emi} {netAmount} {charges} {loanNo} {date} {showroom} {designation} {guarantor}</p>' +
      U.field('letterTemplate', T('sanctionLetter'), s.letterTemplate, { type: 'textarea', rows: 7 }) +
      U.field('dpnTemplate', 'DPN (' + T('dpnRoiBlank') + ')', s.dpnTemplate, { type: 'textarea', rows: 4 }) +
      U.field('agreementTerms', T('loanAgreement') + ' – ' + T('terms') + ' (' + T('onePerLine') + ')', s.agreementTerms, { type: 'textarea', rows: 8 }) +
      U.field('terms', T('terms') + ' (' + T('applicationForm') + ')', s.terms, { type: 'textarea', rows: 4 }) + '</div>' +
      '<div class="row-btns"><button class="btn ghost" type="button" id="lsr">' + T('resetDefault') + '</button><button class="btn">' + T('save') + '</button></div></form>';
    U.$('#lsr').onclick = async () => { if (!(await U.confirm(T('resetDefault') + '?'))) return; await DB.set('settings', 'loan', LN.defaults()); S.loanSettings = LN.defaults(); App.refresh(); };
    U.$('#lsf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const steps = d.steps.split('\n').map((x) => x.trim()).filter(Boolean);
      if (!steps.length) return U.toast(T('atLeastOneStep'), 'err');
      const customFields = d.customFields.split('\n').map((x) => x.trim()).filter(Boolean).map((line, i) => {
        const parts = line.split('|').map((x) => x.trim());
        const type = ['text', 'number', 'date', 'tel', 'textarea'].includes(parts[1]) ? parts[1] : 'text';
        return { key: 'f' + i + '_' + parts[0].toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 20), label: parts[0], type, required: /req/i.test(parts[2] || '') };
      });
      const ns = {
        enabled: !!d.enabled, maxAmount: U.num(d.maxAmount), maxTenure: Math.max(1, parseInt(d.maxTenure) || 1), minServiceMonths: U.num(d.minServiceMonths), emiDay: Math.min(28, Math.max(1, parseInt(d.emiDay) || 5)),
        roiType: d.roiType, interest: U.num(d.interest), showRoi: !!d.showRoi, pfType: d.pfType, pfValue: U.num(d.pfValue), gstPct: U.num(d.gstPct), docFee: U.num(d.docFee), stampDuty: U.num(d.stampDuty),
        penaltyAmt: U.num(d.penaltyAmt), foreclosePct: U.num(d.foreclosePct), requireRefs: !!d.requireRefs, requireSelfie: !!d.requireSelfie,
        requireSignedDocs: !!d.requireSignedDocs, signedDocTypes: String(d.signedDocTypes || '').split('\n').map((x) => x.trim()).filter(Boolean),
        empView: ['roi', 'charges', 'schedule', 'scheduleDetail', 'statement', 'emiCard', 'soa', 'docs'].reduce((o, k) => { o[k] = !!d['ev_' + k]; return o; }, {}),
        steps, customFields, letterTemplate: d.letterTemplate, dpnTemplate: d.dpnTemplate, agreementTerms: d.agreementTerms, terms: d.terms
      };
      try { await DB.set('settings', 'loan', ns); S.loanSettings = ns; U.toast(T('saved'), 'ok'); } catch (e) { U.toast(e.message, 'err'); }
    };
  };

  // employee's old detail modal now opens the full page
  window.loanDetailView = (l) => App.go(S.isAdmin ? 'adminLoanDetail' : 'empLoanDetail', { id: l.id });
})();
