// ---------- Firebase data layer ----------
(function () {
  const DB = {};
  let app, auth, fs, FV;

  DB.configured = function () {
    const c = window.FIREBASE_CONFIG || {};
    return c.apiKey && !/PASTE/.test(c.apiKey) && c.projectId && !/PASTE/.test(c.projectId);
  };

  DB.init = function () {
    app = firebase.initializeApp(window.FIREBASE_CONFIG);
    auth = firebase.auth();
    fs = firebase.firestore();
    try { fs.enablePersistence && fs.enablePersistence({ synchronizeTabs: true }).catch(() => { }); } catch (e) { }
    FV = firebase.firestore.FieldValue;
    DB.auth = auth; DB.fs = fs;
  };

  DB.now = () => FV.serverTimestamp();
  DB.inc = (n) => FV.increment(n);
  DB.arrayUnion = (...v) => FV.arrayUnion(...v);

  const col = (n) => fs.collection(n);
  const snapList = (s) => s.docs.map((d) => Object.assign({ id: d.id }, d.data()));
  const docData = (d) => (d.exists ? Object.assign({ id: d.id }, d.data()) : null);

  DB.get = async (c, id) => docData(await col(c).doc(id).get());
  DB.set = (c, id, data, merge) => col(c).doc(id).set(data, merge ? { merge: true } : undefined);
  DB.update = (c, id, data) => col(c).doc(id).update(data);
  DB.add = async (c, data) => { const r = await col(c).add(data); return r.id; };
  DB.del = (c, id) => col(c).doc(id).delete();
  DB.all = async (c) => snapList(await col(c).get());
  // where: [[field, op, value], ...]
  DB.query = async (c, wheres) => {
    let q = col(c);
    (wheres || []).forEach((w) => { q = q.where(w[0], w[1], w[2]); });
    return snapList(await q.get());
  };
  DB.watch = (c, wheres, cb, onErr) => {
    let q = col(c);
    (wheres || []).forEach((w) => { q = q.where(w[0], w[1], w[2]); });
    return q.onSnapshot((s) => cb(snapList(s)), (e) => { console.warn(e); if (onErr) onErr(e); });
  };
  DB.watchDoc = (c, id, cb) => col(c).doc(id).onSnapshot((d) => cb(docData(d)), (e) => console.warn(e));

  // ---------- Auth ----------
  DB.loginEmail = function (idOrEmail) {
    idOrEmail = String(idOrEmail || '').trim().toLowerCase();
    return idOrEmail;
  };
  DB.signIn = async function (id, pass) {
    let email = id.trim().toLowerCase();
    if (!email.includes('@')) {
      const mob = email.replace(/\D/g, '');
      const map = await DB.get('logins', mob);
      if (!map) throw new Error(T('loginNotFound'));
      email = map.email;
    }
    return auth.signInWithEmailAndPassword(email, pass);
  };
  DB.signOut = () => auth.signOut();
  DB.changePassword = async (oldPass, newPass) => {
    const u = auth.currentUser;
    const cred = firebase.auth.EmailAuthProvider.credential(u.email, oldPass);
    await u.reauthenticateWithCredential(cred);
    await u.updatePassword(newPass);
  };

  // Create a staff login without logging the admin out (secondary app)
  DB.createStaffLogin = async function (mobile, password) {
    const name = 'sec' + Date.now();
    const sec = firebase.initializeApp(window.FIREBASE_CONFIG, name);
    try {
      const n = (await DB.get('logins', mobile)) ? Date.now().toString(36) : '';
      const email = 'm' + mobile + (n ? '.' + n : '') + '@' + window.APP_INFO.staffDomain;
      const cred = await sec.auth().createUserWithEmailAndPassword(email, password);
      const uid = cred.user.uid;
      await sec.auth().signOut();
      return { uid, email };
    } finally {
      try { await sec.delete(); } catch (e) { }
    }
  };

  DB.bootstrap = async function (name, email, password) {
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    const uid = cred.user.uid;
    await DB.set('meta', 'bootstrap', { adminUid: uid, at: DB.now() });
    await DB.set('users', uid, { role: 'admin', name: name, email: email, active: true, createdAt: DB.now() });
    await DB.set('settings', 'app', DB.defaultSettings(), true);
    await DB.set('settings', 'loan', DB.defaultLoanSettings(), true);
    return uid;
  };

  DB.defaultSettings = () => ({
    showroom: window.APP_INFO.showroom,
    address: '',
    phone: '',
    lat: null, lng: null, radius: 150,
    blockOutside: true,
    sundayPaid: true,
    weeklyOff: 0,
    officeStart: '09:30',
    officeEnd: '19:00'
  });

  DB.defaultLoanSettings = () => ({
    enabled: true,
    interest: 0,
    maxAmount: 50000,
    maxTenure: 12,
    minServiceMonths: 6,
    steps: ['Application Review', 'Document Verification', 'Manager Approval', 'Final Approval'],
    customFields: [
      { key: 'guarantorName', label: 'Guarantor Name', type: 'text', required: false },
      { key: 'guarantorMobile', label: 'Guarantor Mobile', type: 'tel', required: false }
    ],
    letterTemplate:
      'Dear {name},\n\nWe are pleased to inform you that your staff loan application No. {loanNo} has been APPROVED by the management of {showroom}.\n\n' +
      'Sanctioned Amount: Rs. {amount} ({amountWords} Only)\nRate of Interest: {interest}% per annum\nTenure: {tenure} months\nMonthly EMI: Rs. {emi}\n\n' +
      'The EMI will be deducted from your monthly salary starting from the month following disbursement. In case you leave the organisation, the outstanding balance shall become payable immediately and may be adjusted against your dues.\n\n' +
      'Please sign the Demand Promissory Note (DPN) and submit it to the office before disbursement.',
    dpnTemplate:
      'On demand, I, {name}, son/daughter of {father}, residing at {address}, Employee ID {empId}, promise to pay {showroom} or order, the sum of Rs. {amount} ({amountWords} Only) together with interest at the rate of {interest}% per annum, for value received in cash.',
    terms: '1. EMI will be deducted from monthly salary.\n2. Full balance becomes payable on resignation/termination.\n3. Management decision on loan is final.'
  });

  window.DB = DB;
})();
