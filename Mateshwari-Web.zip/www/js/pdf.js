// ---------- Letters, ID card, PDF & Excel export ----------
(function () {
  const P = window.PDF = {};
  const esc = U.esc;
  let logoData = null;

  async function logo() {
    if (logoData) return logoData;
    try {
      const r = await fetch('img/logo.png'); const b = await r.blob();
      logoData = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(b); });
    } catch (e) { logoData = null; }
    return logoData;
  }
  // jsPDF core fonts are Latin only
  const L = (s) => String(s == null ? '' : s).replace(/₹/g, 'Rs.').replace(/[^\x09\x0A\x0D\x20-\x7E]/g, '');

  function newDoc(orient, format) {
    const { jsPDF } = window.jspdf;
    return new jsPDF({ orientation: orient || 'portrait', unit: 'mm', format: format || 'a4' });
  }
  function savePdf(doc, name) {
    const uri = doc.output('datauristring');
    return U.saveFile(name, uri.split(',')[1], 'application/pdf');
  }
  P.savePdf = savePdf;

  async function letterhead(doc, title) {
    const st = S.settings, W = doc.internal.pageSize.getWidth();
    const lg = await logo();
    doc.setFillColor(218, 37, 29); doc.rect(0, 0, W, 4, 'F');
    if (lg) doc.addImage(lg, 'PNG', 14, 9, 42, 13.6);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(17); doc.setTextColor(218, 37, 29);
    doc.text(L(st.showroom || APP_INFO.showroom), W - 14, 15, { align: 'right' });
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(80);
    const addr = L(st.address || ''); if (addr) doc.text(doc.splitTextToSize(addr, 110), W - 14, 20, { align: 'right' });
    if (st.phone) doc.text('Ph: ' + L(st.phone), W - 14, 28, { align: 'right' });
    doc.setDrawColor(218, 37, 29); doc.setLineWidth(0.6); doc.line(14, 32, W - 14, 32);
    doc.setTextColor(20);
    if (title) { doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.text(L(title), W / 2, 42, { align: 'center' }); }
    return 50;
  }
  function paragraph(doc, text, y, size) {
    const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
    doc.setFont('helvetica', 'normal'); doc.setFontSize(size || 11);
    const lines = doc.splitTextToSize(L(text), W - 28);
    lines.forEach((ln) => {
      if (y > H - 30) { doc.addPage(); y = 20; }
      doc.text(ln, 14, y); y += (size || 11) * 0.48;
    });
    return y;
  }
  function signature(doc, y, left, right) {
    const W = doc.internal.pageSize.getWidth();
    y = Math.max(y + 18, 0);
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    if (left) { doc.line(14, y, 74, y); doc.text(L(left), 14, y + 5); }
    if (right) { doc.line(W - 84, y, W - 14, y); doc.text(L(right), W - 84, y + 5); }
    return y + 10;
  }

  // ---------- Loan template vars ----------
  function loanVars(l) {
    const a = l.applicant || {};
    const amt = l.approvedAmount || l.amount;
    return {
      name: a.name || l.empName, empId: l.empId, father: a.fatherName || '-', address: a.address || '-', designation: a.designation || '',
      amount: Number(amt).toLocaleString('en-IN'), amountWords: U.numToWords(amt), interest: l.interest || 0, tenure: l.tenure,
      emi: Number(l.emi || 0).toLocaleString('en-IN'), loanNo: l.loanNo || '-', date: U.fmtDate(l.approvedAt || new Date()), showroom: S.settings.showroom || APP_INFO.showroom
    };
  }
  function headHtml(title) {
    const st = S.settings;
    return '<div class="lh"><img src="img/logo.png" alt=""><div><b>' + esc(st.showroom || APP_INFO.showroom) + '</b><small>' + esc(st.address || '') + (st.phone ? ' · ' + esc(st.phone) : '') +
      '</small></div></div>' + (title ? '<h3 class="center">' + esc(title) + '</h3>' : '');
  }

  P.showLoanLetter = function (l) {
    const v = loanVars(l), ls = S.loanSettings;
    const body = U.fillTemplate(ls.letterTemplate, v);
    const m = U.modal(T('approvalLetter'), '<div class="letter">' + headHtml('LOAN APPROVAL LETTER') +
      '<div class="row-between"><span>Ref: ' + esc(v.loanNo) + '</span><span>Date: ' + esc(v.date) + '</span></div>' +
      '<p>To,<br><b>' + esc(v.name) + '</b><br>' + esc(v.designation) + ' (Emp ID: ' + esc(v.empId) + ')</p>' +
      '<p><b>Subject: Sanction of Staff Loan</b></p><p>' + esc(body).replace(/\n/g, '<br>') + '</p>' +
      (ls.terms ? '<p class="small"><b>Terms &amp; Conditions</b><br>' + esc(ls.terms).replace(/\n/g, '<br>') + '</p>' : '') +
      '<div class="sig"><span>Employee Signature</span><span>For ' + esc(v.showroom) + '<br>Authorised Signatory</span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.loanLetterPdf(l);
  };
  P.loanLetterPdf = async function (l) {
    const v = loanVars(l), ls = S.loanSettings;
    const doc = newDoc(); let y = await letterhead(doc, 'LOAN APPROVAL LETTER');
    const W = doc.internal.pageSize.getWidth();
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    doc.text('Ref: ' + L(v.loanNo), 14, y); doc.text('Date: ' + v.date, W - 14, y, { align: 'right' }); y += 10;
    y = paragraph(doc, 'To,\n' + v.name + '\n' + v.designation + ' (Emp ID: ' + v.empId + ')', y); y += 4;
    doc.setFont('helvetica', 'bold'); doc.text('Subject: Sanction of Staff Loan', 14, y); y += 8;
    y = paragraph(doc, U.fillTemplate(ls.letterTemplate, v), y) + 4;
    if (ls.terms) { doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.text('Terms & Conditions', 14, y); y = paragraph(doc, ls.terms, y + 5, 9.5); }
    signature(doc, y, 'Employee Signature', 'For ' + v.showroom + ' (Authorised Signatory)');
    await savePdf(doc, 'Loan_Approval_' + safeName(v.loanNo) + '.pdf');
  };

  P.showDPN = function (l) {
    const v = loanVars(l);
    const body = U.fillTemplate(S.loanSettings.dpnTemplate, v);
    const m = U.modal('DPN', '<div class="letter">' + headHtml('DEMAND PROMISSORY NOTE') +
      '<div class="row-between"><b>Rs. ' + esc(v.amount) + '/-</b><span>Date: ' + esc(v.date) + '</span></div><p>Place: ________________</p>' +
      '<p>' + esc(body).replace(/\n/g, '<br>') + '</p><div class="stamp">Revenue<br>Stamp</div>' +
      '<div class="sig"><span>Witness 1<br>Name: ____________</span><span>Signature of Borrower<br>' + esc(v.name) + '</span></div>' +
      '<div class="sig"><span>Witness 2<br>Name: ____________</span><span></span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = () => P.dpnPdf(l);
  };
  P.dpnPdf = async function (l) {
    const v = loanVars(l);
    const doc = newDoc(); let y = await letterhead(doc, 'DEMAND PROMISSORY NOTE');
    const W = doc.internal.pageSize.getWidth();
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text('Rs. ' + v.amount + '/-', 14, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.text('Date: ' + v.date, W - 14, y, { align: 'right' }); y += 7;
    doc.text('Place: ____________________', 14, y); y += 10;
    y = paragraph(doc, U.fillTemplate(S.loanSettings.dpnTemplate, v), y, 11.5) + 8;
    doc.rect(W - 44, y, 30, 30); doc.setFontSize(8); doc.text('Affix Revenue', W - 29, y + 13, { align: 'center' }); doc.text('Stamp', W - 29, y + 17, { align: 'center' });
    y += 40;
    signature(doc, y, 'Witness 1 (Name & Sign)', 'Signature of Borrower: ' + v.name);
    signature(doc, y + 22, 'Witness 2 (Name & Sign)', '');
    await savePdf(doc, 'DPN_' + safeName(v.loanNo) + '.pdf');
  };

  P.showWarning = function (w) {
    const m = U.modal(T('warningLetter'), '<div class="letter">' + headHtml('WARNING LETTER') +
      '<div class="row-between"><span>Ref: ' + esc(w.refNo || '') + '</span><span>Date: ' + U.fmtDate(w.at) + '</span></div>' +
      '<p>To,<br><b>' + esc(w.empName) + '</b><br>' + esc(w.designation || '') + ' (Emp ID: ' + esc(w.empId) + ')</p>' +
      '<p><b>Subject: ' + esc(w.subject) + '</b></p><p>Dear ' + esc(w.empName) + ',</p><p>' + esc(w.body).replace(/\n/g, '<br>') + '</p>' +
      '<div class="sig"><span></span><span>For ' + esc(S.settings.showroom) + '<br>Authorised Signatory</span></div></div>' +
      '<button class="btn block" data-dl>⬇ ' + T('downloadPdf') + '</button>', { wide: true });
    m.el.querySelector('[data-dl]').onclick = async () => {
      const doc = newDoc(); let y = await letterhead(doc, 'WARNING LETTER');
      const W = doc.internal.pageSize.getWidth();
      doc.setFontSize(10); doc.text('Ref: ' + L(w.refNo || ''), 14, y); doc.text('Date: ' + U.fmtDate(w.at), W - 14, y, { align: 'right' }); y += 10;
      y = paragraph(doc, 'To,\n' + w.empName + '\n' + (w.designation || '') + ' (Emp ID: ' + w.empId + ')', y) + 4;
      doc.setFont('helvetica', 'bold'); doc.text(L('Subject: ' + w.subject), 14, y); y += 8;
      y = paragraph(doc, 'Dear ' + w.empName + ',\n\n' + w.body, y);
      signature(doc, y + 6, '', 'For ' + S.settings.showroom + ' (Authorised Signatory)');
      await savePdf(doc, 'Warning_' + safeName(w.refNo || w.id) + '.pdf');
    };
  };

  // ---------- ID card ----------
  P.idCardHtml = function (e, st) {
    return '<div class="idcard-wrap"><div class="idcard"><div class="idc-top"><img src="img/logo.png" alt=""><b>' + esc(st.showroom || APP_INFO.showroom) + '</b></div>' +
      '<div class="idc-photo">' + App.empAvatar(e, 92) + '</div><div class="idc-name">' + esc(e.name) + '</div><div class="idc-desig">' + esc(e.designation || '') + '</div>' +
      '<div class="idc-info"><div><span>ID</span><b>' + esc(e.id) + '</b></div><div><span>Mobile</span><b>' + esc(e.mobile || '') + '</b></div>' +
      '<div><span>Blood</span><b>' + esc(e.bloodGroup || '-') + '</b></div><div><span>Joined</span><b>' + U.fmtDate(e.joinDate) + '</b></div></div>' +
      '<div class="idc-foot">EMPLOYEE IDENTITY CARD</div></div>' +
      '<div class="idcard back"><div class="idc-top"><b>' + esc(st.showroom || APP_INFO.showroom) + '</b></div><div class="idc-back">' +
      '<p><span>Address</span>' + esc(e.address || '-') + '</p><p><span>Emergency</span>' + esc(e.emergencyContact || '-') + '</p>' +
      '<p class="small">If found, please return to:<br><b>' + esc(st.showroom || '') + '</b><br>' + esc(st.address || '') + '<br>' + esc(st.phone || '') + '</p>' +
      '<div class="idc-sign">Authorised Signatory</div></div></div></div>';
  };

  P.idCardPdf = async function (e, st) {
    const doc = newDoc('portrait', [54, 85.6]);
    const W = 54, H = 85.6;
    const lg = await logo();
    const shop = L(st.showroom || APP_INFO.showroom);
    // front
    doc.setFillColor(218, 37, 29); doc.rect(0, 0, W, 17, 'F');
    doc.setFillColor(255, 255, 255); doc.roundedRect(3, 2.5, 19, 6.4, 1, 1, 'F');
    if (lg) doc.addImage(lg, 'PNG', 3.6, 3, 17.8, 5.8);
    doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(6.4);
    doc.text(doc.splitTextToSize(shop, 28), W - 3, 5.6, { align: 'right' });
    doc.setFontSize(5); doc.setFont('helvetica', 'normal'); doc.text('Staff Identity Card', W - 3, 14, { align: 'right' });
    if (e.photo) { try { doc.addImage(e.photo, 'JPEG', W / 2 - 11, 20, 22, 25); } catch (x) { } }
    else { doc.setDrawColor(200); doc.rect(W / 2 - 11, 20, 22, 25); doc.setTextColor(150); doc.setFontSize(6); doc.text('PHOTO', W / 2, 33, { align: 'center' }); }
    doc.setDrawColor(218, 37, 29); doc.setLineWidth(0.5); doc.rect(W / 2 - 11, 20, 22, 25);
    doc.setTextColor(20); doc.setFont('helvetica', 'bold'); doc.setFontSize(9);
    doc.text(doc.splitTextToSize(L(e.name), W - 6), W / 2, 50, { align: 'center' });
    doc.setFont('helvetica', 'normal'); doc.setFontSize(6.5); doc.setTextColor(218, 37, 29);
    doc.text(L(e.designation || ''), W / 2, 54.5, { align: 'center' });
    doc.setTextColor(30); doc.setFontSize(6.4);
    const rows = [['Emp ID', e.id], ['Mobile', e.mobile], ['Blood Group', e.bloodGroup || '-'], ['Joined', U.fmtDate(e.joinDate)]];
    let y = 60;
    rows.forEach((r) => { doc.setFont('helvetica', 'normal'); doc.text(r[0], 6, y); doc.setFont('helvetica', 'bold'); doc.text(': ' + L(r[1] || '-'), 22, y); y += 4.2; });
    doc.setFillColor(20, 20, 20); doc.rect(0, H - 6, W, 6, 'F');
    doc.setTextColor(255); doc.setFontSize(5.5); doc.text('EMPLOYEE IDENTITY CARD', W / 2, H - 2.2, { align: 'center' });
    // back
    doc.addPage([54, 85.6], 'portrait');
    doc.setFillColor(218, 37, 29); doc.rect(0, 0, W, 9, 'F');
    doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(7); doc.text(shop, W / 2, 5.8, { align: 'center' });
    doc.setTextColor(30); y = 15;
    const block = (label, val) => {
      doc.setFont('helvetica', 'bold'); doc.setFontSize(6); doc.text(label, 4, y); y += 3;
      doc.setFont('helvetica', 'normal'); doc.setFontSize(6.2);
      const ls = doc.splitTextToSize(L(val || '-'), W - 8); doc.text(ls, 4, y); y += ls.length * 2.8 + 2;
    };
    block('Address', e.address); block('Emergency Contact', e.emergencyContact); block('Date of Birth', U.fmtDate(e.dob));
    y += 2; doc.setFontSize(5.6); doc.setFont('helvetica', 'italic');
    const ret = doc.splitTextToSize(L('If found, please return to: ' + (st.showroom || '') + ', ' + (st.address || '') + (st.phone ? ', Ph: ' + st.phone : '')), W - 8);
    doc.text(ret, 4, y);
    doc.setFont('helvetica', 'normal'); doc.setDrawColor(120); doc.line(W - 26, H - 10, W - 4, H - 10); doc.setFontSize(5.5); doc.text('Authorised Signatory', W - 15, H - 7, { align: 'center' });
    await savePdf(doc, 'ID_Card_' + safeName(e.id) + '.pdf');
  };

  // ---------- Exam certificate ----------
  P.certificatePdf = async function (x, a, e, g, certNo) {
    const doc = newDoc('landscape'); const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
    const lg = await logo(); const st = S.settings;
    doc.setDrawColor(218, 37, 29); doc.setLineWidth(2.5); doc.rect(8, 8, W - 16, H - 16);
    doc.setDrawColor(30); doc.setLineWidth(0.4); doc.rect(12, 12, W - 24, H - 24);
    if (lg) doc.addImage(lg, 'PNG', W / 2 - 25, 20, 50, 16.25);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(14); doc.setTextColor(218, 37, 29); doc.text(L(st.showroom || APP_INFO.showroom), W / 2, 44, { align: 'center' });
    doc.setTextColor(25); doc.setFont('times', 'bold'); doc.setFontSize(30); doc.text('CERTIFICATE OF ACHIEVEMENT', W / 2, 62, { align: 'center' });
    doc.setFont('times', 'italic'); doc.setFontSize(14); doc.text('This is to certify that', W / 2, 76, { align: 'center' });
    doc.setFont('times', 'bold'); doc.setFontSize(26); doc.setTextColor(218, 37, 29); doc.text(L(e.name), W / 2, 90, { align: 'center' });
    doc.setDrawColor(180); doc.line(W / 2 - 70, 93, W / 2 + 70, 93);
    doc.setTextColor(40); doc.setFont('times', 'normal'); doc.setFontSize(12);
    doc.text(L((e.designation || '') + '  (Employee ID: ' + e.id + ')'), W / 2, 101, { align: 'center' });
    doc.setFontSize(14); doc.text('has successfully passed the assessment', W / 2, 113, { align: 'center' });
    doc.setFont('times', 'bold'); doc.setFontSize(18); doc.text(L(x.title), W / 2, 124, { align: 'center' });
    doc.setFont('times', 'normal'); doc.setFontSize(14);
    doc.text('with a score of ' + g.pct + '% (' + g.score + '/' + g.total + ') on ' + U.fmtDate(a.submittedAt), W / 2, 135, { align: 'center' });
    doc.setFontSize(10); doc.setFont('helvetica', 'normal');
    doc.line(30, H - 32, 95, H - 32); doc.text('Certificate No: ' + L(certNo), 30, H - 27);
    doc.line(W - 95, H - 32, W - 30, H - 32); doc.text('Authorised Signatory', W - 62.5, H - 27, { align: 'center' });
    await savePdf(doc, 'Certificate_' + safeName(e.id + '_' + x.title) + '.pdf');
  };

  // ---------- Generic table exports ----------
  P.tablePdf = async function (title, subtitle, columns, rows, foot, legend) {
    const landscape = columns.length > 6;
    const doc = newDoc(landscape ? 'landscape' : 'portrait');
    const W = doc.internal.pageSize.getWidth();
    const lg = await logo();
    if (lg) doc.addImage(lg, 'PNG', 14, 8, 30, 9.75);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(14); doc.setTextColor(218, 37, 29);
    doc.text(L(S.settings.showroom || APP_INFO.showroom), W - 14, 13, { align: 'right' });
    doc.setTextColor(20); doc.setFontSize(12); doc.text(L(title), 14, 26);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(90);
    doc.text(L((subtitle || '') + (legend ? '    ' + legend : '')), 14, 31); doc.text('Generated: ' + U.fmtDT(new Date()), W - 14, 31, { align: 'right' });
    doc.autoTable({
      startY: 35, head: [columns.map(L)], body: rows.map((r) => r.map((c) => L(c))), foot: foot ? [foot.map(L)] : undefined,
      styles: { fontSize: columns.length > 10 ? 6.5 : 8.5, cellPadding: 1.6 }, headStyles: { fillColor: [218, 37, 29] },
      footStyles: { fillColor: [235, 235, 235], textColor: 20, fontStyle: 'bold' }, alternateRowStyles: { fillColor: [250, 246, 246] }, margin: { left: 10, right: 10 },
      didDrawPage: (d) => { doc.setFontSize(8); doc.setTextColor(150); doc.text('Page ' + doc.internal.getNumberOfPages(), W - 14, doc.internal.pageSize.getHeight() - 6, { align: 'right' }); }
    });
    await savePdf(doc, safeName(title + '_' + (subtitle || '')) + '.pdf');
  };

  P.tableXlsx = async function (title, subtitle, columns, rows, foot) {
    const aoa = [[S.settings.showroom || APP_INFO.showroom], [title + (subtitle ? ' - ' + subtitle : '')], [], columns].concat(rows);
    if (foot) aoa.push(foot);
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = columns.map((c, i) => ({ wch: Math.max(String(c).length, ...rows.map((r) => String(r[i] == null ? '' : r[i]).length)) + 2 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, String(title).slice(0, 30).replace(/[\\/?*\[\]:]/g, ''));
    const b64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
    await U.saveFile(safeName(title + '_' + (subtitle || '')) + '.xlsx', b64, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  };
})();
