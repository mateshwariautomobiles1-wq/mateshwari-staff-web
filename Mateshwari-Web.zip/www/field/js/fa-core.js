// ---------- Field Activity app: shell, login, settings, camera ----------
(function () {
  const S = window.S = { user: null, member: null, isAdmin: false, cfg: null, members: [], view: null, params: null, unsubs: [] };
  const V = window.Views = {};
  const App = window.App = {};
  const FA = window.FA = {};
  const esc = U.esc;
  const root = () => document.getElementById('app');

  // ---------- default settings ----------
  const F = (key, label, type, required, options) => ({ key, label, type: type || 'number', required: !!required, options: options || '' });
  FA.defaultTypes = () => [
    { id: 'service_camp', name: 'Service Camp', icon: '🛠️', active: true, minPhotos: 3, minEnquiries: 0, enquiries: true,
      fields: [F('vehiclesServiced', 'Vehicles serviced', 'number', true), F('jobCards', 'Job cards opened'), F('freeCheckups', 'Free check-ups'), F('partsSale', 'Parts / oil sale ₹'), F('feedback', 'Customer feedback', 'textarea')] },
    { id: 'exchange_camp', name: 'Exchange Camp', icon: '🔄', active: true, minPhotos: 3, minEnquiries: 0, enquiries: true,
      fields: [F('evaluated', 'Old vehicles evaluated', 'number', true), F('exchangeBookings', 'Exchange bookings'), F('bestOffer', 'Best offer given ₹')] },
    { id: 'door_to_door', name: 'Door to Door Leaflet', icon: '🚪', active: true, minPhotos: 2, minEnquiries: 0, enquiries: true,
      fields: [F('leaflets', 'Leaflets distributed', 'number', true), F('houses', 'Houses / shops covered', 'number', true), F('streets', 'Streets / mohalla covered', 'text')] },
    { id: 'leaflet_distribution', name: 'Leaflet Distribution', icon: '📄', active: true, minPhotos: 2, minEnquiries: 0, enquiries: true,
      fields: [F('leaflets', 'Leaflets distributed', 'number', true), F('spot', 'Spot (market / chowk / haat)', 'text')] },
    { id: 'engine_check_camp', name: 'Engine Check Camp', icon: '⚙️', active: true, minPhotos: 3, minEnquiries: 0, enquiries: true,
      fields: [F('enginesChecked', 'Engines checked', 'number', true), F('issuesFound', 'Issues found'), F('serviceBooked', 'Service bookings')] },
    { id: 'road_show', name: 'Road Show / Canopy Display', icon: '🏍️', active: true, minPhotos: 3, minEnquiries: 0, enquiries: true,
      fields: [F('footfall', 'Footfall (people visited)'), F('testRides', 'Test rides'), F('vehiclesDisplayed', 'Vehicles displayed')] }
  ];
  FA.defaultCfg = () => ({
    types: FA.defaultTypes(),
    core: { area: true, location: true, landmark: false, leader: true, team: false, plan: true, target: false },
    enq: { mobile: true, village: true, model: false, followUpDate: false, purchaseTime: false },
    allowGallery: false, blockMock: true, requireApproval: true, empSeeAll: true, empReports: true, endGps: true,
    models: ['Splendor+', 'Super Splendor', 'HF Deluxe', 'Passion+', 'Glamour', 'Xtreme 125R', 'Xtreme 160R', 'Xpulse 200', 'Xoom', 'Destini 125', 'Pleasure+', 'Vida (EV)'].join('\n'),
    areas: ''
  });
  FA.loadCfg = async function () {
    const d = (await DB.get('fa_settings', 'app')) || {};
    const def = FA.defaultCfg();
    S.cfg = Object.assign(def, d, { core: Object.assign(def.core, d.core || {}), enq: Object.assign(def.enq, d.enq || {}) });
    if (!Array.isArray(S.cfg.types) || !S.cfg.types.length) S.cfg.types = def.types;
    return S.cfg;
  };
  FA.types = (all) => (S.cfg.types || []).filter((t) => all || t.active !== false);
  FA.type = (id) => (S.cfg.types || []).find((t) => t.id === id) || null;
  FA.models = () => String(S.cfg.models || '').split('\n').map((x) => x.trim()).filter(Boolean);
  FA.areas = () => String(S.cfg.areas || '').split('\n').map((x) => x.trim()).filter(Boolean);
  FA.loadMembers = async function () {
    S.members = (await DB.all('fa_members')).sort((a, b) => String(a.name).localeCompare(String(b.name)));
    return S.members;
  };
  FA.member = (id) => S.members.find((m) => m.id === id) || null;
  FA.myId = () => (S.isAdmin ? 'admin' : S.user.empId);
  FA.myName = () => (S.isAdmin ? (S.user.name || 'Admin') : ((S.member && S.member.name) || S.user.empId));
  FA.canCreate = () => S.isAdmin || (S.member && S.member.canCreate !== false);

  // ---------- badges ----------
  U.badge = function (status) {
    const map = { draft: 'info', submitted: 'warn', approved: 'ok', rejected: 'bad', open: 'info', followup: 'warn', booked: 'ok', lost: 'muted', hot: 'bad', warm: 'warn', cold: 'info' };
    const lab = ['hot', 'warm', 'cold'].includes(status) ? T(status) : T('st_' + status);
    return '<span class="badge ' + (map[status] || 'muted') + '">' + esc(lab) + '</span>';
  };

  // ---------- start ----------
  App.start = async function () {
    I18N.init();
    if (!DB.configured()) { root().innerHTML = '<div class="center-card card">' + T('notConfigured') + '</div>'; return; }
    DB.init();
    U.loading(true);
    DB.auth.onAuthStateChanged(async (fbUser) => {
      S.unsubs.forEach((f) => { try { f(); } catch (e) { } }); S.unsubs = [];
      if (!fbUser) { U.loading(false); return renderLogin(); }
      try {
        const u = await DB.get('users', fbUser.uid);
        if (!u || u.active === false) { U.loading(false); await DB.signOut(); U.toast(T('accountInactive'), 'err'); return; }
        S.user = u; S.isAdmin = u.role === 'admin';
        if (!S.isAdmin) {
          let m = null; try { m = await DB.get('fa_members', u.empId); } catch (e) { m = null; }
          if (!m || m.active === false) { U.loading(false); await DB.signOut(); U.toast(T('notFieldMember'), 'err'); return; }
          S.member = m;
        }
        await FA.loadCfg();
        await FA.loadMembers();
        U.loading(false);
        renderShell();
        App.go(S.isAdmin ? 'adminDashboard' : 'empHome');
      } catch (e) {
        console.error(e); U.loading(false);
        root().innerHTML = '<div class="center-card card"><h3>' + T('error') + '</h3><p>' + esc(e.message) + '</p><button class="btn" onclick="DB.signOut()">' + T('logout') + '</button></div>';
      }
    });
  };

  // ---------- login ----------
  function renderLogin() {
    S.user = null; S.member = null;
    U.$$('.modal-wrap').forEach((m) => m.remove());
    root().innerHTML = '<div class="login-page"><div class="lang-top">' + langSwitch() + '</div><div class="login-card card">' +
      '<img src="img/logo.png" class="login-logo" alt=""><h2>' + esc(APP_INFO.showroom) + '</h2><p class="muted"><b>📍 ' + esc(APP_INFO.appName) + '</b> · ' + T('appSubtitle') + '</p>' +
      '<form id="loginForm" class="form">' + U.field('id', T('mobileOrEmail'), '', { required: true, placeholder: '98xxxxxxxx' }) +
      U.field('password', T('password'), '', { type: 'password', required: true }) +
      '<button class="btn block" type="submit">' + T('login') + '</button><p class="muted small center">' + T('sameLogin') + '</p></form>' +
      '</div><p class="muted small center">v' + APP_INFO.version + '</p></div>';
    bindLang();
    U.$('#loginForm').onsubmit = async (e) => {
      e.preventDefault(); const d = U.formData(e.target);
      U.loading(true, T('signingIn'));
      try { await DB.signIn(d.id, d.password); } catch (err) { U.loading(false); U.toast(authErr(err), 'err'); }
    };
  }
  function authErr(err) {
    const c = (err && err.code) || '';
    if (/wrong-password|invalid-credential|invalid-login|user-not-found/.test(c)) return T('wrongLogin');
    if (/too-many-requests/.test(c)) return T('tooMany');
    if (/network/.test(c)) return T('noInternet');
    if (/weak-password/.test(c)) return T('pwdShort');
    return (err && err.message) || String(err);
  }
  function langSwitch() {
    return '<div class="lang-sw"><button data-lang="en" class="' + (I18N.lang === 'en' ? 'on' : '') + '">EN</button><button data-lang="hi" class="' + (I18N.lang === 'hi' ? 'on' : '') + '">हिं</button></div>';
  }
  function bindLang() {
    U.$$('[data-lang]').forEach((b) => b.onclick = () => { I18N.set(b.dataset.lang); if (S.user) { renderShell(); App.go(S.view, S.params); } else renderLogin(); });
  }

  // ---------- shell ----------
  const EMP_NAV = [{ v: 'empHome', i: '🏠', k: 'home' }, { v: 'actList', i: '📋', k: 'activities' }, { v: 'actNew', i: '➕', k: 'newActivity' }, { v: 'enqList', i: '🙋', k: 'enquiries' }, { v: 'empMore', i: '☰', k: 'more' }];
  const ADMIN_NAV = [{ v: 'adminDashboard', i: '📊', k: 'dashboard' }, { v: 'actList', i: '📋', k: 'activities' }, { v: 'enqList', i: '🙋', k: 'enquiries' }, { v: 'reports', i: '📑', k: 'reports' }, { v: '_menu', i: '☰', k: 'menu' }];
  const ADMIN_MENU = [
    { v: 'adminDashboard', i: '📊', k: 'dashboard' }, { v: 'actList', i: '📋', k: 'activities' }, { v: 'actNew', i: '➕', k: 'newActivity' },
    { v: 'enqList', i: '🙋', k: 'enquiries' }, { v: 'reports', i: '📑', k: 'reports' }, { v: 'adminTeam', i: '👥', k: 'fieldTeam' },
    { v: 'adminTypes', i: '🗂️', k: 'activityTypes' }, { v: 'adminRules', i: '✅', k: 'rules' }
  ];
  function renderShell() {
    const nav = S.isAdmin ? ADMIN_NAV : EMP_NAV;
    root().innerHTML =
      '<header class="topbar"><div class="brand" onclick="App.go(\'' + (S.isAdmin ? 'adminDashboard' : 'empHome') + '\')"><img src="img/logo.png" alt=""><div><b>' + esc(APP_INFO.showroom) +
      '</b><small>📍 ' + esc(APP_INFO.appName) + ' · ' + (S.isAdmin ? T('adminPanel') : esc(FA.myName())) + '</small></div></div><div class="top-actions">' + langSwitch() + '</div></header>' +
      (S.isAdmin ? '<aside id="drawer" class="drawer"><div class="drawer-head"><b>' + esc(FA.myName()) + '</b><small>' + esc(S.user.email || '') + '</small></div>' +
        ADMIN_MENU.map((m) => '<a data-go="' + m.v + '"><span>' + m.i + '</span>' + T(m.k) + '</a>').join('') +
        '<a data-go="changePassword"><span>🔑</span>' + T('changePassword') + '</a><a onclick="App.logout()"><span>🚪</span>' + T('logout') + '</a></aside><div id="drawerBg" class="drawer-bg"></div>' : '') +
      '<main id="view" class="view"></main><nav class="bottomnav">' + nav.map((n) => '<a data-go="' + n.v + '"><span>' + n.i + '</span><small>' + T(n.k) + '</small></a>').join('') + '</nav>';
    bindLang();
    U.$$('[data-go]').forEach((a) => a.onclick = () => { if (a.dataset.go === '_menu') return drawer(true); drawer(false); App.go(a.dataset.go); });
    const bg = U.$('#drawerBg'); if (bg) bg.onclick = () => drawer(false);
  }
  function drawer(on) { const d = U.$('#drawer'), bg = U.$('#drawerBg'); if (!d) return; d.classList.toggle('open', on); bg.classList.toggle('open', on); }

  App.go = async function (view, params) {
    S.view = view; S.params = params || null;
    U.$$('.modal-wrap').forEach((m) => m.remove());
    const el = U.$('#view'); if (!el) return;
    U.$$('.bottomnav a, .drawer a').forEach((a) => a.classList.toggle('on', a.dataset.go === view));
    const fn = V[view];
    if (!fn) { el.innerHTML = U.empty('Not found: ' + view); return; }
    el.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    window.scrollTo(0, 0);
    try { await fn(el, params || {}); }
    catch (e) { console.error(e); el.innerHTML = '<div class="card"><h3>' + T('error') + '</h3><p>' + esc(e.message || e) + '</p><button class="btn" onclick="App.go(S.view,S.params)">' + T('retry') + '</button></div>'; }
  };
  App.refresh = () => App.go(S.view, S.params);
  App.logout = async function () { if (await U.confirm(T('logoutConfirm'), T('logout'))) await DB.signOut(); };
  App.avatar = function (e, size) {
    size = size || 40;
    if (e && e.photo) return '<img class="avatar" style="width:' + size + 'px;height:' + size + 'px" src="' + esc(e.photo) + '" alt="">';
    const ini = String((e && e.name) || '?').split(' ').map((x) => x[0]).slice(0, 2).join('').toUpperCase();
    return '<span class="avatar ph" style="width:' + size + 'px;height:' + size + 'px;font-size:' + Math.round(size / 2.6) + 'px">' + esc(ini) + '</span>';
  };

  V.changePassword = async function (el) {
    el.innerHTML = '<h2 class="page-title">' + T('changePassword') + '</h2><form id="cpf" class="card form">' + U.field('old', T('oldPassword'), '', { type: 'password', required: true }) +
      U.field('n1', T('newPassword'), '', { type: 'password', required: true }) + U.field('n2', T('confirmPassword'), '', { type: 'password', required: true }) + '<button class="btn block">' + T('save') + '</button></form>';
    U.$('#cpf').onsubmit = async (e) => {
      e.preventDefault(); const d = U.formData(e.target);
      if (d.n1.length < 6) return U.toast(T('pwdShort'), 'err');
      if (d.n1 !== d.n2) return U.toast(T('pwdMismatch'), 'err');
      U.loading(true);
      try { await DB.changePassword(d.old, d.n1); U.toast(T('saved'), 'ok'); App.go(S.isAdmin ? 'adminDashboard' : 'empMore'); } catch (err) { U.toast(authErr(err), 'err'); } finally { U.loading(false); }
    };
  };

  V.empMore = async function (el) {
    const m = S.member || {};
    el.innerHTML = '<div class="card hello">' + App.avatar(m, 56) + '<div><h2>' + esc(m.name) + '</h2><small>' + esc(m.id) + ' · ' + esc(m.designation || '') + '</small><br><small>' + T('role_' + (m.role || 'staff')) + '</small></div></div>' +
      '<div class="card menu-list">' +
      '<a data-g="actList">📋 ' + T('myActivities') + '<i>›</i></a><a data-g="enqList">🙋 ' + T('enquiries') + '<i>›</i></a>' +
      (S.cfg.empReports ? '<a data-g="reports">📑 ' + T('reports') + '<i>›</i></a>' : '') +
      '<a data-g="changePassword">🔑 ' + T('changePassword') + '<i>›</i></a><a id="lo">🚪 ' + T('logout') + '<i>›</i></a></div><p class="muted small center">v' + APP_INFO.version + '</p>';
    U.$$('[data-g]', el).forEach((a) => a.onclick = () => App.go(a.dataset.g));
    U.$('#lo').onclick = App.logout;
  };

  // ---------- GPS ----------
  FA.gps = async function () {
    U.loading(true, T('gettingLocation'));
    try {
      const loc = await U.getLocation();
      if (loc.mocked && S.cfg.blockMock) throw new Error(T('mockBlocked'));
      return loc;
    } finally { U.loading(false); }
  };
  FA.mapUrl = (lat, lng) => 'https://www.google.com/maps?q=' + lat + ',' + lng;
  FA.gpsText = (g) => (g && g.lat != null ? Number(g.lat).toFixed(6) + ', ' + Number(g.lng).toFixed(6) + (g.acc ? ' (±' + g.acc + 'm)' : '') : '-');
  FA.dist = (a, b) => (a && b && a.lat != null && b.lat != null ? U.distance(a.lat, a.lng, b.lat, b.lng) : null);
  FA.distText = (d) => (d == null ? '' : d >= 1000 ? (d / 1000).toFixed(1) + ' ' + T('km') : d + ' ' + T('m'));
  FA.openMap = (lat, lng) => { try { window.open(FA.mapUrl(lat, lng), '_blank'); } catch (e) { } };

  // ---------- Camera: live photo with GPS watermark ----------
  // returns {data, thumb, lat, lng, acc, at} or null
  FA.capturePhoto = function (info, fromGallery) {
    return new Promise(async (resolve) => {
      let loc;
      try { loc = await FA.gps(); } catch (e) { U.toast(e.message, 'err'); return resolve(null); }
      const at = new Date();
      const stamp = (ctx, w, h) => {
        const lines = [(info.title || ''), U.fmtDate(at) + ' ' + U.fmtTime(at) + ' · ' + FA.myName(), 'GPS ' + loc.lat.toFixed(6) + ', ' + loc.lng.toFixed(6) + ' (±' + loc.acc + 'm)', (info.place || '')].filter(Boolean);
        const fs = Math.max(14, Math.round(w / 38));
        const bh = fs * (lines.length * 1.3 + 0.8);
        ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(0, h - bh, w, bh);
        ctx.fillStyle = '#DA251D'; ctx.fillRect(0, h - bh, Math.max(6, fs * 0.35), bh);
        ctx.fillStyle = '#fff'; ctx.font = 'bold ' + fs + 'px sans-serif';
        lines.forEach((t, i) => ctx.fillText(t, fs * 0.9, h - bh + fs * 1.3 * (i + 1)));
      };
      const finish = (canvas) => {
        const t = document.createElement('canvas'); const sc = 260 / Math.max(canvas.width, canvas.height);
        t.width = Math.round(canvas.width * sc); t.height = Math.round(canvas.height * sc); t.getContext('2d').drawImage(canvas, 0, 0, t.width, t.height);
        resolve({ data: canvas.toDataURL('image/jpeg', 0.7), thumb: t.toDataURL('image/jpeg', 0.6), w: canvas.width, h: canvas.height, lat: loc.lat, lng: loc.lng, acc: loc.acc, mocked: !!loc.mocked, at: at.getTime() });
      };
      const fromFile = (f) => {
        if (!f) return resolve(null);
        U.compressImage(f, 1280, 0.85).then((url) => {
          const img = new Image();
          img.onload = () => { const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0); stamp(ctx, c.width, c.height); finish(c); };
          img.src = url;
        }).catch(() => resolve(null));
      };
      const fileInput = (capture) => {
        const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; if (capture) inp.setAttribute('capture', 'environment');
        inp.style.display = 'none'; document.body.appendChild(inp);
        inp.onchange = () => { const f = inp.files && inp.files[0]; inp.remove(); fromFile(f); };
        inp.click();
      };
      if (fromGallery) return fileInput(false);
      let stream = null;
      try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 960 } }, audio: false }); } catch (e) { stream = null; }
      if (!stream) return fileInput(true);
      let done = false;
      const m = U.modal('📸 ' + T('takePhoto'), '<div class="cam back"><video autoplay playsinline muted></video></div><p class="muted small center">📍 ' + esc(FA.gpsText(loc)) + '</p>' +
        '<button class="btn block" data-snap>📸 ' + T('capture') + '</button>', { sticky: true, onClose: () => { stream.getTracks().forEach((t) => t.stop()); if (!done) resolve(null); } });
      const video = m.el.querySelector('video'); video.srcObject = stream;
      m.el.querySelector('[data-snap]').onclick = () => {
        const vw = video.videoWidth || 1280, vh = video.videoHeight || 960; const sc = Math.min(1, 1280 / Math.max(vw, vh));
        const w = Math.round(vw * sc), h = Math.round(vh * sc);
        const c = document.createElement('canvas'); c.width = w; c.height = h; const ctx = c.getContext('2d');
        ctx.drawImage(video, 0, 0, w, h); stamp(ctx, w, h);
        done = true; stream.getTracks().forEach((t) => t.stop()); m.el.remove(); finish(c);
      };
    });
  };

  FA.viewPhoto = async function (p) {
    let data = null;
    U.loading(true); try { const d = await DB.get('fa_photodata', p.id); data = d && d.data; } catch (e) { } finally { U.loading(false); }
    U.modal(p.empName + ' · ' + U.fmtDT(p.at), '<img src="' + esc(data || p.thumb) + '" style="width:100%;border-radius:10px">' +
      '<div class="kv small" style="margin-top:8px"><div><span>GPS</span><b>' + esc(FA.gpsText(p)) + '</b></div>' + (p.caption ? '<div><span>' + T('caption') + '</span><b>' + esc(p.caption) + '</b></div>' : '') + '</div>' +
      '<div class="row-btns"><button class="btn ghost sm" data-map>📍 ' + T('openMap') + '</button>' + (data ? '<button class="btn sm" data-dl>⬇️ ' + T('photo') + '</button>' : '') + '</div>', {
      wide: true, onOpen: (w) => {
        w.querySelector('[data-map]').onclick = () => FA.openMap(p.lat, p.lng);
        const dl = w.querySelector('[data-dl]'); if (dl) dl.onclick = () => U.openDataUrl('Photo_' + p.id + '.jpg', data);
      }
    });
  };

  // multi-member picker
  FA.pickerHtml = function (id, selected, opts) {
    opts = opts || {};
    const sel = new Set(selected || []);
    const list = S.members.filter((m) => m.active !== false && !(opts.exclude || []).includes(m.id));
    return '<div class="pick-list" id="' + id + '">' + (list.length ? list.map((m) => '<label class="chk"><input type="checkbox" value="' + esc(m.id) + '"' + (sel.has(m.id) ? ' checked' : '') + '> <span>' +
      esc(m.name) + ' <small class="muted">' + esc(m.id) + ' · ' + T('role_' + (m.role || 'staff')) + '</small></span></label>').join('') : U.empty()) + '</div>';
  };
  FA.readPicker = (id) => U.$$('#' + id + ' input:checked').map((i) => i.value);

  document.addEventListener('DOMContentLoaded', App.start);
  document.addEventListener('backbutton', () => { const m = U.$$('.modal-wrap'); if (m.length) m[m.length - 1].remove(); });
})();
