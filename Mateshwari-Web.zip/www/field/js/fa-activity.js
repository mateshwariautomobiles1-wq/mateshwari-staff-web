// ---------- Activities, photos, enquiries ----------
(function () {
  const V = window.Views, esc = U.esc;
  const today = () => U.dateKey(new Date());
  const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return U.dateKey(d); };
  const monthStart = () => U.monthKey(new Date()) + '-01';

  FA.actTitle = (a) => (a.typeIcon || '📍') + ' ' + (a.typeName || '') + (a.area ? ' – ' + a.area : '');
  FA.place = (a) => [a.location, a.area].filter(Boolean).join(', ');
  FA.canEdit = (a) => ['draft', 'rejected'].includes(a.status) && (S.isAdmin || (a.members || []).includes(FA.myId()));
  FA.actByRange = async function (from, to) {
    const list = await DB.query('fa_activities', [['date', '>=', from], ['date', '<=', to]]);
    return list.sort((a, b) => (b.date + (b.startAt || 0)).localeCompare(a.date + (a.startAt || 0)) || ((b.startAt || 0) - (a.startAt || 0)));
  };
  FA.visible = (list, scope) => {
    if (S.isAdmin) return list;
    if (scope === 'team' && S.cfg.empSeeAll) return list;
    return list.filter((a) => (a.members || []).includes(FA.myId()));
  };

  FA.actCard = function (a) {
    return '<div class="card act-card" data-act="' + esc(a.id) + '"><div class="row-between"><b>' + esc(FA.actTitle(a)) + '</b>' + U.badge(a.status) + '</div>' +
      '<small class="muted">📅 ' + U.fmtDate(a.date) + (a.startAt ? ' · ' + U.fmtTime(a.startAt) : '') + ' · 📍 ' + esc(FA.place(a) || '-') + '</small>' +
      '<div class="act-meta"><span>👤 ' + esc(a.leaderName || a.createdByName || '-') + (a.team && a.team.length ? ' +' + a.team.length : '') + '</span><span>📸 ' + (a.photoCount || 0) + '</span><span>🙋 ' + (a.enqCount || 0) + '</span></div></div>';
  };
  FA.bindActCards = (el) => U.$$('[data-act]', el).forEach((c) => c.onclick = () => App.go('actView', { id: c.dataset.act }));

  // ---------- Employee home ----------
  V.empHome = async function (el) {
    const m = S.member;
    const list = FA.visible(await FA.actByRange(monthStart(), today()), 'mine');
    const tday = list.filter((a) => a.date === today());
    const open = list.filter((a) => ['draft', 'rejected'].includes(a.status));
    const enq = (await DB.query('fa_enquiries', [['empId', '==', FA.myId()]])).filter((x) => (x.date || '') >= monthStart());
    el.innerHTML = '<div class="card hello">' + App.avatar(m, 52) + '<div><small>' + T('hello') + ',</small><h2>' + esc(m.name) + '</h2><small>' + esc(m.id) + ' · ' + T('role_' + (m.role || 'staff')) + '</small></div></div>' +
      (FA.canCreate() ? '<button class="big-btn in" id="startAct"><span>➕</span>' + T('startActivity') + '</button>' : '') +
      '<div class="stats4"><div class="card center"><b>' + list.length + '</b><small>' + T('activities') + '</small></div><div class="card center"><b>' + list.reduce((s, a) => s + (a.photoCount || 0), 0) +
      '</b><small>' + T('photos') + '</small></div><div class="card center"><b>' + enq.length + '</b><small>' + T('enquiries') + '</small></div><div class="card center"><b class="low">' + enq.filter((x) => x.enqType === 'hot').length +
      '</b><small>' + T('hot') + '</small></div></div><p class="muted small center" style="margin-top:-6px">' + T('thisMonth') + '</p>' +
      (open.length ? '<h3 class="sec-title">⏳ ' + T('st_draft') + ' / ' + T('st_rejected') + '</h3>' + open.map(FA.actCard).join('') : '') +
      '<h3 class="sec-title">' + T('todaysActivities') + '</h3>' + (tday.length ? tday.map(FA.actCard).join('') : U.empty());
    const b = U.$('#startAct'); if (b) b.onclick = () => App.go('actNew');
    FA.bindActCards(el);
  };

  // ---------- Activity list ----------
  V.actList = async function (el, p) {
    const st = Object.assign({ range: 'today', from: today(), to: today(), status: 'all', type: 'all', scope: S.isAdmin ? 'team' : 'mine', q: '' }, S._actFilter || {}, p || {});
    S._actFilter = st;
    const ranges = { today: [today(), today()], d7: [addDays(-6), today()], month: [monthStart(), today()] };
    if (ranges[st.range]) { st.from = ranges[st.range][0]; st.to = ranges[st.range][1]; }
    let list = FA.visible(await FA.actByRange(st.from, st.to), st.scope);
    if (st.status !== 'all') list = list.filter((a) => a.status === st.status);
    if (st.type !== 'all') list = list.filter((a) => a.typeId === st.type);
    if (st.q) { const q = st.q.toLowerCase(); list = list.filter((a) => [a.area, a.location, a.leaderName, a.createdByName, a.typeName].concat(a.teamNames || []).join(' ').toLowerCase().includes(q)); }
    const chip = (k, v, lab) => '<button class="chip' + (st[k] === v ? ' on' : '') + '" data-f="' + k + '" data-v="' + v + '">' + esc(lab) + '</button>';
    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + T('activities') + '</h2>' + (FA.canCreate() ? '<button class="btn sm" id="na">➕ ' + T('newActivity') + '</button>' : '') + '</div>' +
      (!S.isAdmin && S.cfg.empSeeAll ? '<div class="tabs"><button data-f="scope" data-v="mine" class="' + (st.scope === 'mine' ? 'on' : '') + '">' + T('mine') + '</button><button data-f="scope" data-v="team" class="' + (st.scope === 'team' ? 'on' : '') + '">' + T('teamAll') + '</button></div>' : '') +
      '<div class="chips">' + chip('range', 'today', T('today')) + chip('range', 'd7', '7 ' + (I18N.lang === 'hi' ? 'दिन' : 'days')) + chip('range', 'month', T('thisMonth')) + chip('range', 'custom', '📅 ' + T('from') + '–' + T('to')) + '</div>' +
      (st.range === 'custom' ? '<div class="grid2f"><label class="fld"><span>' + T('from') + '</span><input type="date" id="f1" value="' + st.from + '"></label><label class="fld"><span>' + T('to') + '</span><input type="date" id="f2" value="' + st.to + '"></label></div>' : '') +
      '<div class="chips">' + chip('status', 'all', T('all')) + ['draft', 'submitted', 'approved', 'rejected'].map((s) => chip('status', s, T('st_' + s))).join('') + '</div>' +
      '<div class="grid2f"><select class="month-sel" id="ft"><option value="all">' + T('allTypes') + '</option>' + FA.types(true).map((t) => '<option value="' + t.id + '"' + (st.type === t.id ? ' selected' : '') + '>' + esc(t.icon + ' ' + t.name) + '</option>').join('') + '</select>' +
      '<input class="search" id="fq" placeholder="🔍 ' + T('search') + '" value="' + esc(st.q) + '"></div>' +
      '<p class="muted small">' + U.fmtDate(st.from) + ' → ' + U.fmtDate(st.to) + ' · ' + list.length + ' ' + T('activities') + '</p>' +
      (list.length ? list.map(FA.actCard).join('') : U.empty(T('noActivities')));
    const set = (o) => App.go('actList', Object.assign({}, st, o));
    U.$$('[data-f]', el).forEach((b) => b.onclick = () => set({ [b.dataset.f]: b.dataset.v }));
    const f1 = U.$('#f1'), f2 = U.$('#f2');
    if (f1) { f1.onchange = () => set({ from: f1.value }); f2.onchange = () => set({ to: f2.value }); }
    U.$('#ft').onchange = (e) => set({ type: e.target.value });
    U.$('#fq').onchange = (e) => set({ q: e.target.value.trim() });
    const na = U.$('#na'); if (na) na.onclick = () => App.go('actNew');
    FA.bindActCards(el);
  };

  // ---------- Create / edit ----------
  function customFieldHtml(f, val) {
    const name = 'cf_' + f.key, req = { required: false };
    if (f.type === 'select') return U.field(name, f.label + (f.required ? ' *' : ''), val, Object.assign(req, { type: 'select', options: [{ v: '', l: '— ' + T('select') + ' —' }].concat(String(f.options || '').split(',').map((x) => x.trim()).filter(Boolean)) }));
    if (f.type === 'yesno') return U.field(name, f.label + (f.required ? ' *' : ''), val, Object.assign(req, { type: 'select', options: [{ v: '', l: '— ' + T('select') + ' —' }, { v: 'Yes', l: T('yes') }, { v: 'No', l: T('no') }] }));
    return U.field(name, f.label + (f.required ? ' *' : ''), val, Object.assign(req, { type: f.type === 'textarea' ? 'textarea' : f.type === 'number' ? 'number' : 'text', step: 'any' }));
  }
  V.actNew = (el) => V.actEdit(el, {});
  V.actEdit = async function (el, p) {
    if (!FA.canCreate() && !p.id) { el.innerHTML = '<div class="note">' + T('notAllowedCreate') + '</div>'; return; }
    const a = p.id ? await DB.get('fa_activities', p.id) : null;
    if (a && !FA.canEdit(a)) return App.go('actView', { id: a.id });
    const cfg = S.cfg, core = cfg.core;
    const types = FA.types(); if (a && !types.find((t) => t.id === a.typeId) && FA.type(a.typeId)) types.push(FA.type(a.typeId));
    const x = a || { date: today(), typeId: types[0] && types[0].id, leaderId: S.isAdmin ? '' : (S.member.role === 'leader' ? S.member.id : ''), team: [], fields: {} };
    const lab = (k, key) => T(k) + (core[key] ? ' *' : '');
    const areas = FA.areas();
    const leaders = S.members.filter((m) => m.active !== false).sort((m1, m2) => (m1.role === 'leader' ? 0 : 1) - (m2.role === 'leader' ? 0 : 1));
    el.innerHTML = '<h2 class="page-title">' + (a ? '✏️ ' + T('edit') : '➕ ' + T('newActivity')) + '</h2><form id="af" class="form">' +
      '<div class="card">' + U.field('date', T('date') + ' *', x.date, { type: 'date' }) +
      '<label class="fld"><span>' + T('activityType') + ' *</span><div class="type-grid">' + types.map((t) => '<label class="type-opt"><input type="radio" name="typeId" value="' + esc(t.id) + '"' + (x.typeId === t.id ? ' checked' : '') + '><span><i>' + esc(t.icon || '📍') + '</i>' + esc(t.name) + '</span></label>').join('') + '</div></label>' +
      (areas.length ? U.field('area', lab('area', 'area'), x.area, { type: 'select', options: [{ v: '', l: '— ' + T('select') + ' —' }].concat(areas, x.area && !areas.includes(x.area) ? [x.area] : []) }) : U.field('area', lab('area', 'area'), x.area)) +
      U.field('location', lab('location', 'location'), x.location) + U.field('landmark', lab('landmark', 'landmark'), x.landmark) + '</div>' +
      '<div class="card"><h3>👥 ' + T('team') + '</h3>' +
      U.field('leaderId', lab('leader', 'leader'), x.leaderId, { type: 'select', options: [{ v: '', l: '— ' + T('select') + ' —' }].concat(leaders.map((m) => ({ v: m.id, l: m.name + ' (' + m.id + ') · ' + T('role_' + (m.role || 'staff')) }))) }) +
      '<span class="small muted">' + lab('team', 'team') + '</span>' + FA.pickerHtml('teamPick', x.team) + '</div>' +
      '<div class="card">' + U.field('plan', lab('plan', 'plan'), x.plan, { type: 'textarea', rows: 3 }) + U.field('target', lab('target', 'target'), x.target) + '<div id="cfs"></div></div>' +
      '<button class="btn block" type="submit">' + (a ? '💾 ' + T('save') : '📍 ' + T('createActivity')) + '</button>' + (a ? '' : '<p class="muted small center">📍 ' + T('startGps') + ' ' + T('autoFilled') + '</p>') + '</form>';
    const renderCF = () => {
      const tid = (U.$('input[name=typeId]:checked', el) || {}).value; const t = FA.type(tid);
      U.$('#cfs').innerHTML = t && t.fields && t.fields.length ? '<h3>' + esc(t.icon + ' ' + t.name) + '</h3>' + t.fields.map((f) => customFieldHtml(f, (x.fields || {})[f.key])).join('') : '';
    };
    U.$$('input[name=typeId]', el).forEach((r) => r.onchange = renderCF); renderCF();
    U.$('#af').onsubmit = async (e) => {
      e.preventDefault();
      const d = U.formData(e.target); d.typeId = (U.$('input[name=typeId]:checked', e.target) || {}).value || ''; const t = FA.type(d.typeId);
      if (!t) return U.toast(T('isRequired', { f: T('activityType') }), 'err');
      const team = FA.readPicker('teamPick').filter((id) => id !== d.leaderId);
      for (const k of ['area', 'location', 'landmark', 'plan', 'target']) if (core[k] && !d[k]) return U.toast(T('isRequired', { f: T(k) }), 'err');
      if (core.leader && !d.leaderId) return U.toast(T('isRequired', { f: T('leader') }), 'err');
      if (core.team && !team.length) return U.toast(T('isRequired', { f: T('team') }), 'err');
      const fields = {}; (t.fields || []).forEach((f) => { const v = d['cf_' + f.key]; fields[f.key] = v === undefined ? '' : v; });
      const leader = FA.member(d.leaderId);
      const creator = a ? a.createdBy : FA.myId();
      const members = Array.from(new Set([creator, d.leaderId].concat(team).filter((v) => v && v !== 'admin')));
      const data = { date: d.date, month: d.date.slice(0, 7), typeId: t.id, typeName: t.name, typeIcon: t.icon || '📍', area: d.area || '', location: d.location || '', landmark: d.landmark || '',
        leaderId: d.leaderId || '', leaderName: leader ? leader.name : '', team, teamNames: team.map((id) => (FA.member(id) || {}).name || id), plan: d.plan || '', target: d.target || '', fields, members, updatedAt: Date.now() };
      U.loading(true);
      try {
        if (a) { await DB.update('fa_activities', a.id, data); U.toast(T('saved'), 'ok'); App.go('actView', { id: a.id }); return; }
        U.loading(false);
        let g; try { g = await FA.gps(); } catch (err) { return U.toast(err.message, 'err'); }
        U.loading(true);
        const id = U.uid();
        await DB.set('fa_activities', id, Object.assign(data, { status: 'draft', createdBy: creator, createdByName: FA.myName(), createdAt: Date.now(), startAt: Date.now(),
          startGps: { lat: g.lat, lng: g.lng, acc: g.acc }, photoCount: 0, enqCount: 0 }));
        U.toast(T('saved'), 'ok'); App.go('actView', { id });
      } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    };
  };

  // ---------- Activity detail ----------
  FA.validate = function (a, photos, enqs) {
    const miss = [], core = S.cfg.core, t = FA.type(a.typeId) || { fields: [], minPhotos: 1, minEnquiries: 0 };
    ['area', 'location', 'landmark', 'plan', 'target'].forEach((k) => { if (core[k] && !a[k]) miss.push(T('isRequired', { f: T(k) })); });
    if (core.leader && !a.leaderId) miss.push(T('isRequired', { f: T('leader') }));
    if (core.team && !(a.team || []).length) miss.push(T('isRequired', { f: T('team') }));
    (t.fields || []).forEach((f) => { const v = (a.fields || {})[f.key]; if (f.required && (v === '' || v == null)) miss.push(T('isRequired', { f: f.label })); });
    const minP = Math.max(1, parseInt(t.minPhotos) || 1);
    if (photos.length < minP) miss.push(T('minPhotosMsg', { n: minP, c: photos.length }));
    const minE = parseInt(t.minEnquiries) || 0;
    if (minE && enqs.length < minE) miss.push(T('minEnqMsg', { n: minE, c: enqs.length }));
    return miss;
  };

  V.actView = async function (el, p) {
    const a = await DB.get('fa_activities', p.id);
    if (!a) { el.innerHTML = U.empty(); return; }
    const [photos, enqs] = await Promise.all([DB.query('fa_photos', [['activityId', '==', a.id]]), DB.query('fa_enquiries', [['activityId', '==', a.id]])]);
    photos.sort((x, y) => (x.at || 0) - (y.at || 0)); enqs.sort((x, y) => (x.at || 0) - (y.at || 0));
    const t = FA.type(a.typeId) || { fields: [] };
    const editable = FA.canEdit(a);
    const miss = FA.validate(a, photos, enqs);
    const kv = (k, v) => (v || v === 0) && v !== '' ? '<div><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>' : '';
    const flabel = (k) => ((t.fields || []).find((f) => f.key === k) || {}).label || k;
    const dur = a.endAt && a.startAt ? Math.round((a.endAt - a.startAt) / 60000) : null;
    const canPdf = S.isAdmin || S.cfg.empReports;
    const cnt = { hot: 0, warm: 0, cold: 0, exch: 0 }; enqs.forEach((q) => { cnt[q.enqType] = (cnt[q.enqType] || 0) + 1; if (q.exchange === 'Yes') cnt.exch++; });
    el.innerHTML = '<button class="btn ghost sm" id="bk">← ' + T('back') + '</button>' +
      '<div class="card" style="margin-top:10px"><div class="row-between"><h2 style="margin:0">' + esc(FA.actTitle(a)) + '</h2>' + U.badge(a.status) + '</div>' +
      (a.remark ? '<div class="note" style="margin-top:8px">💬 ' + esc(a.remark) + (a.reviewedBy ? ' — ' + esc(a.reviewedBy) : '') + '</div>' : '') +
      '<div class="kv">' + kv(T('date'), U.fmtDate(a.date)) + kv(T('area'), a.area) + kv(T('location'), a.location) + kv(T('landmark'), a.landmark) +
      kv(T('leader'), a.leaderName) + kv(T('team'), (a.teamNames || []).join(', ')) + kv(T('plan'), a.plan) + kv(T('target'), a.target) +
      Object.keys(a.fields || {}).map((k) => kv(flabel(k), a.fields[k])).join('') + kv(T('createdBy'), a.createdByName) +
      '<div><span>' + T('startedAt') + '</span><b>' + U.fmtTime(a.startAt) + (a.startGps ? ' · <a data-map="' + a.startGps.lat + ',' + a.startGps.lng + '">📍 ' + T('openMap') + '</a>' : '') + '</b></div>' +
      (a.endAt ? '<div><span>' + T('endedAt') + '</span><b>' + U.fmtTime(a.endAt) + (a.endGps ? ' · <a data-map="' + a.endGps.lat + ',' + a.endGps.lng + '">📍 ' + T('openMap') + '</a>' : '') + '</b></div>' : '') +
      (dur != null ? kv(T('duration'), Math.floor(dur / 60) + 'h ' + (dur % 60) + 'm') : '') + '</div>' +
      '<div class="row-btns left">' + (editable ? '<button class="btn ghost sm" id="ed">✏️ ' + T('edit') + '</button>' : '') + (canPdf ? '<button class="btn ghost sm" id="pdf">📄 ' + T('downloadPdf') + '</button>' : '') +
      (S.isAdmin ? '<button class="btn ghost sm danger-t" id="del">🗑️ ' + T('delete') + '</button>' : '') + '</div></div>' +
      // photos
      '<div class="card"><div class="row-between"><h3>📸 ' + T('photos') + ' (' + photos.length + (t.minPhotos ? ' / min ' + t.minPhotos : '') + ')</h3>' +
      (editable ? '<div class="row"><button class="btn sm" id="tp">📸 ' + T('takePhoto') + '</button>' + (S.cfg.allowGallery || S.isAdmin ? '<button class="btn ghost sm" id="gp">🖼️</button>' : '') + '</div>' : '') + '</div>' +
      (photos.length ? '<div class="ph-grid">' + photos.map((ph) => { const d = FA.dist(a.startGps, ph); return '<div class="ph" data-ph="' + esc(ph.id) + '"><img src="' + esc(ph.thumb) + '" alt=""><small>' + esc(ph.empName) + '<br>' + U.fmtTime(ph.at) +
        (d != null ? ' · ' + FA.distText(d) : '') + '</small>' + (editable && (S.isAdmin || ph.empId === FA.myId()) ? '<button class="ph-del" data-pdel="' + esc(ph.id) + '">✕</button>' : '') + '</div>'; }).join('') + '</div>' : '<div class="note">' + T('noPhotos') + '</div>') + '</div>' +
      // enquiries
      (t.enquiries !== false || enqs.length ? '<div class="card"><div class="row-between"><h3>🙋 ' + T('enquiries') + ' (' + enqs.length + ')</h3>' + (editable && t.enquiries !== false ? '<button class="btn sm" id="ae">➕ ' + T('addEnquiry') + '</button>' : '') + '</div>' +
        (enqs.length ? '<p class="small"><span class="badge bad">' + T('hot') + ' ' + cnt.hot + '</span> <span class="badge warn">' + T('warm') + ' ' + cnt.warm + '</span> <span class="badge info">' + T('cold') + ' ' + cnt.cold + '</span> <span class="badge muted">' + T('exchange') + ' ' + cnt.exch + '</span></p>' +
          '<div class="list" style="padding:0">' + enqs.map(FA.enqRow).join('') + '</div>' : '<p class="muted small">' + T('noData') + '</p>') + '</div>' : '') +
      // submit / approval
      (editable ? '<div class="card">' + (miss.length ? '<div class="note"><b>' + T('missingItems') + '</b><br>• ' + miss.map(esc).join('<br>• ') + '</div>' : '') +
        '<button class="btn block" id="sub"' + (miss.length ? ' disabled style="opacity:.5"' : '') + '>✅ ' + T('submitActivity') + '</button></div>' : '') +
      (S.isAdmin && a.status === 'submitted' ? '<div class="card row-btns"><button class="btn danger" id="rj">✕ ' + T('reject') + '</button><button class="btn" id="ap">✓ ' + T('approve') + '</button></div>' : '') +
      (S.isAdmin && ['approved', 'submitted'].includes(a.status) ? '<button class="btn ghost block" id="ro">↺ ' + T('reopen') + '</button>' : '');

    U.$('#bk').onclick = () => App.go(S.isAdmin || S._actFilter ? 'actList' : 'empHome');
    U.$$('[data-map]', el).forEach((x) => x.onclick = () => { const [la, ln] = x.dataset.map.split(','); FA.openMap(la, ln); });
    U.$$('[data-ph]', el).forEach((x) => x.onclick = (ev) => { if (ev.target.dataset.pdel) return; FA.viewPhoto(photos.find((ph) => ph.id === x.dataset.ph)); });
    U.$$('[data-pdel]', el).forEach((b) => b.onclick = async (ev) => {
      ev.stopPropagation(); if (!(await U.confirm(T('deletePhotoConfirm'), T('delete')))) return;
      U.loading(true); try { await DB.del('fa_photos', b.dataset.pdel); await DB.del('fa_photodata', b.dataset.pdel); await DB.update('fa_activities', a.id, { photoCount: DB.inc(-1) }); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      App.refresh();
    });
    const ed = U.$('#ed'); if (ed) ed.onclick = () => App.go('actEdit', { id: a.id });
    const pdf = U.$('#pdf'); if (pdf) pdf.onclick = () => FA.activityPdf([a], { title: FA.actTitle(a), file: 'Activity_' + a.date + '_' + (a.typeName || '').replace(/\W+/g, '_') });
    const del = U.$('#del'); if (del) del.onclick = async () => {
      if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return;
      U.loading(true);
      try { for (const ph of photos) { await DB.del('fa_photos', ph.id); await DB.del('fa_photodata', ph.id); } for (const q of enqs) await DB.del('fa_enquiries', q.id); await DB.del('fa_activities', a.id); U.toast(T('deleted'), 'ok'); App.go('actList'); }
      catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
    const addPhoto = async (gallery) => {
      const r = await FA.capturePhoto({ title: a.typeName, place: FA.place(a) }, gallery); if (!r) return;
      const caption = await U.prompt(T('photo'), T('caption'), '');
      U.loading(true);
      try {
        const id = U.uid();
        await DB.set('fa_photodata', id, { activityId: a.id, empId: FA.myId(), data: r.data });
        await DB.set('fa_photos', id, { activityId: a.id, date: a.date, typeName: a.typeName, empId: FA.myId(), empName: FA.myName(), lat: r.lat, lng: r.lng, acc: r.acc, mocked: r.mocked, at: r.at,
          thumb: r.thumb, caption: caption || '', gallery: !!gallery });
        await DB.update('fa_activities', a.id, { photoCount: DB.inc(1) });
        U.toast(T('photoSaved'), 'ok');
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      App.refresh();
    };
    const tp = U.$('#tp'); if (tp) tp.onclick = () => addPhoto(false);
    const gp = U.$('#gp'); if (gp) gp.onclick = () => addPhoto(true);
    const ae = U.$('#ae'); if (ae) ae.onclick = () => FA.enqForm(a, null, App.refresh);
    FA.bindEnqRows(el, enqs, App.refresh);
    const sub = U.$('#sub'); if (sub) sub.onclick = async () => {
      if (miss.length) return;
      if (!(await U.confirm(T('submitConfirm'), T('submitActivity')))) return;
      let g = null;
      if (S.cfg.endGps) { try { g = await FA.gps(); } catch (e) { return U.toast(e.message, 'err'); } }
      U.loading(true);
      try {
        await DB.update('fa_activities', a.id, { status: S.cfg.requireApproval ? 'submitted' : 'approved', endAt: Date.now(), endGps: g ? { lat: g.lat, lng: g.lng, acc: g.acc } : null, submittedAt: Date.now(), submittedBy: FA.myName(), remark: '' });
        U.toast(T('submitted'), 'ok');
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      App.refresh();
    };
    const review = async (status) => {
      const remark = await U.prompt(status === 'approved' ? T('approve') : T('reject'), T('remarkOptional'), '', 'textarea'); if (remark == null) return;
      U.loading(true);
      try { await DB.update('fa_activities', a.id, { status, remark, reviewedBy: FA.myName(), reviewedAt: Date.now() }); U.toast(T('saved'), 'ok'); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      App.refresh();
    };
    const ap = U.$('#ap'); if (ap) ap.onclick = () => review('approved');
    const rj = U.$('#rj'); if (rj) rj.onclick = () => review('rejected');
    const ro = U.$('#ro'); if (ro) ro.onclick = async () => { await DB.update('fa_activities', a.id, { status: 'draft' }); App.refresh(); };
  };

  // ---------- Enquiries ----------
  FA.enqRow = (q) => '<div class="li" data-enq="' + esc(q.id) + '"><div class="grow"><b>' + esc(q.name) + '</b> ' + U.badge(q.enqType) + (q.exchange === 'Yes' ? ' <span class="badge muted">' + T('exchange') + '</span>' : '') +
    '<br><small class="muted">📞 ' + esc(q.mobile || '-') + ' · ' + esc(q.model || '') + (q.village ? ' · ' + esc(q.village) : '') + '</small><br><small class="muted">' + esc(q.empName || '') + ' · ' + U.fmtDate(q.date) +
    (q.status && q.status !== 'open' ? ' · ' : '') + '</small>' + (q.status && q.status !== 'open' ? U.badge(q.status) : '') + '</div><i>›</i></div>';
  FA.bindEnqRows = (el, list, after) => U.$$('[data-enq]', el).forEach((r) => r.onclick = () => FA.enqDetail(list.find((q) => q.id === r.dataset.enq), after));

  FA.enqForm = function (a, q, after) {
    const c = S.cfg.enq, x = q || { enqType: 'warm', exchange: 'No', finance: '', status: 'open' };
    const models = FA.models();
    const typeChips = ['hot', 'warm', 'cold'].map((k) => '<label class="type-opt sm"><input type="radio" name="enqType" value="' + k + '"' + (x.enqType === k ? ' checked' : '') + '><span>' + (k === 'hot' ? '🔥' : k === 'warm' ? '🌤️' : '❄️') + ' ' + T(k) + '</span></label>').join('');
    const yn = (name, v) => U.field(name, T(name === 'exchange' ? 'exchange' : 'finance'), v, { type: 'select', options: [{ v: 'No', l: T('no') }, { v: 'Yes', l: T('yes') }] });
    const html = '<form id="eqf" class="form">' + U.field('name', T('customerName') + ' *', x.name) + U.field('mobile', T('mobile') + (c.mobile ? ' *' : ''), x.mobile, { type: 'tel' }) +
      U.field('village', T('village') + (c.village ? ' *' : ''), x.village) +
      U.field('model', T('model') + (c.model ? ' *' : ''), x.model, { type: 'select', options: [{ v: '', l: '— ' + T('select') + ' —' }].concat(models, x.model && !models.includes(x.model) ? [x.model] : [], [T('other')]) }) +
      '<label class="fld"><span>' + T('enqType') + ' *</span><div class="type-grid three">' + typeChips + '</div></label>' +
      '<div class="grid2f">' + yn('exchange', x.exchange || 'No') + yn('finance', x.finance || 'No') + '</div>' +
      '<div id="exb">' + U.field('oldVehicle', T('oldVehicle'), x.oldVehicle) + '<div class="grid2f">' + U.field('oldYear', T('oldYear'), x.oldYear, { type: 'number' }) + U.field('expectedPrice', T('expectedPrice'), x.expectedPrice, { type: 'number' }) + '</div></div>' +
      '<div class="grid2f">' + U.field('purchaseTime', T('purchaseTime') + (c.purchaseTime ? ' *' : ''), x.purchaseTime, { type: 'select', options: [{ v: '', l: '—' }, { v: 'now', l: T('pt_now') }, { v: 'month', l: T('pt_month') }, { v: 'later', l: T('pt_later') }] }) +
      U.field('followUpDate', T('followUpDate') + (c.followUpDate ? ' *' : ''), x.followUpDate, { type: 'date' }) + '</div>' +
      U.field('remarks', T('remarks'), x.remarks, { type: 'textarea', rows: 2 }) + '<button class="btn block" type="submit">💾 ' + T('save') + '</button></form>';
    U.modal((q ? '✏️ ' : '➕ ') + T('enquiry'), html, {
      sticky: true, onOpen: (w, m) => {
        const f = w.querySelector('#eqf'), exs = f.querySelector('[name=exchange]'), exb = f.querySelector('#exb');
        const sync = () => { exb.style.display = exs.value === 'Yes' ? '' : 'none'; }; exs.onchange = sync; sync();
        f.onsubmit = async (e) => {
          e.preventDefault(); const d = U.formData(f); d.enqType = (f.querySelector('input[name=enqType]:checked') || {}).value || '';
          if (!d.name) return U.toast(T('isRequired', { f: T('customerName') }), 'err');
          const mob = String(d.mobile || '').replace(/\D/g, '');
          if ((c.mobile || d.mobile) && mob.length !== 10) return U.toast(T('isRequired', { f: T('mobile') + ' (10 digit)' }), 'err');
          for (const k of ['village', 'model', 'followUpDate', 'purchaseTime']) if (c[k] && !d[k]) return U.toast(T('isRequired', { f: T(k) }), 'err');
          if (!d.enqType) return U.toast(T('isRequired', { f: T('enqType') }), 'err');
          if (d.exchange !== 'Yes') { d.oldVehicle = ''; d.oldYear = ''; d.expectedPrice = ''; }
          d.mobile = mob;
          U.loading(true);
          try {
            if (q) await DB.update('fa_enquiries', q.id, Object.assign(d, { updatedAt: Date.now() }));
            else {
              await DB.add('fa_enquiries', Object.assign(d, { activityId: a.id, date: a.date, month: a.date.slice(0, 7), activityType: a.typeName, area: a.area || '', location: a.location || '',
                empId: FA.myId(), empName: FA.myName(), at: Date.now(), status: 'open', notes: [] }));
              await DB.update('fa_activities', a.id, { enqCount: DB.inc(1) });
            }
            m.close(); U.toast(T('saved'), 'ok'); if (after) after();
          } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  };

  FA.enqDetail = function (q, after) {
    const mine = S.isAdmin || q.empId === FA.myId();
    const kv = (k, v) => (v ? '<div><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>' : '');
    const pt = q.purchaseTime ? T('pt_' + q.purchaseTime) : '';
    const html = '<div class="row-between"><b class="big">' + esc(q.name) + '</b>' + U.badge(q.enqType) + '</div><div class="kv">' +
      '<div><span>' + T('mobile') + '</span><b>' + (q.mobile ? '<a href="tel:' + esc(q.mobile) + '">📞 ' + esc(q.mobile) + '</a>' : '-') + '</b></div>' +
      kv(T('village'), q.village) + kv(T('model'), q.model) + kv(T('exchange'), q.exchange === 'Yes' ? T('yes') : T('no')) + kv(T('oldVehicle'), q.oldVehicle) + kv(T('oldYear'), q.oldYear) +
      kv(T('expectedPrice'), q.expectedPrice ? U.money(q.expectedPrice) : '') + kv(T('finance'), q.finance === 'Yes' ? T('yes') : '') + kv(T('purchaseTime'), pt) + kv(T('followUpDate'), q.followUpDate ? U.fmtDate(q.followUpDate) : '') +
      kv(T('remarks'), q.remarks) + kv(T('activity'), (q.activityType || '') + (q.location ? ' – ' + q.location : '')) + kv(T('photoBy'), q.empName + ' · ' + U.fmtDT(q.at)) +
      '<div><span>' + T('enqStatus') + '</span><b>' + U.badge(q.status || 'open') + '</b></div></div>' +
      ((q.notes || []).length ? '<h3 style="margin-top:10px">' + T('followUpNote') + '</h3>' + q.notes.map((n) => '<div class="small"><b>' + U.fmtDT(n.at) + '</b> · ' + esc(n.by) + ' · ' + U.badge(n.status) + '<br>' + esc(n.text) + '</div>').join('<hr>') : '') +
      (mine ? '<hr><form id="fu" class="form">' + U.field('status', T('enqStatus'), q.status || 'open', { type: 'select', options: ['open', 'followup', 'booked', 'lost'].map((s) => ({ v: s, l: T('st_' + s) })) }) +
        U.field('text', T('followUpNote'), '', { type: 'textarea', rows: 2 }) + U.field('followUpDate', T('followUpDate'), q.followUpDate, { type: 'date' }) +
        '<div class="row-btns"><button type="button" class="btn ghost" id="eqe">✏️ ' + T('edit') + '</button><button class="btn">💾 ' + T('save') + '</button></div></form>' : '');
    U.modal(T('enquiry'), html, {
      onOpen: (w, m) => {
        const f = w.querySelector('#fu'); if (!f) return;
        w.querySelector('#eqe').onclick = () => { m.close(); FA.enqForm({ id: q.activityId }, q, after); };
        f.onsubmit = async (e) => {
          e.preventDefault(); const d = U.formData(f);
          const notes = (q.notes || []).concat(d.text || d.status !== q.status ? [{ at: Date.now(), by: FA.myName(), status: d.status, text: d.text || '' }] : []);
          U.loading(true);
          try { await DB.update('fa_enquiries', q.id, { status: d.status, followUpDate: d.followUpDate || '', notes, updatedAt: Date.now() }); m.close(); U.toast(T('saved'), 'ok'); if (after) after(); }
          catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  };

  V.enqList = async function (el, p) {
    const st = Object.assign({ range: 'month', from: monthStart(), to: today(), t: 'all', s: 'all', q: '', scope: 'mine' }, S._enqFilter || {}, p || {});
    S._enqFilter = st;
    const ranges = { today: [today(), today()], d7: [addDays(-6), today()], month: [monthStart(), today()] };
    if (ranges[st.range]) { st.from = ranges[st.range][0]; st.to = ranges[st.range][1]; }
    let list = await DB.query('fa_enquiries', [['date', '>=', st.from], ['date', '<=', st.to]]);
    if (!S.isAdmin && !(S.cfg.empSeeAll && st.scope === 'team')) list = list.filter((q) => q.empId === FA.myId());
    const base = list;
    if (st.t !== 'all') list = list.filter((q) => (st.t === 'exchange' ? q.exchange === 'Yes' : q.enqType === st.t));
    if (st.s !== 'all') list = list.filter((q) => (q.status || 'open') === st.s);
    if (st.q) { const s = st.q.toLowerCase(); list = list.filter((q) => [q.name, q.mobile, q.village, q.model, q.empName].join(' ').toLowerCase().includes(s)); }
    list.sort((a, b) => (b.at || 0) - (a.at || 0));
    const chip = (k, v, lab) => '<button class="chip' + (st[k] === v ? ' on' : '') + '" data-f="' + k + '" data-v="' + v + '">' + esc(lab) + '</button>';
    const n = (f) => base.filter(f).length;
    el.innerHTML = '<h2 class="page-title">🙋 ' + T('enquiries') + '</h2>' +
      (!S.isAdmin && S.cfg.empSeeAll ? '<div class="tabs"><button data-f="scope" data-v="mine" class="' + (st.scope === 'mine' ? 'on' : '') + '">' + T('mine') + '</button><button data-f="scope" data-v="team" class="' + (st.scope === 'team' ? 'on' : '') + '">' + T('teamAll') + '</button></div>' : '') +
      '<div class="chips">' + chip('range', 'today', T('today')) + chip('range', 'd7', '7 ' + (I18N.lang === 'hi' ? 'दिन' : 'days')) + chip('range', 'month', T('thisMonth')) + chip('range', 'custom', '📅') + '</div>' +
      (st.range === 'custom' ? '<div class="grid2f"><label class="fld"><span>' + T('from') + '</span><input type="date" id="f1" value="' + st.from + '"></label><label class="fld"><span>' + T('to') + '</span><input type="date" id="f2" value="' + st.to + '"></label></div>' : '') +
      '<div class="stats4"><div class="card center"><b>' + base.length + '</b><small>' + T('total') + '</small></div><div class="card center"><b class="low">' + n((q) => q.enqType === 'hot') + '</b><small>' + T('hot') +
      '</small></div><div class="card center"><b>' + n((q) => q.exchange === 'Yes') + '</b><small>' + T('exchange') + '</small></div><div class="card center"><b class="good">' + n((q) => q.status === 'booked') + '</b><small>' + T('booked') + '</small></div></div>' +
      '<div class="chips">' + chip('t', 'all', T('all')) + chip('t', 'hot', '🔥 ' + T('hot')) + chip('t', 'warm', '🌤️ ' + T('warm')) + chip('t', 'cold', '❄️ ' + T('cold')) + chip('t', 'exchange', '🔄 ' + T('exchange')) + '</div>' +
      '<div class="chips">' + chip('s', 'all', T('all')) + ['open', 'followup', 'booked', 'lost'].map((s) => chip('s', s, T('st_' + s))).join('') + '</div>' +
      '<input class="search" id="fq" placeholder="🔍 ' + T('search') + '" value="' + esc(st.q) + '">' +
      (S.isAdmin || S.cfg.empReports ? '<div class="row-btns left" style="margin:0 0 10px"><button class="btn ghost sm" id="xl">📊 ' + T('exportExcel') + '</button></div>' : '') +
      (list.length ? '<div class="card list">' + list.map(FA.enqRow).join('') + '</div>' : U.empty());
    const set = (o) => App.go('enqList', Object.assign({}, st, o));
    U.$$('[data-f]', el).forEach((b) => b.onclick = () => set({ [b.dataset.f]: b.dataset.v }));
    const f1 = U.$('#f1'), f2 = U.$('#f2'); if (f1) { f1.onchange = () => set({ from: f1.value }); f2.onchange = () => set({ to: f2.value }); }
    U.$('#fq').onchange = (e) => set({ q: e.target.value.trim() });
    const xl = U.$('#xl'); if (xl) xl.onclick = () => FA.enquiryExcel(list, st.from, st.to);
    FA.bindEnqRows(el, list, App.refresh);
  };
})();
