// ---------- Admin: dashboard, field team, activity types, rules ----------
(function () {
  const V = window.Views, esc = U.esc;
  const today = () => U.dateKey(new Date());
  const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return U.dateKey(d); };

  V.adminDashboard = async function (el) {
    const from30 = addDays(-29), mStart = U.monthKey(new Date()) + '-01';
    const from = from30 < mStart ? from30 : mStart;
    const [acts, enqs] = await Promise.all([FA.actByRange(from, today()), DB.query('fa_enquiries', [['date', '>=', from], ['date', '<=', today()]])]);
    const tA = acts.filter((a) => a.date === today()), tE = enqs.filter((q) => q.date === today());
    const pending = acts.filter((a) => a.status === 'submitted');
    const running = acts.filter((a) => a.status === 'draft' && a.date === today());
    // by type (30 days)
    const byType = {}; acts.filter((a) => a.date >= from30).forEach((a) => { byType[a.typeName] = (byType[a.typeName] || 0) + 1; });
    const maxT = Math.max(1, ...Object.values(byType));
    // team this month
    const mActs = acts.filter((a) => a.date >= mStart), mEnq = enqs.filter((q) => q.date >= mStart);
    const rows = S.members.filter((m) => m.active !== false).map((m) => {
      const my = mActs.filter((a) => (a.members || []).includes(m.id));
      const e = mEnq.filter((q) => q.empId === m.id);
      return { m, acts: my.length, lead: my.filter((a) => a.leaderId === m.id).length, photos: my.reduce((s, a) => s + (a.photoCount || 0), 0), enq: e.length, hot: e.filter((q) => q.enqType === 'hot').length, booked: e.filter((q) => q.status === 'booked').length };
    }).sort((a, b) => b.acts - a.acts || b.enq - a.enq);
    el.innerHTML = '<h2 class="page-title">📊 ' + T('dashboard') + '</h2>' +
      '<div class="stats4"><div class="card center"><b>' + tA.length + '</b><small>' + T('activities') + '</small></div><div class="card center"><b>' + tA.reduce((s, a) => s + (a.photoCount || 0), 0) +
      '</b><small>' + T('photos') + '</small></div><div class="card center"><b>' + tE.length + '</b><small>' + T('enquiries') + '</small></div><div class="card center"><b class="low">' + tE.filter((q) => q.enqType === 'hot').length +
      '</b><small>' + T('hot') + '</small></div></div><p class="muted small center" style="margin-top:-6px">' + T('today') + ' · ' + U.fmtDate(today()) + '</p>' +
      '<div class="row-btns left"><button class="btn" id="dr">📄 ' + T('dailyReport').split('(')[0] + '</button><button class="btn ghost" id="na">➕ ' + T('newActivity') + '</button></div>' +
      (pending.length ? '<h3 class="sec-title">⏳ ' + T('pendingApproval') + ' (' + pending.length + ')</h3>' + pending.map(FA.actCard).join('') : '') +
      (running.length ? '<h3 class="sec-title">🟢 ' + T('st_draft') + ' – ' + T('today') + '</h3>' + running.map(FA.actCard).join('') : '') +
      '<h3 class="sec-title">' + T('last30') + '</h3><div class="card">' + (Object.keys(byType).length ? Object.keys(byType).sort((a, b) => byType[b] - byType[a]).map((k) =>
        '<div class="hbar"><span>' + esc(k) + '</span><div><i style="width:' + Math.round(byType[k] / maxT * 100) + '%"></i></div><b>' + byType[k] + '</b></div>').join('') : '<p class="muted">' + T('noData') + '</p>') + '</div>' +
      '<h3 class="sec-title">' + T('teamMonth') + '</h3><div class="card table-wrap"><table class="tbl"><thead><tr><th>' + T('employee') + '</th><th>' + T('activities') + '</th><th>Lead</th><th>' + T('photos') +
      '</th><th>' + T('enquiries') + '</th><th>' + T('hot') + '</th><th>' + T('booked') + '</th></tr></thead><tbody>' +
      (rows.length ? rows.map((r) => '<tr><td>' + esc(r.m.name) + '<br><small class="muted">' + esc(r.m.id) + '</small></td><td>' + r.acts + '</td><td>' + r.lead + '</td><td>' + r.photos + '</td><td>' + r.enq + '</td><td>' + r.hot + '</td><td>' + r.booked + '</td></tr>').join('') :
        '<tr><td colspan="7">' + T('noData') + '</td></tr>') + '</tbody></table></div>' +
      (S.members.length ? '' : '<div class="note">👥 ' + T('fieldTeam') + ': ' + T('fetchHint') + ' <a data-g="adminTeam">→ ' + T('addMember') + '</a></div>');
    U.$('#dr').onclick = () => App.go('reports');
    U.$('#na').onclick = () => App.go('actNew');
    U.$$('[data-g]', el).forEach((a) => a.onclick = () => App.go(a.dataset.g));
    FA.bindActCards(el);
  };

  // ---------- Field team ----------
  V.adminTeam = async function (el) {
    await FA.loadMembers();
    el.innerHTML = '<div class="row-between"><h2 class="page-title">👥 ' + T('fieldTeam') + ' (' + S.members.length + ')</h2><button class="btn sm" id="am">➕ ' + T('addMember') + '</button></div>' +
      (S.members.length ? '<div class="card list">' + S.members.map((m) => '<div class="li emp-row" data-m="' + esc(m.id) + '">' + App.avatar(m, 42) + '<div class="grow"><b>' + esc(m.name) + '</b><small>' + esc(m.id) + ' · ' + esc(m.designation || '') + ' · 📞 ' + esc(m.mobile || '') +
        '</small><small>' + (m.role === 'leader' ? '⭐ ' : '') + T('role_' + (m.role || 'staff')) + '</small></div>' + (m.active === false ? '<span class="badge muted">' + T('inactive') + '</span>' : '<span class="badge ok">' + T('active') + '</span>') + '</div>').join('') + '</div>' :
        '<div class="note">' + T('fetchHint') + '</div>');
    U.$('#am').onclick = () => memberForm(null);
    U.$$('[data-m]', el).forEach((r) => r.onclick = () => memberForm(FA.member(r.dataset.m)));
  };
  function memberForm(m) {
    let fetched = m ? Object.assign({}, m) : null;
    const body = '<form id="mf" class="form">' + (m ? '' : '<p class="muted small">' + T('fetchHint') + '</p><div class="row"><input id="eid" class="search" style="margin:0" placeholder="' + T('employeeId') + ' e.g. MA002"><button type="button" class="btn" id="fe">' + T('fetch') + '</button></div>') +
      '<div id="mp" style="margin-top:12px"></div></form>';
    U.modal(m ? T('fieldTeam') : T('addMember'), body, {
      onOpen: (w, md) => {
        const mp = w.querySelector('#mp');
        const render = () => {
          if (!fetched) { mp.innerHTML = ''; return; }
          const e = fetched;
          mp.innerHTML = '<div class="card row" style="box-shadow:none;border:1px solid var(--line)">' + App.avatar(e, 56) + '<div><b>' + esc(e.name) + '</b><br><small class="muted">' + esc(e.id) + ' · ' + esc(e.designation || '') + '<br>📞 ' + esc(e.mobile || '') + (e.department ? ' · ' + esc(e.department) : '') + '</small></div></div>' +
            U.field('role', T('role'), e.role || 'staff', { type: 'select', options: [{ v: 'leader', l: T('role_leader') }, { v: 'staff', l: T('role_staff') }] }) +
            U.field('canCreate', T('canCreate'), e.canCreate !== false, { type: 'checkbox' }) + U.field('active', T('active'), e.active !== false, { type: 'checkbox' }) +
            '<div class="row-btns">' + (m ? '<button type="button" class="btn ghost" id="rm">🗑️ ' + T('removeMember') + '</button><button type="button" class="btn ghost" id="rf">🔄 ' + T('fetch') + '</button>' : '') + '<button class="btn">💾 ' + T('save') + '</button></div>';
          const rm = mp.querySelector('#rm'); if (rm) rm.onclick = async () => { if (!(await U.confirm(T('removeMember') + '?', T('delete')))) return; await DB.del('fa_members', m.id); md.close(); App.refresh(); };
          const rf = mp.querySelector('#rf'); if (rf) rf.onclick = async () => { const e2 = await fetchEmp(m.id); if (e2) { fetched = Object.assign(fetched, e2); render(); U.toast(T('saved') + ' ✓', 'ok'); } };
        };
        const fetchEmp = async (id) => {
          U.loading(true);
          try {
            const e = await DB.get('employees', id);
            if (!e) { U.toast(T('empNotFound'), 'err'); return null; }
            let photo = e.photo || '';
            if (photo && photo.length > 60000) { try { photo = await shrink(photo, 160); } catch (er) { photo = ''; } }
            return { id: e.id, name: e.name || '', mobile: e.mobile || '', designation: e.designation || '', department: e.department || '', photo, empActive: e.active !== false };
          } catch (err) { U.toast(err.message, 'err'); return null; } finally { U.loading(false); }
        };
        const fe = w.querySelector('#fe');
        if (fe) fe.onclick = async () => {
          const id = w.querySelector('#eid').value.trim().toUpperCase(); if (!id) return;
          if (FA.member(id)) return U.toast(T('alreadyMember'), 'err');
          const e = await fetchEmp(id); if (e) { fetched = Object.assign({ role: 'staff', canCreate: true, active: true }, e); render(); }
        };
        render();
        w.querySelector('#mf').onsubmit = async (ev) => {
          ev.preventDefault(); if (!fetched) return;
          const d = U.formData(w.querySelector('#mf'));
          U.loading(true);
          try {
            await DB.set('fa_members', fetched.id, { empId: fetched.id, name: fetched.name, mobile: fetched.mobile, designation: fetched.designation, department: fetched.department || '', photo: fetched.photo || '',
              role: d.role, canCreate: !!d.canCreate, active: !!d.active, addedAt: m ? (m.addedAt || Date.now()) : Date.now(), updatedAt: Date.now() });
            md.close(); U.toast(T('saved'), 'ok'); App.refresh();
          } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  }
  function shrink(dataUrl, side) {
    return new Promise((res, rej) => { const img = new Image(); img.onload = () => { const sc = Math.min(1, side / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * sc); c.height = Math.round(img.height * sc); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', 0.7)); }; img.onerror = rej; img.src = dataUrl; });
  }

  // ---------- Activity types ----------
  async function saveCfg(patch) {
    U.loading(true);
    try { await DB.set('fa_settings', 'app', patch, true); await FA.loadCfg(); U.toast(T('saved'), 'ok'); } catch (e) { U.toast(e.message, 'err'); throw e; } finally { U.loading(false); }
  }
  V.adminTypes = async function (el) {
    await FA.loadCfg();
    const types = S.cfg.types;
    el.innerHTML = '<div class="row-between"><h2 class="page-title">🗂️ ' + T('activityTypes') + '</h2><button class="btn sm" id="at">➕ ' + T('addType') + '</button></div>' +
      '<div class="card list">' + types.map((t, i) => '<div class="li" data-t="' + i + '"><span style="font-size:26px">' + esc(t.icon || '📍') + '</span><div class="grow"><b>' + esc(t.name) + '</b><br><small class="muted">📸 min ' + (t.minPhotos || 1) +
        ' · 🙋 ' + (t.enquiries === false ? '✕' : 'min ' + (t.minEnquiries || 0)) + ' · ' + (t.fields || []).length + ' fields</small></div>' + (t.active === false ? '<span class="badge muted">' + T('inactive') + '</span>' : '') +
        (i ? '<button class="icon-btn" data-up="' + i + '">⬆️</button>' : '') + '<i>›</i></div>').join('') + '</div>';
    U.$('#at').onclick = () => typeForm(-1);
    U.$$('[data-t]', el).forEach((r) => r.onclick = (e) => { if (e.target.dataset.up) return; typeForm(+r.dataset.t); });
    U.$$('[data-up]', el).forEach((b) => b.onclick = async (e) => { e.stopPropagation(); const i = +b.dataset.up; const ts = S.cfg.types.slice(); [ts[i - 1], ts[i]] = [ts[i], ts[i - 1]]; await saveCfg({ types: ts }); App.refresh(); });
  };
  function typeForm(idx) {
    const t = idx >= 0 ? JSON.parse(JSON.stringify(S.cfg.types[idx])) : { id: '', name: '', icon: '📍', active: true, minPhotos: 2, minEnquiries: 0, enquiries: true, fields: [] };
    const fieldRow = (f, i) => '<div class="fe-row" data-i="' + i + '"><div class="grid2f">' + U.field('label', T('fieldLabel'), f.label) +
      U.field('type', T('fieldType'), f.type, { type: 'select', options: ['number', 'text', 'textarea', 'select', 'yesno'].map((x) => ({ v: x, l: T('ft_' + x) })) }) + '</div>' +
      U.field('options', T('options'), f.options) + '<div class="row-between">' + U.field('required', T('required'), f.required, { type: 'checkbox' }) + '<button type="button" class="btn ghost sm" data-rf="' + i + '">🗑️</button></div><input type="hidden" name="key" value="' + esc(f.key || '') + '"></div>';
    const body = '<form id="tf" class="form"><div class="grid2f">' + U.field('name', T('typeName') + ' *', t.name) + U.field('icon', T('icon'), t.icon) + '</div>' +
      '<div class="grid2f">' + U.field('minPhotos', T('minPhotos'), t.minPhotos, { type: 'number', min: 1 }) + U.field('minEnquiries', T('minEnquiries'), t.minEnquiries, { type: 'number', min: 0 }) + '</div>' +
      U.field('enquiries', T('enquiriesOn'), t.enquiries !== false, { type: 'checkbox' }) + U.field('active', T('typeActive'), t.active !== false, { type: 'checkbox' }) +
      '<h3>' + T('customFields') + '</h3><div id="fl"></div><button type="button" class="btn ghost sm" id="af">➕ ' + T('addField') + '</button>' +
      '<div class="row-btns">' + (idx >= 0 ? '<button type="button" class="btn ghost" id="dt">🗑️ ' + T('delete') + '</button>' : '') + '<button class="btn">💾 ' + T('save') + '</button></div></form>';
    U.modal(idx >= 0 ? t.name : T('addType'), body, {
      sticky: true, wide: true, onOpen: (w, m) => {
        const fl = w.querySelector('#fl');
        const readFields = () => U.$$('.fe-row', fl).map((r) => { const d = {}; U.$$('[name]', r).forEach((x) => { d[x.name] = x.type === 'checkbox' ? x.checked : x.value.trim(); }); return d; });
        const draw = () => { fl.innerHTML = t.fields.map(fieldRow).join(''); U.$$('[data-rf]', fl).forEach((b) => b.onclick = () => { t.fields = readFields(); t.fields.splice(+b.dataset.rf, 1); draw(); }); };
        draw();
        w.querySelector('#af').onclick = () => { t.fields = readFields(); t.fields.push({ key: '', label: '', type: 'number', required: false, options: '' }); draw(); };
        const dt = w.querySelector('#dt');
        if (dt) dt.onclick = async () => { if (!(await U.confirm(T('deleteConfirm'), T('delete')))) return; const ts = S.cfg.types.slice(); ts.splice(idx, 1); await saveCfg({ types: ts }); m.close(); App.refresh(); };
        w.querySelector('#tf').onsubmit = async (e) => {
          e.preventDefault();
          const top = {}; U.$$('#tf > .grid2f [name], #tf > .chk [name], #tf > label [name]', w).forEach((x) => { top[x.name] = x.type === 'checkbox' ? x.checked : x.value.trim(); });
          if (!top.name) return U.toast(T('isRequired', { f: T('typeName') }), 'err');
          const used = new Set();
          const fields = readFields().filter((f) => f.label).map((f) => {
            let key = f.key || f.label.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'f';
            while (used.has(key)) key += '_2'; used.add(key);
            return { key, label: f.label, type: f.type, required: !!f.required, options: f.options || '' };
          });
          const nt = Object.assign(t, { name: top.name, icon: top.icon || '📍', minPhotos: Math.max(1, parseInt(top.minPhotos) || 1), minEnquiries: Math.max(0, parseInt(top.minEnquiries) || 0),
            enquiries: !!top.enquiries, active: !!top.active, fields });
          if (!nt.id) nt.id = top.name.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 30) + '_' + Date.now().toString(36).slice(-4);
          const ts = S.cfg.types.slice(); if (idx >= 0) ts[idx] = nt; else ts.push(nt);
          await saveCfg({ types: ts }); m.close(); App.refresh();
        };
      }
    });
  }

  // ---------- Rules & mandatory ----------
  V.adminRules = async function (el) {
    await FA.loadCfg();
    const c = S.cfg;
    const ck = (name, label, v) => U.field(name, label, v, { type: 'checkbox' });
    el.innerHTML = '<h2 class="page-title">✅ ' + T('rules') + '</h2><form id="rf" class="form">' +
      '<div class="card"><h3>' + T('coreMandatory') + '</h3>' + ['area', 'location', 'landmark', 'leader', 'team', 'plan', 'target'].map((k) => ck('core_' + k, T(k), c.core[k])).join('') +
      '<p class="muted small">📸 ' + T('minPhotos') + ' → ' + T('activityTypes') + '</p></div>' +
      '<div class="card"><h3>' + T('enqMandatory') + '</h3><p class="muted small">' + T('customerName') + ', ' + T('enqType') + ' – ' + T('required') + '</p>' +
      ['mobile', 'village', 'model', 'followUpDate', 'purchaseTime'].map((k) => ck('enq_' + k, T(k), c.enq[k])).join('') + '</div>' +
      '<div class="card"><h3>' + T('photoRules') + '</h3>' + ck('allowGallery', T('allowGallery'), c.allowGallery) + ck('blockMock', T('blockMock'), c.blockMock) + ck('endGps', T('endGps') + ' (' + T('submitActivity') + ')', c.endGps) + '</div>' +
      '<div class="card"><h3>' + T('settings') + '</h3>' + ck('requireApproval', T('requireApproval'), c.requireApproval) + ck('empSeeAll', T('empSeeAll'), c.empSeeAll) + ck('empReports', T('empReports'), c.empReports) +
      U.field('models', T('models'), c.models, { type: 'textarea', rows: 6 }) + U.field('areas', T('areas'), c.areas, { type: 'textarea', rows: 4 }) + '</div>' +
      '<button class="btn block">💾 ' + T('save') + '</button></form>';
    U.$('#rf').onsubmit = async (e) => {
      e.preventDefault(); const d = U.formData(e.target);
      const core = {}, enq = {};
      Object.keys(d).forEach((k) => { if (k.startsWith('core_')) core[k.slice(5)] = d[k]; if (k.startsWith('enq_')) enq[k.slice(4)] = d[k]; });
      await saveCfg({ core, enq, allowGallery: d.allowGallery, blockMock: d.blockMock, endGps: d.endGps, requireApproval: d.requireApproval, empSeeAll: d.empSeeAll, empReports: d.empReports, models: d.models, areas: d.areas });
      App.refresh();
    };
  };
})();
