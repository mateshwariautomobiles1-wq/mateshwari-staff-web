// =====================================================================
//  MATESHWARI AUTOMOBILES - FIELD ACTIVITY APP CONFIG
//  Same Firebase project as the Staff app (same logins, same employees)
// =====================================================================
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAfd60w6ARCH1eSddXoh1SM9HGlOvF3X-k",
  authDomain: "mateshwari-staff.firebaseapp.com",
  projectId: "mateshwari-staff",
  storageBucket: "mateshwari-staff.firebasestorage.app",
  messagingSenderId: "869746141888",
  appId: "1:869746141888:web:7fcb86066de1edf6d75b25"
};

window.APP_INFO = {
  showroom: "MATESHWARI AUTOMOBILES",
  tagline: "Authorised Dealer",
  appName: "Field Activity",
  staffDomain: "staff.mateshwari.app",
  version: "1.0.0"
};
