// ---------- English / Hindi (Field Activity app) ----------
(function () {
  // key: [English, Hindi]
  const P = {
    appSubtitle: ['Field Activity & Daily Report', 'फील्ड एक्टिविटी और डेली रिपोर्ट'],
    login: ['Login', 'लॉगिन'], logout: ['Logout', 'लॉगआउट'], logoutConfirm: ['Do you want to logout?', 'क्या आप लॉगआउट करना चाहते हैं?'],
    mobileOrEmail: ['Mobile number (or Admin email)', 'मोबाइल नंबर (या एडमिन ईमेल)'], password: ['Password', 'पासवर्ड'],
    sameLogin: ['Use the same login as the Mateshwari Staff app.', 'मातेश्वरी स्टाफ ऐप वाला ही लॉगिन इस्तेमाल करें।'],
    signingIn: ['Signing in...', 'लॉगिन हो रहा है...'], wrongLogin: ['Wrong mobile number or password', 'गलत मोबाइल नंबर या पासवर्ड'],
    tooMany: ['Too many attempts. Try again later.', 'बहुत ज़्यादा कोशिश। थोड़ी देर बाद करें।'], noInternet: ['No internet connection', 'इंटरनेट नहीं है'],
    loginNotFound: ['No account found for this mobile number', 'इस मोबाइल नंबर का कोई अकाउंट नहीं'],
    accountInactive: ['Your account is inactive. Contact admin.', 'आपका अकाउंट बंद है। एडमिन से संपर्क करें।'],
    notFieldMember: ['You are not added to the Field Team. Ask admin to add your Employee ID.', 'आप फील्ड टीम में नहीं जोड़े गए हैं। एडमिन से अपनी Employee ID जुड़वाएं।'],
    notConfigured: ['App is not connected to Firebase.', 'ऐप Firebase से नहीं जुड़ा है।'],
    error: ['Error', 'त्रुटि'], retry: ['Retry', 'फिर से'], pleaseWait: ['Please wait...', 'कृपया रुकें...'], confirm: ['Confirm', 'पुष्टि करें'],
    cancel: ['Cancel', 'रद्द'], yes: ['Yes', 'हाँ'], no: ['No', 'नहीं'], ok: ['OK', 'ठीक'], save: ['Save', 'सेव करें'], saved: ['Saved', 'सेव हो गया'],
    delete: ['Delete', 'हटाएं'], deleted: ['Deleted', 'हटा दिया'], deleteConfirm: ['Delete this permanently?', 'इसे हमेशा के लिए हटाएं?'], edit: ['Edit', 'बदलें'],
    view: ['View', 'देखें'], back: ['Back', 'वापस'], search: ['Search', 'खोजें'], select: ['Select', 'चुनें'], all: ['All', 'सभी'], add: ['Add', 'जोड़ें'],
    noData: ['No records', 'कोई रिकॉर्ड नहीं'], autoFilled: ['auto', 'ऑटो'], savedDocuments: ['Saved in Documents folder', 'Documents फोल्डर में सेव'],
    saveFailed: ['Save failed', 'सेव नहीं हुआ'], gpsDenied: ['Location permission denied. Please allow location.', 'लोकेशन की अनुमति नहीं मिली। कृपया अनुमति दें।'],
    gpsFailed: ['Could not get GPS location. Turn on GPS and try again.', 'GPS लोकेशन नहीं मिली। GPS चालू कर फिर कोशिश करें।'],
    gettingLocation: ['Getting GPS location...', 'GPS लोकेशन ली जा रही है...'], mockBlocked: ['Fake GPS detected. Turn off mock location apps.', 'नकली GPS पकड़ा गया। मॉक लोकेशन ऐप बंद करें।'],
    home: ['Home', 'होम'], dashboard: ['Dashboard', 'डैशबोर्ड'], activities: ['Activities', 'एक्टिविटी'], activity: ['Activity', 'एक्टिविटी'],
    newActivity: ['New Activity', 'नई एक्टिविटी'], myActivities: ['My Activities', 'मेरी एक्टिविटी'], enquiries: ['Enquiries', 'पूछताछ'], enquiry: ['Enquiry', 'पूछताछ'],
    reports: ['Reports', 'रिपोर्ट'], more: ['More', 'और'], menu: ['Menu', 'मेनू'], fieldTeam: ['Field Team', 'फील्ड टीम'],
    activityTypes: ['Activity Types & Fields', 'एक्टिविटी प्रकार और फ़ील्ड'], rules: ['Rules & Mandatory', 'नियम और ज़रूरी फ़ील्ड'], settings: ['Settings', 'सेटिंग'],
    changePassword: ['Change Password', 'पासवर्ड बदलें'], oldPassword: ['Old password', 'पुराना पासवर्ड'], newPassword: ['New password', 'नया पासवर्ड'],
    confirmPassword: ['Confirm password', 'पासवर्ड दोबारा'], pwdShort: ['Password must be at least 6 characters', 'पासवर्ड कम से कम 6 अक्षर'],
    pwdMismatch: ['Passwords do not match', 'पासवर्ड मेल नहीं खाते'], adminPanel: ['Admin Panel', 'एडमिन पैनल'], language: ['Language', 'भाषा'],
    hello: ['Hello', 'नमस्ते'], today: ['Today', 'आज'], thisMonth: ['This month', 'इस महीने'], startActivity: ['Start New Activity', 'नई एक्टिविटी शुरू करें'],
    todaysActivities: ["Today's activities", 'आज की एक्टिविटी'], pendingApproval: ['Pending approval', 'मंज़ूरी बाकी'],
    // activity
    date: ['Date', 'तारीख'], activityType: ['Activity type', 'एक्टिविटी प्रकार'], area: ['Area', 'एरिया'], location: ['Location / Village / Town', 'जगह / गाँव / कस्बा'],
    landmark: ['Landmark / Spot', 'लैंडमार्क / स्पॉट'], leader: ['Main leader', 'मुख्य लीडर'], team: ['Staff team', 'स्टाफ टीम'], plan: ['What we will do (plan)', 'क्या करेंगे (प्लान)'],
    target: ['Target / Quantity planned', 'टारगेट / प्लान की मात्रा'], createdBy: ['Created by', 'किसने बनाया'], startGps: ['Start GPS', 'शुरुआत GPS'], endGps: ['End GPS', 'समाप्ति GPS'],
    start: ['Start', 'शुरू'], end: ['End', 'समाप्त'], status: ['Status', 'स्थिति'], photos: ['Photos', 'फोटो'], photo: ['Photo', 'फोटो'], details: ['Details', 'विवरण'],
    takePhoto: ['Take Photo', 'फोटो लें'], fromGallery: ['From gallery', 'गैलरी से'], caption: ['Caption (optional)', 'कैप्शन (वैकल्पिक)'], capture: ['Capture', 'कैप्चर'],
    photoSaved: ['Photo saved with GPS', 'GPS के साथ फोटो सेव'], addEnquiry: ['Add Enquiry', 'पूछताछ जोड़ें'], saveDraft: ['Save', 'सेव करें'],
    createActivity: ['Create & continue', 'बनाएं और आगे बढ़ें'], submitActivity: ['Finish & Submit', 'पूरा कर सबमिट करें'], submitConfirm: ['Submit this activity? After submitting you cannot add photos or edit.', 'यह एक्टिविटी सबमिट करें? सबमिट के बाद फोटो या बदलाव नहीं होंगे।'],
    submitted: ['Submitted', 'सबमिट हो गया'], approve: ['Approve', 'मंज़ूर'], reject: ['Reject', 'नामंज़ूर'], remark: ['Remark', 'टिप्पणी'], remarkOptional: ['Remark (optional)', 'टिप्पणी (वैकल्पिक)'],
    reopen: ['Reopen for edit', 'बदलाव के लिए खोलें'], missingItems: ['Complete these before submitting:', 'सबमिट से पहले ये पूरा करें:'],
    minPhotosMsg: ['At least {n} photo(s) required (now {c})', 'कम से कम {n} फोटो ज़रूरी (अभी {c})'], minEnqMsg: ['At least {n} enquiry required (now {c})', 'कम से कम {n} पूछताछ ज़रूरी (अभी {c})'],
    isRequired: ['{f} is required', '{f} ज़रूरी है'], selectMembers: ['Select team members', 'टीम सदस्य चुनें'], members: ['members', 'सदस्य'],
    downloadPdf: ['Download PDF', 'PDF डाउनलोड'], exportExcel: ['Export Excel', 'Excel एक्सपोर्ट'], openMap: ['Map', 'मैप'], fromStart: ['from start', 'शुरुआत से'],
    photoBy: ['By', 'द्वारा'], noPhotos: ['No photos yet. Photo is mandatory.', 'अभी कोई फोटो नहीं। फोटो ज़रूरी है।'], cameraFail: ['Camera not available', 'कैमरा उपलब्ध नहीं'],
    st_draft: ['In progress', 'चालू'], st_submitted: ['Submitted', 'सबमिट'], st_approved: ['Approved', 'मंज़ूर'], st_rejected: ['Rejected', 'नामंज़ूर'],
    st_open: ['Open', 'खुली'], st_followup: ['Follow-up', 'फॉलो-अप'], st_booked: ['Booked', 'बुक'], st_lost: ['Lost', 'खोई'],
    st_pending: ['Pending', 'बाकी'],
    // enquiry
    customerName: ['Customer name', 'ग्राहक का नाम'], mobile: ['Mobile', 'मोबाइल'], village: ['Village / Address', 'गाँव / पता'], model: ['Model interested', 'पसंद का मॉडल'],
    enqType: ['Enquiry type', 'पूछताछ प्रकार'], hot: ['Hot', 'हॉट'], warm: ['Warm', 'वॉर्म'], cold: ['Cold', 'कोल्ड'], exchange: ['Exchange', 'एक्सचेंज'],
    oldVehicle: ['Old vehicle (make / model)', 'पुराना वाहन (कंपनी / मॉडल)'], oldYear: ['Old vehicle year', 'पुराने वाहन का साल'], expectedPrice: ['Expected price ₹', 'अपेक्षित कीमत ₹'],
    finance: ['Finance needed', 'फाइनेंस चाहिए'], followUpDate: ['Follow-up date', 'फॉलो-अप तारीख'], remarks: ['Remarks', 'टिप्पणी'], purchaseTime: ['Purchase plan', 'खरीद कब'],
    enqStatus: ['Enquiry status', 'पूछताछ स्थिति'], followUpNote: ['Follow-up note', 'फॉलो-अप नोट'], other: ['Other', 'अन्य'],
    pt_now: ['Within 7 days', '7 दिन में'], pt_month: ['Within 30 days', '30 दिन में'], pt_later: ['Later', 'बाद में'],
    // team
    addMember: ['Add member', 'सदस्य जोड़ें'], employeeId: ['Employee ID', 'कर्मचारी ID'], fetch: ['Fetch', 'लाएं'], fetchHint: ['Enter the Employee ID from the Staff app and press Fetch.', 'स्टाफ ऐप वाली कर्मचारी ID डालकर "लाएं" दबाएं।'],
    empNotFound: ['No employee found with this ID', 'इस ID का कोई कर्मचारी नहीं'], role: ['Role', 'भूमिका'], role_leader: ['Team Leader', 'टीम लीडर'], role_staff: ['Field Staff', 'फील्ड स्टाफ'],
    active: ['Active', 'सक्रिय'], inactive: ['Inactive', 'बंद'], designation: ['Designation', 'पद'], removeMember: ['Remove from field team', 'फील्ड टीम से हटाएं'],
    canCreate: ['Can create activities', 'एक्टिविटी बना सकता है'], alreadyMember: ['Already in field team', 'पहले से फील्ड टीम में'],
    // types & rules
    addType: ['Add activity type', 'एक्टिविटी प्रकार जोड़ें'], typeName: ['Activity name', 'एक्टिविटी का नाम'], icon: ['Icon', 'आइकन'], minPhotos: ['Minimum photos', 'कम से कम फोटो'],
    minEnquiries: ['Minimum enquiries', 'कम से कम पूछताछ'], enquiriesOn: ['Enquiry entry allowed', 'पूछताछ एंट्री चालू'], customFields: ['Extra fields for this activity', 'इस एक्टिविटी के अतिरिक्त फ़ील्ड'],
    addField: ['Add field', 'फ़ील्ड जोड़ें'], fieldLabel: ['Field label', 'फ़ील्ड नाम'], fieldType: ['Type', 'प्रकार'], options: ['Options (comma separated)', 'विकल्प (कॉमा से अलग)'],
    required: ['Mandatory', 'ज़रूरी'], ft_text: ['Text', 'टेक्स्ट'], ft_number: ['Number', 'संख्या'], ft_select: ['Dropdown', 'ड्रॉपडाउन'], ft_textarea: ['Long text', 'लंबा टेक्स्ट'], ft_yesno: ['Yes / No', 'हाँ / नहीं'],
    coreMandatory: ['Mandatory activity details', 'ज़रूरी एक्टिविटी विवरण'], enqMandatory: ['Mandatory enquiry details', 'ज़रूरी पूछताछ विवरण'],
    photoRules: ['Photo & GPS rules', 'फोटो और GPS नियम'], allowGallery: ['Allow photo from gallery (default: live camera only)', 'गैलरी से फोटो की अनुमति (डिफ़ॉल्ट: सिर्फ लाइव कैमरा)'],
    blockMock: ['Block fake GPS', 'नकली GPS रोकें'], requireApproval: ['Admin approval needed after submit', 'सबमिट के बाद एडमिन मंज़ूरी ज़रूरी'],
    empSeeAll: ['Field staff can see all team activities (off = only own)', 'फील्ड स्टाफ सभी टीम एक्टिविटी देख सके (बंद = सिर्फ अपनी)'],
    empReports: ['Field staff can download PDF reports', 'फील्ड स्टाफ PDF रिपोर्ट डाउनलोड कर सके'], models: ['Vehicle models (one per line)', 'वाहन मॉडल (हर लाइन में एक)'],
    areas: ['Areas list (one per line, optional)', 'एरिया सूची (हर लाइन में एक, वैकल्पिक)'], typeActive: ['Active', 'चालू'], moveUp: ['Up', 'ऊपर'],
    // reports
    dailyReport: ['Daily Activity Report (PDF with photos)', 'डेली एक्टिविटी रिपोर्ट (फोटो सहित PDF)'], rangeReport: ['Activity report – date range', 'एक्टिविटी रिपोर्ट – तारीख सीमा'],
    enquiryReport: ['Enquiry report', 'पूछताछ रिपोर्ट'], employeeReport: ['Employee-wise summary', 'कर्मचारी अनुसार सारांश'], typeReport: ['Activity-type summary', 'एक्टिविटी प्रकार सारांश'],
    from: ['From', 'से'], to: ['To', 'तक'], employee: ['Employee', 'कर्मचारी'], allEmployees: ['All employees', 'सभी कर्मचारी'], allTypes: ['All types', 'सभी प्रकार'],
    generate: ['Generate', 'बनाएं'], includePhotos: ['Include photos', 'फोटो शामिल करें'], noActivities: ['No activities for this selection', 'इस चयन में कोई एक्टिविटी नहीं'],
    preparingPdf: ['Preparing PDF with photos...', 'फोटो सहित PDF बन रही है...'], total: ['Total', 'कुल'], count: ['Count', 'संख्या'],
    reportsOff: ['Reports are allowed only for admin.', 'रिपोर्ट सिर्फ एडमिन के लिए है।'], summary: ['Summary', 'सारांश'], approvedOnly: ['Approved only', 'सिर्फ मंज़ूर'],
    last30: ['Last 30 days by activity type', 'पिछले 30 दिन – एक्टिविटी प्रकार अनुसार'], teamMonth: ['Team performance – this month', 'टीम प्रदर्शन – इस महीने'],
    profile: ['My profile', 'मेरी प्रोफाइल'], deletePhotoConfirm: ['Delete this photo?', 'यह फोटो हटाएं?'], notAllowedCreate: ['You are not allowed to create activities.', 'आपको एक्टिविटी बनाने की अनुमति नहीं।'],
    gpsAccuracy: ['accuracy', 'सटीकता'], km: ['km', 'कि.मी.'], m: ['m', 'मी.'], filter: ['Filter', 'फ़िल्टर'], booked: ['Booked', 'बुक'], conversion: ['Conversion', 'कन्वर्ज़न'],
    duration: ['Duration', 'अवधि'], startedAt: ['Started', 'शुरू हुई'], endedAt: ['Ended', 'खत्म हुई'], reviewedBy: ['Reviewed by', 'समीक्षा'], open: ['Open', 'खोलें'],
    mine: ['Mine', 'मेरी'], teamAll: ['Team', 'टीम'], photoTaken: ['Photo', 'फोटो']
  };
  const en = {}, hi = {};
  Object.keys(P).forEach((k) => { en[k] = P[k][0]; hi[k] = P[k][1]; });
  const I18N = window.I18N = { lang: 'hi', dict: { en, hi } };
  I18N.init = function () { try { I18N.lang = localStorage.getItem('fa_lang') || 'hi'; } catch (e) { I18N.lang = 'hi'; } document.documentElement.lang = I18N.lang; };
  I18N.set = function (l) { I18N.lang = l; try { localStorage.setItem('fa_lang', l); } catch (e) { } document.documentElement.lang = l; };
  window.T = function (k, vars) { let s = (I18N.dict[I18N.lang] && I18N.dict[I18N.lang][k]) || en[k] || k; if (vars) s = s.replace(/\{(\w+)\}/g, (m, x) => (vars[x] != null ? vars[x] : m)); return s; };
})();
